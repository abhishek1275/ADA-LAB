

/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;
async function test_calculate_individual_risk_score_success(GET, POST, PATCH, DELETE, expect) {
  //Arrange
  const QuestionnaireV1 = {
    ID: uuid(),
    version: 'v3',
    questionnairetype_code: 'Usecase Impact Assessment',
    isActive: true,
    submitted: true,
    email: 'test@example.com',
    individualRiskScoreFormula: 'scope + scale + remediation * likelihood',
    overAllRiskScoreFormula: 'sum(individualScores) / count',
    createdAt: new Date(),
    createdBy: 'admin',
    modifiedAt: new Date(),
    modifiedBy: 'admin'
  }

  const section1 = {
    ID: uuid(),
    text: 'General Section'
  };

  const QuestionsV1 = [
    {
      ID: uuid(),
      questionNumber: 1,
      questionText: 'Processing personal information: test question?',
      questionID: 'Q1',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Define the operational scope',
      examples: 'Internal use, External use',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin',
      highRiskFramework_code: 'Processing personal data'
    },
    {
      ID: uuid(),
      questionNumber: 2,
      questionText: 'Scope  Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: ' Q:',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      questionNumber: 3,
      questionText: 'Scale Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Assess risk probability',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      questionNumber: 4,
      questionText: 'Remediatbility Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Assess risk probability',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
    ,
    {
      ID: uuid(),
      questionNumber: 5,
      questionText: 'Likelihood Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: ' Q:',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];
  const ChoicesV1 = [
    {
      ID: uuid(),
      text: 'Yes',
      question_ID: QuestionsV1[0].ID,
      sequence: 1,
      explanation_required: false,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'PPD Scope',
      question_ID: QuestionsV1[1].ID,
      sequence: 1,
      explanation_required: false,
      high_risk_score: 1
    },
    {
      ID: uuid(),
      text: 'PPDScale',
      question_ID: QuestionsV1[1].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    },
    {
      ID: uuid(),
      text: 'PPD Likelihood',
      question_ID: QuestionsV1[1].ID,
      sequence: 1,
      explanation_required: true,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'PPDRemediatbility',
      question_ID: QuestionsV1[1].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    }
  ];

  const DependentAnswersV1 = [
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[1].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[2].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[3].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[4].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];

  await INSERT.into('sapit.acoe.aiea.Questions').entries(QuestionsV1);
  await INSERT.into('sapit.acoe.aiea.Choices').entries(ChoicesV1);
  await INSERT.into('sapit.acoe.aiea.DependentQuestionAnswer').entries(DependentAnswersV1);


  console.log("Choices", ChoicesV1);

  const AIEthicsImapactAssessment = {
    ID: uuid(),
    name: "AI Ethics Impact Assessment",
    sourceSystem: "SIRIUS",
    sourceSystemID: "SysID-2345",
    responsibilityArea: "Ethics and Compliance",
    processor: "admin",
    isSteeringExceptionProvided: true,
    status_code: "Submitted",
    createdBy: "bob"
  }

  const GroupedQuestionnaireResponse = {
    ID: uuid(),
    assessment_ID: AIEthicsImapactAssessment.ID,
    questionnaire_ID: QuestionnaireV1.ID
  };

  const QuestionnaireResponse = [{
    question_ID: QuestionsV1[1].ID,
    choices_ID: ChoicesV1[1].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID

  },
  {
    question_ID: QuestionsV1[2].ID,
    choices_ID: ChoicesV1[2].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID

  },
  {
    question_ID: QuestionsV1[3].ID,
    choices_ID: ChoicesV1[3].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID
  },
  {
    question_ID: QuestionsV1[4].ID,
    choices_ID: ChoicesV1[4].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID
  },
  {
    question_ID: QuestionsV1[0].ID,
    choices_ID: ChoicesV1[0].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID
  }
  ];

  // Insert test data
  await INSERT.into('sapit.acoe.aiea.AIEthicsImpactAssessments').entries({
    ...AIEthicsImapactAssessment,
    IsActiveEntity: true  // Add this field
  });


  // Create new draft questionnaire


  const draftResponse = await POST(
    `/service/AIEthicsAssessment/AIEthicsImpactAssessments`,
    {
      ...AIEthicsImapactAssessment,
      IsActiveEntity: false,
      HasActiveEntity: false
    },
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );
  const draftId = draftResponse.data.ID;

  // Create GroupedQuestionnaireResponse in draft
  const groupedResponse = await POST(
    `/service/AIEthicsAssessment/AIEthicsImpactAssessments(ID=${draftId},IsActiveEntity=false)/groupedQuestionnaireResponse`,
    {
      questionnaire_ID: QuestionnaireV1.ID,
      IsActiveEntity: false
    },
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );

  const groupedResponseId = groupedResponse.data.ID;

  // Add QuestionnaireResponse entries to the draft
  for (const response of QuestionnaireResponse) {
    await POST(
      `/service/AIEthicsAssessment/AIEthicsImpactAssessments(ID=${draftId},IsActiveEntity=false)/groupedQuestionnaireResponse(ID=${groupedResponseId},IsActiveEntity=false)/questionnaireResponse`,
      {
        ID: uuid(),
        question_ID: response.question_ID,
        responseChoice_ID: response.choices_ID,
        groupedQuestionnaireResponse_ID: groupedResponseId,
        IsActiveEntity: false,
        HasActiveEntity: false
      },
      {
        withCredentials: true,
        auth: { username: "bob", password: "bob" }
      }
    );
  }

  // Act
  await POST(
    `/service/AIEthicsAssessment/AIEthicsImpactAssessments(ID=${draftId},IsActiveEntity=false)/groupedQuestionnaireResponse(ID=${groupedResponseId},IsActiveEntity=false)/AIEthicsAssessment.calculateIndividualRiskScore`,
    {
      individualRiskQuestionId: ChoicesV1[0].ID,
      scopeChoiceId: ChoicesV1[1].ID,
      scaleChoiceID: ChoicesV1[2].ID,
      likeliHoodChoiceID: ChoicesV1[3].ID,
      remediatbilityChoiceID: ChoicesV1[4].ID,
    },
    {
      withCredentials: true,

      auth: {
        username: "bob",
        password: "bob"
      }
    }
  );

  // Assert

  // Verify the data was actually copied 

  const updatedDraftResponse = await SELECT.one.from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
    .where({ ID: draftId });

  expect(updatedDraftResponse.processingPersonalDataRiskScore).to.equal(5.00);

}

async function test_calculate_individual_risk_score_failure(GET, POST, PATCH, DELETE, expect) {
  //Arrange
  const QuestionnaireV1 = {
    ID: uuid(),
    version: 'v3',
    questionnairetype_code: 'Usecase Impact Assessment',
    isActive: true,
    submitted: true,
    email: 'test@example.com',
    individualRiskScoreFormula: 'scope + scale + remediation * likelihood',
    overAllRiskScoreFormula: 'sum(individualScores) / count',
    createdAt: new Date(),
    createdBy: 'admin',
    modifiedAt: new Date(),
    modifiedBy: 'admin'
  }

  const section1 = {
    ID: uuid(),
    text: 'General Section'
  };

  const QuestionsV1 = [
    {
      ID: uuid(),
      questionNumber: 1,
      questionText: 'Processing personal information: test question?',
      questionID: 'Q1',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Define the operational scope',
      examples: 'Internal use, External use',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin',
      highRiskFramework_code: null
    },
    {
      ID: uuid(),
      questionNumber: 2,
      questionText: 'Scope  Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: ' Q:',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      questionNumber: 3,
      questionText: 'Scale Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Assess risk probability',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      questionNumber: 4,
      questionText: 'Remediatbility Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Assess risk probability',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
    ,
    {
      ID: uuid(),
      questionNumber: 5,
      questionText: 'Likelihood Q: ?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: ' Q:',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];
  const ChoicesV1 = [
    {
      ID: uuid(),
      text: 'Yes',
      question_ID: QuestionsV1[0].ID,
      sequence: 1,
      explanation_required: false,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'PPD Scope',
      question_ID: QuestionsV1[1].ID,
      sequence: 1,
      explanation_required: false,
      high_risk_score: 1
    },
    {
      ID: uuid(),
      text: 'PPDScale',
      question_ID: QuestionsV1[1].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    },
    {
      ID: uuid(),
      text: 'PPD Likelihood',
      question_ID: QuestionsV1[1].ID,
      sequence: 1,
      explanation_required: true,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'PPDRemediatbility',
      question_ID: QuestionsV1[1].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    }
  ];

  const DependentAnswersV1 = [
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[1].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[2].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[3].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[4].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];

  await INSERT.into('sapit.acoe.aiea.Questions').entries(QuestionsV1);
  await INSERT.into('sapit.acoe.aiea.Choices').entries(ChoicesV1);
  await INSERT.into('sapit.acoe.aiea.DependentQuestionAnswer').entries(DependentAnswersV1);


  console.log("Choices", ChoicesV1);

  const AIEthicsImapactAssessment = {
    ID: uuid(),
    name: "AI Ethics Impact Assessment",
    sourceSystem: "SIRIUS",
    sourceSystemID: "SysID-2345",
    responsibilityArea: "Ethics and Compliance",
    processor: "admin",
    isSteeringExceptionProvided: true,
    status_code: "Submitted",
    createdBy: "bob"
  }

  const GroupedQuestionnaireResponse = {
    ID: uuid(),
    assessment_ID: AIEthicsImapactAssessment.ID,
    questionnaire_ID: QuestionnaireV1.ID
  };

  const QuestionnaireResponse = [{
    question_ID: QuestionsV1[1].ID,
    choices_ID: ChoicesV1[1].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID

  },
  {
    question_ID: QuestionsV1[2].ID,
    choices_ID: ChoicesV1[2].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID

  },
  {
    question_ID: QuestionsV1[3].ID,
    choices_ID: ChoicesV1[3].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID
  },
  {
    question_ID: QuestionsV1[4].ID,
    choices_ID: ChoicesV1[4].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID
  },
  {
    question_ID: QuestionsV1[0].ID,
    choices_ID: ChoicesV1[0].ID,
    groupedQuestionnaireResponse_ID: GroupedQuestionnaireResponse.ID
  }
  ];

  // Insert test data
  await INSERT.into('sapit.acoe.aiea.AIEthicsImpactAssessments').entries({
    ...AIEthicsImapactAssessment,
    IsActiveEntity: true  // Add this field
  });


  // Create new draft questionnaire


  const draftResponse = await POST(
    `/service/AIEthicsAssessment/AIEthicsImpactAssessments`,
    {
      ...AIEthicsImapactAssessment,
      IsActiveEntity: false,
      HasActiveEntity: false
    },
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );
  const draftId = draftResponse.data.ID;

  // Create GroupedQuestionnaireResponse in draft
  const groupedResponse = await POST(
    `/service/AIEthicsAssessment/AIEthicsImpactAssessments(ID=${draftId},IsActiveEntity=false)/groupedQuestionnaireResponse`,
    {
      questionnaire_ID: QuestionnaireV1.ID,
      IsActiveEntity: false
    },
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );

  const groupedResponseId = groupedResponse.data.ID;

  // Add QuestionnaireResponse entries to the draft
  for (const response of QuestionnaireResponse) {
    await POST(
      `/service/AIEthicsAssessment/AIEthicsImpactAssessments(ID=${draftId},IsActiveEntity=false)/groupedQuestionnaireResponse(ID=${groupedResponseId},IsActiveEntity=false)/questionnaireResponse`,
      {
        ID: uuid(),
        question_ID: response.question_ID,
        responseChoice_ID: response.choices_ID,
        groupedQuestionnaireResponse_ID: groupedResponseId,
        IsActiveEntity: false,
        HasActiveEntity: false
      },
      {
        withCredentials: true,
        auth: { username: "bob", password: "bob" }
      }
    );
  }

  // Act and Assert
  await expect(POST(
    `/service/AIEthicsAssessment/AIEthicsImpactAssessments(ID=${draftId},IsActiveEntity=false)/groupedQuestionnaireResponse(ID=${groupedResponseId},IsActiveEntity=false)/AIEthicsAssessment.calculateIndividualRiskScore`,
    {
      individualRiskQuestionId: ChoicesV1[0].ID,
      scopeChoiceId: ChoicesV1[1].ID,
      scaleChoiceID: ChoicesV1[2].ID,
      likeliHoodChoiceID: ChoicesV1[3].ID,
      remediatbilityChoiceID: ChoicesV1[4].ID,
    },
    {
      withCredentials: true,

      auth: {
        username: "bob",
        password: "bob"
      }
    }
  )
  ).to.be.rejectedWith(400,/High risk framework code is missing for the question, Please check with AI Ethics Office/i);

}

module.exports = { test_calculate_individual_risk_score_success, test_calculate_individual_risk_score_failure };