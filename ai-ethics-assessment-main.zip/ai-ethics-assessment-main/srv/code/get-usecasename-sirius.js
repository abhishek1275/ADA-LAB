/**
 * 
 * @On(event = { "defaultResponsibilityArea" }, entity = "AIEthicsManagementService.ResponsibiltyArea")
 * @param {cds.Request} request
 *  - User information, tenant-specific CDS model, headers and query parameters
*/

const httpclient = require("@sap-cloud-sdk/http-client");
const { error } = require("@sap/cds");
const logger = cds.log('aiethics-sassessment');
module.exports = async function(request) {

     try {
                    
                    const destinationName = 'aiethicsassessment-sirius-api'
                    const pathDeliveryDetails = '/zprs/api/v1/deliveryDetails?deliveryGuid='+request.data.SystemId
                    const userToken = request.user.tokenInfo?.getTokenValue();
                    const getdeliveryDetails = await httpclient.executeHttpRequest(
                        {
                            destinationName: destinationName,
                            jwt: userToken
                        },
                        {
                            method: "GET",
                            url: pathDeliveryDetails ?? "/",
                            headers: {
                                'content-type': 'application/json'
                            }
                        },
                        {
                            fetchCsrfToken: false
                        },
                    );

                    if (!getdeliveryDetails.data || getdeliveryDetails.data.length === 0) {
                        return request.error('No delivery details found in SIRIUS');
                    }

                    const deliveryName= getdeliveryDetails.data[0].DELIVERY_NAME

                    
                    if(!deliveryName){
                      return  request.error('Delivery Name Not Found In SIRIUS');                        
                    }
    
                    return deliveryName;
                               
                }catch (error) {
                    logger.error("Failed to get delivery name from sirius", error);                    
                     return request.error(500,error.message);
    
                }
        
}
