/**
 * It will active the current version of questionnaire and deactivate the all others versions
 * @On(event = { "activate" }, entity = "AIEthicsQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
	const questionnaireId = request.params[0].ID;

	const questionnairedetails = await SELECT.one.from("sapit.acoe.aiea.Questionnaires")
			.where({ ID: questionnaireId});
			
	if(!questionnairedetails.isActive){
		const activeAssessments = await SELECT.from("sapit.acoe.aiea.Questionnaires")
		.columns("ID")
		.where({ questionnairetype_code: questionnairedetails.questionnairetype_code, isActive:true});

		for(const quesId of activeAssessments){
			await UPDATE("sapit.acoe.aiea.Questionnaires").where({
				ID: quesId.ID
			}).set({
				isActive : false
			});
		}
		
		await UPDATE("sapit.acoe.aiea.Questionnaires").where({
			ID: questionnaireId
		}).set({
			isActive : true
		});
		request.notify("Successfully activated this Questionnaire");

	}else{
		request.error(500,"This Questionnaire is already active");
	}

}