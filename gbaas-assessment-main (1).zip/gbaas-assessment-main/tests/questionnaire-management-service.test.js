const test_activateQuestionnaire_logic = require('./code/test-activateQuestionnaire-logic');
const test_submitQuestionnaire_logic = require('./code/test-submitQuestionnaire-logic');
const cds = require('@sap/cds/lib');
const {
  GET,
  POST,
  PATCH,
  DELETE,
  expect
} = cds.test(__dirname + '../../', '--with-mocks');

describe('Test for Questionnaire Management App Testing', () => {
 it('test-questionnaires-management-activate-successlogic', async () => {
    await test_activateQuestionnaire_logic.testQuestionnairesManagementActivateLogicSuccess(GET, POST, PATCH, DELETE, expect);
  });
  it('test-questionnaires-management-activate-failurelogic', async () => {
    await test_activateQuestionnaire_logic.testQuestionnairesManagementActivateLogicFailure(GET, POST, PATCH, DELETE, expect);
  });
  it('test-questionnaire-management-submit-successlogic', async () => {
    await test_submitQuestionnaire_logic.testQuestionnaireSubmissionSuccess(GET, POST, PATCH, DELETE, expect);
  });
  it('test-questionnaire-management-submit-failurelogic', async () => {
    await test_submitQuestionnaire_logic.testQuestionnaireSubmissionFailure(GET, POST, PATCH, DELETE, expect);
  });
});
