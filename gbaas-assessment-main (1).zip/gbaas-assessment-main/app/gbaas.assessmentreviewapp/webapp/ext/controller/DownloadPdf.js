sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        downloadPdf: async function(oEvent) {
            
            const ogroupedQuestion = oEvent.getObject();
            const sPath = oEvent.sPath;
            
           // console.log("=== Download PDF Debug ===");
            //console.log("sPath:", sPath);
            //console.log("ogroupedQuestion:", ogroupedQuestion);
            //console.log("Available properties:", Object.keys(ogroupedQuestion));
            //console.log("formType:", ogroupedQuestion.formType);
            //console.log("version:", ogroupedQuestion.version);
            
            // Use absolute path from root to avoid app path prepending
            const oService = `./service/GbaasReviewService${sPath}/downloadAsPdf()`;
           // console.log("Full service URL:", oService);
            
            try {
                const oResponse = await fetch(oService);
            
                if (!oResponse.ok) {
                    MessageToast.show(`Error: ${oResponse.status} - ${oResponse.statusText}`);
                   // throw new Error(`HTTP error! status: ${oResponse.status}`);
                }
                
                const oResult = await oResponse.json();
                
                const binaryString = oResult.value;
                
                // Build filename from available properties with fallback
                const formType = ogroupedQuestion.formType || ogroupedQuestion.type || 'form';
                const version = ogroupedQuestion.version || ogroupedQuestion.ID || 'download';
               //const formType = ogroupedQuestion.formType;
               // const version = ogroupedQuestion.assessment_ID;
                const fileName = `${formType}_${version}`;
               // console.log("Generated filename:", fileName);
                
                const fileType = "application/pdf";
                const isPreviewOnly = false;
                const byteArray = Uint8Array.from(atob(binaryString), (c) =>
                  c.charCodeAt(0),
                );
                const blob = new Blob([byteArray], { type: fileType });
                const blobUrl = URL.createObjectURL(blob);
                if (isPreviewOnly) {
                  window.open(blobUrl, "_blank");
                } else {
                  const link = document.createElement("a");
                  link.href = blobUrl;
                  link.download = fileName;
                  link.click();
                  URL.revokeObjectURL(blobUrl);
                  
                }
                MessageToast.show("PDF Downloaded Successfully");
            } catch (error) {
                console.error("Download PDF Error:", error);
                MessageToast.show("Failed to download PDF: " + error.message);
            }
          }
        
    };
});
