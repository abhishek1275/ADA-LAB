sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"gbaas/questionnairemanagement/test/integration/pages/QuestionnairesList",
	"gbaas/questionnairemanagement/test/integration/pages/QuestionnairesObjectPage",
	"gbaas/questionnairemanagement/test/integration/pages/QuestionsObjectPage"
], function (JourneyRunner, QuestionnairesList, QuestionnairesObjectPage, QuestionsObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('gbaas/questionnairemanagement') + '/test/flpSandbox.html#gbaasquestionnairemanagement-tile',
        pages: {
			onTheQuestionnairesList: QuestionnairesList,
			onTheQuestionnairesObjectPage: QuestionnairesObjectPage,
			onTheQuestionsObjectPage: QuestionsObjectPage
        },
        async: true
    });

    return runner;
});

