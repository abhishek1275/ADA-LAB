const { error } = require("@sap/cds");
const { update } = require("@sap/cds");
const { string } = require("@sap/cds/lib/core/classes");

/**
 *
 * @On(event = { "calculateIndividualRiskScore" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
 * @param {Function} next - Callback function to the next handler
 * 
*/
module.exports = async function (request) {
    {
        const assessmentdraftuuid = request.params[0].ID;
        const { scopeChoiceId, remediatbilityChoiceID, likeliHoodChoiceID, scaleChoiceID, individualRiskQuestionId } = request.data;

        const scopeScore = await SELECT.one.from("sapit.acoe.aiea.Choices")
            .where({ ID: scopeChoiceId });
        const RemediatbilityScore = await SELECT.one.from("sapit.acoe.aiea.Choices")
            .where({ ID: remediatbilityChoiceID });
        const LikeliHoodScore = await SELECT.one.from("sapit.acoe.aiea.Choices")
            .where({ ID: likeliHoodChoiceID });
        const ScaleScore = await SELECT.one.from("sapit.acoe.aiea.Choices")
            .where({ ID: scaleChoiceID });

        const individualRiskChoice = await SELECT.one.from("sapit.acoe.aiea.Choices")
            .where({ ID: individualRiskQuestionId });

        const individualRiskQuestion = await SELECT.one.from("sapit.acoe.aiea.Questions")
            .where({ ID: individualRiskChoice.question_ID });

        const questionText = individualRiskQuestion.highRiskFramework_code;

        if(questionText == null || questionText == undefined){
            request.error(400, "High risk framework code is missing for the question, Please check with AI Ethics Office");
        }

        let individualRiskScore = null;
        let updatedScore = null;
        if (scopeScore && RemediatbilityScore && LikeliHoodScore && ScaleScore) {
            individualRiskScore = parseFloat(scopeScore.high_risk_score) + parseFloat(ScaleScore.high_risk_score) + parseFloat(RemediatbilityScore.high_risk_score) * parseFloat(LikeliHoodScore.high_risk_score);
            individualRiskScore = individualRiskScore.toFixed(2);
        }

        if (questionText == "Processing personal data") {
            {
                await UPDATE('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid })
                    .set({
                        processingPersonalDataRiskScore: individualRiskScore
                    });

                updatedScore = await SELECT.one.columns('processingPersonalDataRiskScore')
                    .from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid });
            }
        }

        if (questionText == 'Automated decision-making') {
            {
                await UPDATE('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid })
                    .set({
                        automatedDecisionMakingRiskScore: individualRiskScore
                    });
                updatedScore = await SELECT.one.columns('automatedDecisionMakingRiskScore')
                    .from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid });
            }
        }

        if (questionText == "Consequence on people") {
            {
                await UPDATE('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid })
                    .set({
                        consequenceOnPeopleRiskScore: individualRiskScore
                    });

                updatedScore = await SELECT.one.columns('consequenceOnPeopleRiskScore')
                    .from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid });
            }
        }

        if (questionText == "High-risk sectors") {
            {
                await UPDATE('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid })
                    .set({
                        highRiskSectorRiskScore: individualRiskScore
                    });
                updatedScore = await SELECT.one.columns('highRiskSectorRiskScore')
                    .from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                    .where({ ID: assessmentdraftuuid });
            }
        }

        return updatedScore;
    }

}