/**
 * It will send the notification
 * @After(event = { "assign" }, entity = "GbaasReviewService.Assessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

const path = require('path');
const MailSender = require("../email/MailSender");

module.exports = async function(results, request) {
	try {
        const employeeDataService = await cds.connect.to("employee_data");
        const { Employees } = employeeDataService.entities;
		const assessmentID = request.params[0].ID;
        const targetPath = path.join(__dirname, "..", "email/", "images");

        // Get assessment details
        const assessmentDetails = await SELECT.one.from("sapit.acoe.gbaas.Assessments").where({ ID: assessmentID });
        
        if (!assessmentDetails) {
            console.error("Assessment not found:", assessmentID);
            return;
        }

        const processorID = assessmentDetails.processor;
        const requestNumber = assessmentDetails.sourceSystemID || assessmentID;
        const nameOfUsecase = assessmentDetails.name;
        const sourceSystem = assessmentDetails.sourceSystem || 'N/A';

        // Get use case owner info
        const processorInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: processorID }));
        
        if (!processorInfo || !processorInfo.email) {
            console.error("Use case owner not found or no email:", processorID);
            return;
        }

        // Get delegates who want to be notified
        const delegateDetails = await SELECT.from("sapit.acoe.gbaas.AssessmentsDelegates").columns("userID")
            .where({ assessments_ID: assessmentID, toBeNotified: true });
        const delegateEmails = [];
        for (const delegate of delegateDetails) {
            const delegateUserInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: delegate.userID }));
            if (delegateUserInfo && delegateUserInfo.email) {
                delegateEmails.push(delegateUserInfo.email);
            }
        }

        const toMailList = delegateEmails.length > 0 ? [processorInfo.email, ...delegateEmails] : [processorInfo.email];
        const ccList = "";

        const assessmentUrl = request && request.headers && request.headers.referer 
            ? `${request.headers.referer}#/Assessments(ID=${assessmentID},IsActiveEntity=true)`
            : `#/Assessments(ID=${assessmentID},IsActiveEntity=true)`;

        const attachments = [
            {
                filename: "sap-logo.png",
                cid: "sap-logo",
                path: targetPath + "/sap-logo.png",
            },
            {
                filename: "Gbaas_img.png",
                cid: "center-image",
                path: targetPath + "/Gbaas_img.png",
            }
        ];

        const subject = "GBAAS Assessment Review is Assigned To You - " + nameOfUsecase;
        const bodycontent = "Your GBAAS assessment has been successfully Assigned to you.";
        const belowBody = `You can view your assessment <a href="${assessmentUrl}">here</a>. If you have any questions, please contact the GBAAS Office.`;
        const status = "ASSIGNED";

        await MailSender.getInstance().send(toMailList, ccList, subject, "status_notification_template", {
            bodycontent: bodycontent,
            name: processorInfo.firstName,
            requestNumber: requestNumber,
            nameOfUsecase: nameOfUsecase,
            status: status,
            sourceSystem: sourceSystem,
            belowBody: belowBody
        }, attachments);

    } catch (error) {
        console.error("Failed to send mark as completed email:", error);
    }
}