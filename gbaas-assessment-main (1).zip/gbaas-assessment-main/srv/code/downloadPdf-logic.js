/**
 * 
 * @On(event = { "downloadAsPdf" }, entity = "GbaasAssessment.Forms")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

const PDFDocument = require('pdfkit');
const { PassThrough } = require("stream");
const { Readable } = require('stream');
module.exports = async function (request) {

	let form;
	
	
	let requestID;
	
	// Try to extract form ID from different parameter positions
	if (request.params && request.params.length > 0) {
		// Check params[1] first (for navigation paths like Assessments(...)/forms(...))
		if (request.params[1] && typeof request.params[1] === 'object' && request.params[1].ID) {
			requestID = request.params[1].ID;
		} else if (request.params[1] && typeof request.params[1] === 'string') {
			requestID = request.params[1];
		}
		// Then check params[0]
		else if (request.params[0] && typeof request.params[0] === 'object' && request.params[0].ID) {
			requestID = request.params[0].ID;
		} else if (request.params[0] && typeof request.params[0] === 'string') {
			requestID = request.params[0];
		}
	}
	
	// Fallback to request.data
	if (!requestID && request.data && request.data.ID) {
		requestID = request.data.ID;
	}
	
	//console.log("Extracted Form ID:", requestID);
	
	if (!requestID) {
		throw new Error('Form ID is required');
	}
	
	form = await SELECT.one.from('sapit.acoe.gbaas.Forms').where({ ID: requestID });
	
	if (!form) {
		throw new Error('Form not found');
	}

	const {
		assessment_ID,
		questionnaire_ID,
		formType,
		status_code
	} = form;

	const assessmentDetails = await SELECT.one.from('sapit.acoe.gbaas.Assessments')
								.where({ ID: form.assessment_ID });
	
	if (!assessmentDetails) {
		throw new Error('Assessment not found');
	}
	
	const {
		ID,
		useCaseclassification_code,
		name,
		sourceSystem,
		sourceSystemID,
		responsibilityArea,
		statusCode_code,
		createdAt,
		createdBy,
		modifiedAt,
		modifiedBy
	} = assessmentDetails;

	const questionnaire = await SELECT.one.from('sapit.acoe.gbaas.Questionnaires')
							.where({ ID: questionnaire_ID });
	
	const questionnaireType = questionnaire?.questionnairetype || formType;
	
	const questionnaireResponse = await SELECT.from('sapit.acoe.gbaas.QuestionnaireResponses')
									.where({ form_ID: form.ID })
									.orderBy('question_questionNumber');
	
	// Create a PDF document
	const doc = new PDFDocument();
	const passthroughStream = new PassThrough();

	doc.pipe(passthroughStream);
	doc.image('./srv/templates/sap-logo.png', 400, 50, { fit: [150, 150], align: 'left', valign: 'top' });
	doc.image('./srv/templates/CentreLogo.png', 60, 97, { fit: [500, 450], align: 'center', valign: 'top' });

	doc.fillColor('white');
	doc
		.font("Helvetica-Bold")
		.fontSize(15)
		.moveDown(6)
		.text(`GBAAS ${questionnaireType} Form`, {
			align: 'left',
			underline: false,
		});

	doc.addNamedDestination(`top`);

	// Assessment details
	doc.fillColor('black');
	doc.fontSize(15)
		.font('Helvetica')
		.moveDown(7)
		.text(`General Information`);

	doc.fontSize(10)
		.font('Helvetica')

	const topY = doc.y;
	const topPage = doc.page;

	let pdfText = `Use Case Name: ${assessmentDetails.name} \n\nAssessment ID: ${assessmentDetails.ID}\n\nStatus: ${assessmentDetails.statusCode_code || 'N/A'}\n\nClassification: ${assessmentDetails.useCaseclassification_code || 'N/A'}\n\nSource System: ${assessmentDetails.sourceSystem}\n\nSource System ID: ${assessmentDetails.sourceSystemID}\n\nResponsibility Area: ${assessmentDetails.responsibilityArea}\n\nForm Type: ${formType}`;
   // console.log("PDF Text Content:", pdfText);
	doc
		.moveDown(1)
		.text(pdfText);

	doc.fontSize(15)
		.font('Helvetica')
		.moveDown(1)
		.text(`${questionnaireType} Response Summary`)

	doc.fontSize(10)
		.font('Helvetica')

	let responseTable = [];

	await Promise.all(questionnaireResponse.map(item => formatcontent(item)));

	async function formatcontent(item) {
		const question = await SELECT.one.from('sapit.acoe.gbaas.Questions')
										.where({ questionNumber: item.question_questionNumber });
		
		if (!question) return;
		
		let responseText = '';
		if (item.responseText) {
			responseText = "\nAnswer: " + item.responseText;
		}
		
		if (item.comment) {
			responseText += "\nComment: " + item.comment;
		}
		
		responseTable.push(question.questionNumber + ") " + question.questionText + responseText);
	}

	doc.moveDown(1)

	responseTable.forEach((item, index) => {
		doc
			.text(item);
		doc.moveDown();
	})

	doc.fontSize(12)
		.font('Helvetica')
		.moveDown(1)
		.text(`Best Regards \n\nGBAAS Team`);

	doc
		.fontSize(8)
		.fillColor('black')
		.text('Back to top', 500, doc.y + 20, {
			link: '#top',
			underline: true
		});

	doc
		.moveDown(1)
		.lineWidth(3)
		.moveTo(50, doc.y)
		.lineTo(550, doc.y)
		.stroke();

	const pageHeight = doc.page.height;
	const pageWidth = doc.page.width;
	const margin = 405;
	const baseY = doc.y + 10;
	let baseX = margin;

	doc.fontSize(7);

	const footerlinks = [
		{ label: 'Copyright/Trademark', link: 'https://www.sap.com/about/legal/copyright.html' },
		{ label: 'Privacy', link: 'https://www.sap.com/about/legal/privacy.html' },
		{ label: 'Impressum', link: 'https://www.sap.com/about/legal/impressum.html' }];

	footerlinks.forEach((item, i) => {
		doc.text(item.label, baseX, baseY, { link: item.link, underline: false });
		baseX += doc.widthOfString(item.label + ' | ');
		if (i < footerlinks.length - 1) {
			doc.fillColor('black').text(' | ', baseX - doc.widthOfString(' | '), baseY);
			doc.fillColor('black');
		}
	});

	doc.fontSize(6).fillColor('black')
		.moveDown(1)
		.text(`SAP SE, Dietmar-Hopp-Allee 16, 69190 Walldorf, Germany`, 50);

	doc.fontSize(6).fillColor('black')
		.moveTo(100, doc.y)
		.moveDown(2)
		.text(`Pflichtangaben/Mandatory Disclosure Statements: http://www.sap.com/about/legal/impressum.html
Diese E-Mail kann Betriebs- oder Geschäftsgeheimnisse oder sonstige vertrauliche Informationen enthalten. Sollten Sie diese E-Mail 
irrtümlich erhalten haben, ist Ihnen eine Kenntnisnahme des Inhalts, eine Vervielfältigung oder Weitergabe der E-Mail ausdrücklich untersagt. 
Bitte benachrichtigen Sie uns und vernichten Sie die empfangene E-Mail. Vielen Dank.`, 50);

	doc.fontSize(6).fillColor('black')
		.moveTo(100, doc.y)
		.moveDown(2)
		.text(`This e-mail may contain trade secrets or privileged, undisclosed, or otherwise confidential information. If you have received this e-mail in 
error, you are hereby notified that any review, copying, or distribution of it is strictly prohibited. Please inform us immediately and destroy the 
original transmittal. Thank you for your cooperation.`, 50);

	doc.end();

	//converting stream to Buffer
	const readableStream = Readable.from(passthroughStream);
	function streamToBuffer(readableStream) {
		return new Promise((resolve, reject) => {
			const buf = [];
			readableStream.on("data", (chunk) => buf.push(chunk));
			readableStream.on("end", () => resolve(Buffer.concat(buf)));
			readableStream.on("error", (err) => reject(err));
		});
	}
	let myBuffer;
	await streamToBuffer(readableStream)
		.then((buffer) => {
			myBuffer = buffer;
		})
		.catch((err) => {
			console.error(err);
		});

	return myBuffer.toString("base64");
}