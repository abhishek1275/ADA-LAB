/**
 * It will update the status
 * @After(event = { "CREATE","UPDATE" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function (results, request) {

	const aieID = results.params[0].ID;

		const aieDetails = await SELECT.one.from("sapit.acoe.aiea.AIEthicsImpactAssessments")
			.where({ ID: aieID });

	if (aieDetails.status_code == "Ready To Submit") {
			await UPDATE("sapit.acoe.aiea.AIEthicsImpactAssessments").where({
				ID: aieID
			}).set({
				status_code: 'Submitted'
			});
		}
}