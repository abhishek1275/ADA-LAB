/**
 * 
 * @Before(event = { "CREATE","UPDATE" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
	const diff = await request.diff();
	const modifiedgroupedQuestionnaireforSIRIUSorHYCOM = [];
	const updatedQRIds = [];
	const newGQR =[];

	if(diff.groupedQuestionnaireResponse && request.data.sourceSystem =='SIRIUS'){
		const groupedQuestionnaireResponsesmodified=diff.groupedQuestionnaireResponse;
			groupedQuestionnaireResponsesmodified.forEach(groupedQuestionnaireResponse => {
			groupedQuestionnaireResponse.Status_code == 'Done'?modifiedgroupedQuestionnaireforSIRIUSorHYCOM.push(groupedQuestionnaireResponse.ID):"";
		});

		request.data.sendToSirius = modifiedgroupedQuestionnaireforSIRIUSorHYCOM;
	}
	if(diff.groupedQuestionnaireResponse && request.data.sourceSystem =='HYCOM'){
		const groupedQuestionnaireResponsesmodified=diff.groupedQuestionnaireResponse;
			groupedQuestionnaireResponsesmodified.forEach(groupedQuestionnaireResponse => {
			groupedQuestionnaireResponse.Status_code == 'Done'?modifiedgroupedQuestionnaireforSIRIUSorHYCOM.push(groupedQuestionnaireResponse.ID):"";
		});

		request.data.sendToHyCom = modifiedgroupedQuestionnaireforSIRIUSorHYCOM;
	}

	// For mail notifications & version
	if(diff.groupedQuestionnaireResponse){

		//collect Ids for new grouped Questionnaire Responses
        diff.groupedQuestionnaireResponse.forEach(res => {
            if(res._op =="create"){
                newGQR.push(res.ID);
				request.data.newGQR = newGQR;
            }
        });
	

		//finds the grouped questionaire ID for submitted status
		diff.groupedQuestionnaireResponse.forEach(response => { 
			response.Status_code == 'Done'?updatedQRIds.push(response.ID):""});
			
		request.data.updatedQRIds = updatedQRIds;

		if(diff.status_code == 'Done'){
			request.data.impactassessmentNotify = true;
		}
	}
}