/**
 * 
 * @On(event = { "READ" }, entity = "AIEthicsAssessment.ResponsibilityAreas")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
 * @param {Function} next - Callback function to the next handler
 * 
*/
const httpclient = require("@sap-cloud-sdk/http-client");

module.exports = async function (request, next) {
    try {
        const destinationName = 'aiethicsassessment-sirius-api';
        const path = '/zorg/v1/hierarchyList?selectionMode=selectable&process=prog_mgmt_relevant';
        const userToken = request.user.tokenInfo?.getTokenValue();

        const getResponsibilityArea = await httpclient.executeHttpRequest(
            {
                destinationName: destinationName,
                jwt: userToken
            },
            {
                method: "GET",
                url: path ?? "/",
                headers: {
                    'content-type': 'application/json'
                }
            },
            {
                fetchCsrfToken: false
            },
        );

        // Log the raw API response for debugging
       // console.log("API Response:", getResponsibilityArea.data);

        // Fetch and sort data
        const data = getResponsibilityArea.data?.data || []; // Default to an empty array if no data is returned
        const sortedData = data.slice().sort((a, b) =>
            String(a.name).localeCompare(String(b.name))
        );

        // Extract and clean up the $search parameter
        const search = request.req.query.$search?.replace(/['"]/g, "") || "";
       // console.log("Search term:", search); // Debugging: Log the cleaned search term

        // Apply search filter
        const filteredData = search
            ? sortedData.filter(item => item.name && item.name.toLowerCase().includes(search.toLowerCase()))
            : sortedData;

        // Map the filtered data
        return filteredData.map(item => ({
            Name: item.name
        }));

    } catch (error) {
        request.notify({
            message: 'Error Occurred while loading Responsibility Area',
            numericSeverity: 4
        });
       // console.error("Error in getResponsibilityareas_Logic:", error); // Log the error for debugging
    }
    return [];
};