sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'aiethicsassessment/aiethicsassessmentapp/test/integration/FirstJourney',
		'aiethicsassessment/aiethicsassessmentapp/test/integration/pages/AIEthicsImpactAssessmentsList',
		'aiethicsassessment/aiethicsassessmentapp/test/integration/pages/AIEthicsImpactAssessmentsObjectPage'
    ],
    function(JourneyRunner, opaJourney, AIEthicsImpactAssessmentsList, AIEthicsImpactAssessmentsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('aiethicsassessment/aiethicsassessmentapp') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheAIEthicsImpactAssessmentsList: AIEthicsImpactAssessmentsList,
					onTheAIEthicsImpactAssessmentsObjectPage: AIEthicsImpactAssessmentsObjectPage
                }
            },
            opaJourney.run
        );
    }
);