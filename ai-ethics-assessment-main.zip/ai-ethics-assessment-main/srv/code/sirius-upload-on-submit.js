/**
 * 
 * @After(event = { "CREATE","UPDATE" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

const upload_Pdf_To_Sirius_Logic = require('../code/upload-pdf-to-sirius-logic');
const upload_Pdf_To_HyCom_Logic = require('../code/upload-pdf-to-hycom-logic');
module.exports = async function (results, request) {


	const groupedQuestionnaireResponses = request.data.sendToSirius || request.data.sendToHyCom;
	const Outputs = []

	for (const groupedQuestionnaireResponse of groupedQuestionnaireResponses) {
		const GroupId = groupedQuestionnaireResponse;
		request.GroupId = GroupId;
		if (request.data.sendToSirius) {
			const result = await upload_Pdf_To_Sirius_Logic(request);
			Outputs.push(result);

		}
		if (request.data.sendToHyCom) {
			const result = await upload_Pdf_To_HyCom_Logic(request);
			Outputs.push(result);
		}

		console.log("Uploaded for Group ID:", GroupId);
	}
	console.log("All uploads completed", Outputs);
}