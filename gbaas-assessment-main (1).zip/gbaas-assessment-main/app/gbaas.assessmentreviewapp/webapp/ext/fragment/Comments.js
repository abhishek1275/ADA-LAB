sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        /**
         * Generated event handler.
         *
         * @param oEvent the event object provided by the event provider.
         */
         fnOnCommentPost: async function(oEvent) {

            let sComment = oEvent.getSource().getValue();
            let sPath = oEvent.getSource().getBindingContext().getPath() + "/comments";
           
            const oListView = this.routing.getView().byId("gbaas.assessmentreviewapp::AssessmentsObjectPage--fe::CustomSubSection::Comments--idCommentsList");
            if(oListView){oListView.setBusy(true)};
            
            //create the comment
            const oModel = oEvent.getSource().getModel();
            let oBindList = oModel.bindList(sPath);
            const oNewMsg = oBindList.create({"comment":sComment});
            await oNewMsg.created();
            oModel.refresh();


            if(oListView){oListView.setBusy(false)};

        }//end of fnOnCommentPost
    };
});