const { render } = require("ejs");
const { join } = require("path");
const { sendMail } = require("@sap-cloud-sdk/mail-client"); 
const { readFile } = require("fs/promises");
const cds = require("@sap/cds");

class MailSender {
  static getInstance() {
    const useCFImplementation = process.env.NODE_ENV === "production" || cds.env.profiles.includes("hybrid");
    return useCFImplementation ? new CFMailSender() : new LocalMailSender();
  }
}
class CFMailSender {
    #logger = cds.log("Mail");
    async send(to,cc, subject, template, data,attachments) {
      const templateContent = await readFile(join(__dirname, "templates", `${template}.ejs`), "utf-8");
      try {
        await sendMail({ destinationName: "smtp" }, [{
          from: "noreply+AIEthicsAssessmentApp@sap.corp",
          to,
          cc,
          subject,
          html: render(templateContent, data),
          attachments 
        }]);
        this.#logger.info("Mail sent successfully.", to, subject, data);
      } catch (err) {
        this.#logger.error("Sending mail failed", err);
      }
    }
  }
  class LocalMailSender {
    #logger = cds.log("LocalMailManager");
    async send(to,cc, subject, data,attachments) {
      this.#logger.info("Mail not sent because the server is not in production mode.", to,cc, subject, data,attachments); 
    }
  }

  module.exports = MailSender;