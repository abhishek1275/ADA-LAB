const test_aiethics_assessment_send_for_review = require('./code/test-aiethics-assessment-send-for-review');
const test_calculate_individual_risk_score = require('./code/test-calculate-individual-risk-score-logic');
const test_calculate_overall_risk_score = require('./code/test-calculate-overall-risk-score-logic');
const cds = require('@sap/cds/lib');
const {
  GET,
  POST,
  PATCH,
  DELETE,
  expect
} = cds.test(__dirname + '../../', '--with-mocks');

describe('AIEthics Assessment Service Testing', () => {
  it('test aiethics-assessment-send-for-review', async () => {
    await test_aiethics_assessment_send_for_review(GET, POST, PATCH, DELETE, expect);
  });

 it('test calculate-individual-risk-score-logic', async () => {
    await test_calculate_individual_risk_score.test_calculate_individual_risk_score_success(GET, POST, PATCH, DELETE, expect);
  });
  it('test calculate-individual-risk-score-logic', async () => {
    await test_calculate_individual_risk_score.test_calculate_individual_risk_score_failure(GET, POST, PATCH, DELETE, expect);
  });
   it('test calculate-overall-risk-score-logic', async () => {
    await test_calculate_overall_risk_score.test_calculate_overall_risk_score_success(GET, POST, PATCH, DELETE, expect);
  });
});