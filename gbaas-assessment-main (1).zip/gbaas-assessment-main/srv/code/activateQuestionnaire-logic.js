/**
 * @On(event = { "activate" }, entity = "GbaasQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
try{
	const questionnaireId = request?.params[0]?.ID;

	const questionnairedetails = await SELECT.one.from("sapit.acoe.gbaas.Questionnaires")
			.where({ ID: questionnaireId});
			
	if(!questionnairedetails.isActive) {

		await UPDATE("sapit.acoe.gbaas.Questionnaires").where({
                questionnaireTypeCode: questionnairedetails.questionnaireTypeCode_code, isActive:true
            }).set({
                isActive : false
            });

		await UPDATE("sapit.acoe.gbaas.Questionnaires").where({
			ID: questionnaireId
		}).set({
			isActive : true
		});
		request.notify("Successfully activated this Questionnaire");

	} else {
		request.notify("This Questionnaire is already active");
	}
} catch (error)
{
	console.error("Activation Error:", error);
    request.error(500,`Error while activating questionnaire: ${error.message}`);
}
}