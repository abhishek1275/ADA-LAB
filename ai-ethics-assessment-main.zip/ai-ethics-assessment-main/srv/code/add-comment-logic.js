/**
 * 
 * @On(event = { "LinkDependentQuestion" }, entity = "AIEthicsQuestionnaireManagement.Questions")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {

const { AssessmentID, Comment } = request.data;

const aieID = request.params[0].ID;

        if (!AssessmentID || !Comment) {
            req.error(400, 'Both AssessmentID and Comment are required.');
        }

      const comment=  {
                groupedQuestionnaireResponse_ID: AssessmentID,
                comment: Comment,
                useCase_ID: aieID
            }

        

	//Update the comments
	const result=await INSERT.into("sapit.acoe.aiea.Comments").entries(comment);

        if (result) {
            return `Comment added to Assessment ID ${AssessmentID}`;
        } else {
            req.error(500, 'Failed to add comment.');
        }

}