/**
 * 
 * @On(event = { "CREATE" }, entity = "AIEthicsQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
 * @param {Function} next - Callback function to the next handler
*/
module.exports = async function(request, next) {
	const type = request.data.questionnairetype_code;
	const questionnaire = await SELECT.one.from("sapit.acoe.aiea.Questionnaires")
								.columns("version")
								.where({ questionnairetype_code : type})
								.orderBy({version: "desc"});
	if(questionnaire){
		const version = questionnaire.version;
		const newVersion = "v" + (parseInt(version.slice(1)) + 1);
		request.data.version = newVersion;
	}else{
		const newVersion = "v1";
		request.data.version = newVersion;
	}
	
	return next();
}