/**
 * It finds the modified data
 * @Before(event = { "CREATE","UPDATE" }, entity = "AIEthicsManagementService.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
	const diff = await request.diff();

	if (diff.status_code){
		request.data.statusChange = true;
	}

	if(diff.useCaseclassification_code){
		request.data.useCaseclassificationChange = true;
		request.data.useCaseclassificationPrevious = diff._old.useCaseclassification_code;
		request.data.useCaseclassificationPresent = diff.useCaseclassification_code;
	}

}