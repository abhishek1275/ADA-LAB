

/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;

async function adddependentquestionanswerSucceed(GET, POST, PATCH, DELETE, expect) {

  //Arrange
 const Questionnaire = {
  ID : uuid(),
  version :'1.0',
  isActive : true
 }

   await INSERT.into('sapit.acoe.aiea.Questionnaires').entries(Questionnaire);
  
   const question1 ={
    ID : uuid(),
    questionNumber : '1',    
    questionText :'Test Q1',
    questionID :'QA1',
    questionnaire_ID: Questionnaire.ID,
  }
  const question2 ={
    ID: uuid(),
    questionNumber: 2,    
    questionText :'Test Q2',
    questionID :'QA2',
    questionnaire_ID: Questionnaire.ID
  }
 await INSERT.into('sapit.acoe.aiea.Questions').entries(question1,question2);
  
  const choice1={
    ID: uuid(),
    question_ID: question1.ID,
    sequence: 1,
    text: 'Choice A'
  }

  const choice2={
    ID: uuid(),
    question_ID: question1.ID,
    sequence: 1,
    text: 'Choice B'
  }

  await INSERT.into('sapit.acoe.aiea.Choices').entries(choice1,choice2);
  // Act
  await POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires(ID=${question2.questionnaire_ID},IsActiveEntity=true)/questions(ID=${question2.ID},IsActiveEntity=true)/AIEthicsQuestionnaireManagement.LinkDependentQuestion`,
    {"dependentQuestionAnswer":choice1.ID},
    {
      withCredentials: true,
      auth: { username: "user", password: "user" },
    }
  );

  // Assert
  const linkQuestionRecord = await SELECT.one.from('sapit.acoe.aiea.DependentQuestionAnswer').where(
		{ question_ID : question2.ID, choices_ID : choice1.ID}
	);
    expect(linkQuestionRecord.question_ID).to.equal(question2.ID);
    expect(linkQuestionRecord.choice_ID).to.equal(question1.choice_ID);
}

async function adddependentquestionanswerFailure(GET, POST, PATCH, DELETE, expect) {

  //Arrange
 const Questionnaire = {
  ID : uuid(),
  version :'1.0',
  isActive : true
 }

   await INSERT.into('sapit.acoe.aiea.Questionnaires').entries(Questionnaire);
  
   const question1 ={
    ID : uuid(),
    questionNumber : '1',    
    questionText :'Test Q1',
    questionID :'QA1',
    questionnaire_ID: Questionnaire.ID,
  }
  const question2 ={
    ID: uuid(),
    questionNumber: 2,    
    questionText :'Test Q2',
    questionID :'QA2',
    questionnaire_ID: Questionnaire.ID
  }
 await INSERT.into('sapit.acoe.aiea.Questions').entries(question1,question2);
  
  const choice1={
    ID: uuid(),
    question_ID: question1.ID,
    sequence: 1,
    text: 'Choice A'
  }

  const choice2={
    ID: uuid(),
    question_ID: question1.ID,
    sequence: 1,
    text: 'Choice B'
  }
    
  await INSERT.into('sapit.acoe.aiea.Choices').entries(choice1,choice2);

  const dependentQnA ={
    question_ID: question2.ID,
    choices_ID: choice1.ID
  }

  await INSERT.into('sapit.acoe.aiea.DependentQuestionAnswer').entries(dependentQnA);
  // Act and Assert
  await expect(
    POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires(ID=${question2.questionnaire_ID},IsActiveEntity=true)/questions(ID=${question2.ID},IsActiveEntity=true)/AIEthicsQuestionnaireManagement.LinkDependentQuestion`,
    {"dependentQuestionAnswer":choice1.ID},
    {
      withCredentials: true,
      auth: { username: "user", password: "user" },
    }
  )
).to.be.rejectedWith(500, /Dependent Question and answer already exists for this Question/i);
}

module.exports = { adddependentquestionanswerSucceed,adddependentquestionanswerFailure };