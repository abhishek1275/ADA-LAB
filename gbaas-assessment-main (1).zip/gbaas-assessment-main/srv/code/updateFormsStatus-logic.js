/**
 * 
 * @Before(event = { "CREATE" }, entity = "GbaasQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

module.exports = async function(request) {
	try{
		const {formId, sStatus} = request.data;
		await UPDATE("sapit.acoe.gbaas.Forms").where({ID: formId}).set({status_code: sStatus});
		request.notify("Form is "+sStatus);
		
	}catch(oError){request.error(500, `Failed to assign: ${oError.message}`);}
	
}