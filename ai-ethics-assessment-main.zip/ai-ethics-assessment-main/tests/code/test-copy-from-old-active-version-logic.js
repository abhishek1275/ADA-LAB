

/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;
async function testCopyFromOldActiveVersionSuccess(GET, POST, PATCH, DELETE, expect) {

  //Arrange
  const QuestionnaireV1 = {
    ID: uuid(),
    version: 'v3',
    questionnairetype_code: 'Usecase Impact Assessment',
    isActive: true,
    submitted: true,
    email: 'test@example.com',
    individualRiskScoreFormula: 'scope + scale + remediation * likelihood',
    overAllRiskScoreFormula: 'sum(individualScores) / count',
    createdAt: new Date(),
    createdBy: 'admin',
    modifiedAt: new Date(),
    modifiedBy: 'admin'
  }

  const section1 = {
    ID: uuid(),
    text: 'General Section'
  };

  const QuestionsV1 = [
    {
      ID: uuid(),
      questionNumber: 1,
      questionText: 'What is the scope of your AI system?',
      questionID: 'Q1',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Define the operational scope',
      examples: 'Internal use, External use',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      questionNumber: 2,
      questionText: 'What is the likelihood of risk?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Assess risk probability',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];
  const ChoicesV1 = [
    {
      ID: uuid(),
      text: 'High Scope',
      question_ID: QuestionsV1[0].ID,
      sequence: 1,
      explanation_required: false,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'Low Scope',
      question_ID: QuestionsV1[0].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    },
    {
      ID: uuid(),
      text: 'High Likelihood',
      question_ID: QuestionsV1[1].ID,
      sequence: 1,
      explanation_required: true,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'Low Likelihood',
      question_ID: QuestionsV1[1].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    }
  ];

  const DependentAnswersV1 = [
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[0].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[1].ID,
      choices_ID: ChoicesV1[2].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];

  // Insert test data
  await INSERT.into('sapit.acoe.aiea.Sections').entries(section1);
  await INSERT.into('sapit.acoe.aiea.Questionnaires').entries(QuestionnaireV1);
  await INSERT.into('sapit.acoe.aiea.Questions').entries(QuestionsV1);
  await INSERT.into('sapit.acoe.aiea.Choices').entries(ChoicesV1);
  await INSERT.into('sapit.acoe.aiea.DependentQuestionAnswer').entries(DependentAnswersV1);

  // Create new draft questionnaire

  const draftResponse = await POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires`,
    {
      questionnairetype_code: 'Usecase Impact Assessment',
      version: '2.0'
    },
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );

  const draftId = draftResponse.data.ID;

  // Act

  const response = await POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires(ID=${draftId},IsActiveEntity=false)/AIEthicsQuestionnaireManagement.copyfromOldVersion`,
    {},
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );


  // Assert

  // Verify the data was actually copied 
  const copiedQuestions = await SELECT
    .from('AIEthicsQuestionnaireManagement.Questions.drafts')
    .where({ questionnaire_ID: draftId })
    .orderBy('questionNumber asc');

  expect(copiedQuestions).to.be.an('array').that.has.lengthOf(2);
  expect(copiedQuestions[0]).to.include({
    questionNumber: 1,
    questionText: 'What is the scope of your AI system?',
    questionID: 'Q1',
    isRequired: true
  });
  expect(copiedQuestions[1]).to.include({
    questionNumber: 2,
    questionText: 'What is the likelihood of risk?',
    questionID: 'Q2',
    isRequired: true
  });

  // Verify choices were copied
  const questionIds = copiedQuestions.map(q => q.ID);
  const copiedChoices = await SELECT
    .from('AIEthicsQuestionnaireManagement.Choices.drafts')
    .where({ question_ID: { in: questionIds } })
    .orderBy('sequence asc');

  expect(copiedChoices).to.be.an('array').that.has.lengthOf(4);

  // Verify dependent answers were copied
  const copiedDependentAnswers = await SELECT
    .from('AIEthicsQuestionnaireManagement.DependentQuestionAnswer.drafts')
    .where({ question_ID: { in: questionIds } });

  expect(copiedDependentAnswers).to.be.an('array').that.has.lengthOf(2);

  // Verify questionnaire metadata was updated
  const updatedQuestionnaire = await SELECT.one
    .from('AIEthicsQuestionnaireManagement.Questionnaires.drafts')
    .where({ ID: draftId });

  expect(updatedQuestionnaire.email).to.equal('test@example.com');
  expect(updatedQuestionnaire.individualRiskScoreFormula).to.equal('scope + scale + remediation * likelihood');

  // Check if version was incremented
  expect(updatedQuestionnaire.version).to.equal('2.0');

}

async function testCopyFromOldActiveVersionFailure(GET, POST, PATCH, DELETE, expect) {

  //Arrange
  const QuestionnaireV1 = {
    ID: uuid(),
    version: 'v3',
    questionnairetype_code: 'Usecase Impact Assessment',
    isActive: true,
    submitted: true,
    email: 'test@example.com',
    individualRiskScoreFormula: 'scope + scale + remediation * likelihood',
    overAllRiskScoreFormula: 'sum(individualScores) / count',
    createdAt: new Date(),
    createdBy: 'admin',
    modifiedAt: new Date(),
    modifiedBy: 'admin'
  }

  const section1 = {
    ID: uuid(),
    text: 'General Section'
  };

  const QuestionsV1 = [
    {
      ID: uuid(),
      questionNumber: 1,
      questionText: 'What is the scope of your AI system?',
      questionID: 'Q1',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Define the operational scope',
      examples: 'Internal use, External use',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      questionNumber: 2,
      questionText: 'What is the likelihood of risk?',
      questionID: 'Q2',
      responseType_code: 'CHOICE',
      section_ID: section1.ID,
      questionnaire_ID: QuestionnaireV1.ID,
      isRequired: true,
      policyDescription: 'Assess risk probability',
      examples: 'High, Medium, Low',
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];
  const ChoicesV1 = [
    {
      ID: uuid(),
      text: 'High Scope',
      question_ID: QuestionsV1[0].ID,
      sequence: 1,
      explanation_required: false,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'Low Scope',
      question_ID: QuestionsV1[0].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    },
    {
      ID: uuid(),
      text: 'High Likelihood',
      question_ID: QuestionsV1[1].ID,
      sequence: 1,
      explanation_required: true,
      high_risk_score: 3
    },
    {
      ID: uuid(),
      text: 'Low Likelihood',
      question_ID: QuestionsV1[1].ID,
      sequence: 2,
      explanation_required: false,
      high_risk_score: 1
    }
  ];

  const DependentAnswersV1 = [
    {
      ID: uuid(),
      question_ID: QuestionsV1[0].ID,
      choices_ID: ChoicesV1[0].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    },
    {
      ID: uuid(),
      question_ID: QuestionsV1[1].ID,
      choices_ID: ChoicesV1[2].ID,
      createdAt: new Date(),
      createdBy: 'admin',
      modifiedAt: new Date(),
      modifiedBy: 'admin'
    }
  ];

  // Insert test data
  await INSERT.into('sapit.acoe.aiea.Sections').entries(section1);
  await INSERT.into('sapit.acoe.aiea.Questionnaires').entries(QuestionnaireV1);
  await INSERT.into('sapit.acoe.aiea.Questions').entries(QuestionsV1);
  await INSERT.into('sapit.acoe.aiea.Choices').entries(ChoicesV1);
  await INSERT.into('sapit.acoe.aiea.DependentQuestionAnswer').entries(DependentAnswersV1);

  // Create new draft questionnaire
  const QuestionnaireV2 = {
    ID: uuid(),
    version: '2.0',
    //questionnairetype_code: 'Usecase Impact Assessment',
    isActive: false,
    submitted: false,
    DraftAdministrativeData_DraftUUID: uuid(),
    IsActiveEntity: false,
    HasActiveEntity: false,
    HasDraftEntity: true,
    createdAt: new Date(),
    createdBy: 'bob',
    modifiedAt: new Date(),
    modifiedBy: 'bob'
  };

  //Draft without questionnaire type
  const draftResponse = await POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires`,
    {
      version: '2.0'
    },
    {
      withCredentials: true,
      auth: { username: "bob", password: "bob" }
    }
  );

  const draftId = draftResponse.data.ID;

  // Act & Assert
  await expect(
    POST(
      `/service/AIEthicsQuestionnaireManagement/Questionnaires(ID=${draftId},IsActiveEntity=false)/AIEthicsQuestionnaireManagement.copyfromOldVersion`,
      {},
      {
        withCredentials: true,
        auth: { username: "bob", password: "bob" }
      }
    )
  ).to.be.rejectedWith(/400 - Please Select the Questionnaire type first/i);

};

module.exports = { testCopyFromOldActiveVersionSuccess, testCopyFromOldActiveVersionFailure };