/**
 * 
 * @Before(event = { "CREATE" }, entity = "GbaasQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

module.exports = async function(request) {
	try{
		const currentUserId = request.user.id;
		const assessmentId = request.params[0].ID;
		const oAssessmentDetails = await SELECT.one("sapit.acoe.gbaas.Assessments")
									.where({ID: assessmentId});

		//update the processor
		if(oAssessmentDetails.processor != currentUserId){
			await UPDATE("sapit.acoe.gbaas.Assessments").where({
				ID: assessmentId
			}).set({processor: currentUserId});

			request.notify("Assigned to you");
		}

		if(oAssessmentDetails.status_code == "Submitted"){
			await UPDATE("sapit.acoe.gbaas.Assessments").where({
				ID: assessmentId
			}).set({
				status_code: "In Review"
			});
		}

	}catch(oError){
		 request.error(500, `Failed to assign: ${oError.message}`);
	}
	
}