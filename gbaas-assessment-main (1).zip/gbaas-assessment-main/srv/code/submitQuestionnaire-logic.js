/**
 * 
 * @On(event = { "submit" }, entity = "GbaasQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function (request) {
	const questionnaireId = request.params[0].ID;

	const questionnairedetails = await SELECT.one.from("sapit.acoe.gbaas.Questionnaires")
		.where({ ID: questionnaireId });
	if (questionnairedetails.questionnaireTypeCode_code !== '' && questionnairedetails.version !== '') {
		await UPDATE("sapit.acoe.gbaas.Questionnaires").where({
			ID: questionnaireId
		}).set({
			submitted: true
		});
		request.notify("Questions are successfully submitted");
	} else {
		request.error(500, "Fill the mandatory fields");
	}

}