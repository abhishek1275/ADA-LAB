/**
 * 
 * @On(event = { "UploadToSirius" }, entity = "AIEthicsAssessment.GroupedQuestionnaireResponses")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
const httpclient = require("@sap-cloud-sdk/http-client");
const download_Groupedquestionnaireresponses = require('../code/download-groupedquestionnaireresponses');
const cds = require("@sap/cds");
const { message } = require("@sap/cds/lib/log/cds-error");

module.exports = async function (request) {

	let userToken = '';

	const expectedSourceSystem = 'SIRIUS'
	//When Status marked as Completed via Action or modifying the status field
	if (request.uploadToSirius|| request.event =='markAsCompleted') {
		let requestID;

		if(request.event == 'markAsCompleted'){
			 requestID = request.params[0].ID;
		}else{
			 requestID = request.data.ID;
		}
		
		userToken = request.user.tokenInfo?.getTokenValue();
		groupedquestionnaireresponse = await SELECT.one.from('sapit.acoe.aiea.GroupedQuestionnaireResponses').where({ assessment_ID: requestID }).orderBy("version desc");
	} 
	//When Policy Self Assessment is Submitted
	else if(request.GroupId){
		const requestID = request.GroupId;
		userToken = request.user.tokenInfo?.getTokenValue();
		groupedquestionnaireresponse = await SELECT.one.from('sapit.acoe.aiea.GroupedQuestionnaireResponses').where({ ID: requestID });
	}
	//When clicked on Upload to Sirius in Assessment Management App
	else{
		const requestID = request.params[1].ID;
		userToken = request.user.tokenInfo?.getTokenValue();
		groupedquestionnaireresponse = await SELECT.one.from('sapit.acoe.aiea.GroupedQuestionnaireResponses').where({ ID: requestID });
	}

	const {
		assessment_ID,
		questionnaire_ID,
		Status
	} = groupedquestionnaireresponse;

	const assessmentDetails = await SELECT.one.from('sapit.acoe.aiea.AIEthicsImpactAssessments').where({ ID: groupedquestionnaireresponse.assessment_ID });
	const {
		ID,
		sourceSystem,
		sourceSystemID,
	} = assessmentDetails

	let destinationName = 'aiethicsassessment-sirius-api';

	if (groupedquestionnaireresponse.Status_code == 'Work In Progress' || assessmentDetails.sourceSystem != 'SIRIUS') {
		return;
	}

	//Hitting space level destination fails in BAS for document upload, hence using subaccount destination sirius test

/*	if (process.env.NODE_ENV === "production") {
		destinationName = 'aiethicsassessment-sirius-api'
	} else if (cds.env.profiles.includes("hybrid") || cds.env.profiles.includes("development")) {
		destinationName = 'siriustest'
	} else {
		request.error(500, "Destination Name could not be retrieved for the environment -" + process.env.NODE_ENV +" " +cds.env.profiles.toString());
	}*/

	const path = '/zprs/api/docs/saveDocumentInTFTask'
	const taskFamily = 'AIET' // Do Not change it, tech user has access to this task only
	const pdfcontent = await download_Groupedquestionnaireresponses(request);


	const assessmentType = await SELECT.one.from('sapit.acoe.aiea.Questionnaires').where({ ID: groupedquestionnaireresponse.questionnaire_ID });
	const documentName = assessmentType.questionnairetype_code

	let documentFamily = '';
	if (documentName == 'Usecase Impact Assessment') {
		documentFamily = 'AIIA'
	} else if (documentName == 'Policy Self Assessment') {
		documentFamily = 'AIPA'
	}


	const postTosirius = await httpclient.executeHttpRequest(
		{
			destinationName: destinationName,
			jwt: userToken
		},
		{
			method: "POST",
			url: path ?? "/",
			headers: {
				'content-type': 'application/json'
			},
			data: {
				"deliveryGuid": `${assessmentDetails.sourceSystemID}`,
				"fileContent": `${pdfcontent}`,
				"fileName": assessmentType.questionnairetype_code + '_' + groupedquestionnaireresponse.version + ".pdf",
				"documentName": `${documentName}`,
				"taskFamily": `${taskFamily}`,
				"documentFamily": `${documentFamily}`,
				"confidential": ""
			}
		},
		{
			fetchCsrfToken: false
		},
	).catch((e) => {
		//console.error(e.response.status, e.response.statusText, e.response.data.message, e);
		if (request.uploadToSirius || request.GroupId!="") {
			//non blocking request for SIRIUS
			request.warn('Upload to Source System ' + sourceSystem + " failed, manual upload may be required");
			return(e);
		} else {
			throw request.error(500, 'Upload to Source System ' + sourceSystem + " failed, manual upload may be required");
		}
	}
	)

	if (postTosirius.status = 200 && postTosirius.data != undefined) {
		request.notify("Document uploaded successfully!!!");
	} 
}