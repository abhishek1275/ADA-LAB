/**
 * 
 * @After(event = { "CREATE","UPDATE" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

module.exports = async function(results,request) {
    if(request.data.newGQR){
        const newGQR = request.data.newGQR
        for(id of newGQR){
            const gqrDetails = await SELECT.one.from("sapit.acoe.aiea.GroupedQuestionnaireResponses")
                                .where({ID:id});
            const questionnairetype = await SELECT.one.from("sapit.acoe.aiea.Questionnaires")
                                        .columns("questionnairetype_code")
                                        .where({ID:gqrDetails.questionnaire_ID});
            const questionnaireDetails = await SELECT.from("sapit.acoe.aiea.Questionnaires")
                                        .columns("ID")
                                        .where({questionnairetype_code:questionnairetype.questionnairetype_code});
            const questionnaireIDs = [];
            questionnaireDetails.forEach(ele => {
                questionnaireIDs.push(ele.ID)
            });
            const highestVersion = await SELECT.one.from("sapit.acoe.aiea.GroupedQuestionnaireResponses")
                                    .columns("version")
                                    .where({questionnaire_ID:questionnaireIDs,assessment_ID:gqrDetails.assessment_ID})
                                    .orderBy({version: "desc"});
            
            if(highestVersion?.version){
                await UPDATE("sapit.acoe.aiea.GroupedQuestionnaireResponses").where({ID: id})
                .set({version: highestVersion.version+1});
            }else{
                await UPDATE("sapit.acoe.aiea.GroupedQuestionnaireResponses").where({ID: id})
                .set({version: 1});
            }
            
        }
    }
}