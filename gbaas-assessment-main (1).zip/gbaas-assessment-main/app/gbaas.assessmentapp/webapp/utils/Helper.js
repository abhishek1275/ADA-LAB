sap.ui.define([], function () {
    "use strict";

    return {


        _fnReadOdataModel: function (oModel, sEntity, sFilters, oExpand, sOrderBy = undefined) {

            const oCtxBinding = oModel.bindContext(sEntity, null, { '$filter': sFilters, '$expand': oExpand, '$orderby': sOrderBy });
            return oCtxBinding.requestObject();
        },//End of _fnReadOdataModel

        _fnGroupByResponseSection: function (aQuestions) {
            try {
                const oSections = aQuestions.reduce((oResult, question) => {
                    const oNewQuestion = question?.question;
                    const groupKey = oNewQuestion["section_sectionName"];
                    oNewQuestion["responseText"] = question["responseText"];
                    oNewQuestion["comment"] = question["comment"];
                    (oResult[groupKey] ||= []).push(oNewQuestion);
                    return oResult;
                }, {});

                return Object.keys(oSections).map(sSection => ({ sectionName: sSection, questions: oSections[sSection] }));

            } catch (oError) {
                return [];
            }
        },//End of _fnGroupByResponseSection

        _fnGroupBySections: function (aQuestions) {
            try {
                const oSections = aQuestions.reduce((oResult, question) => {
                    const groupKey = question["section_sectionName"];
                    question["responseText"] = '';
                    question["comment"] = '';
                    (oResult[groupKey] ||= []).push(question);
                    return oResult;
                }, {});

                return Object.keys(oSections).map(sSection => ({ sectionName: sSection, questions: oSections[sSection] }));

            } catch (oError) {
                return [];
            }
        },//End of _fnGroupBySections

        fnCreateWizardStepsFactory: function (sId, oContext) {
            const oSections = oContext.getObject();
            const oWizardStep = new sap.m.WizardStep({
                title: oSections?.sectionName,
                validated: false,
                content: {
                    path: 'oFormJsonModel>questions',
                    templateShareable: false,
                    factory: this.fhCreateWizardTemplateFactory.bind(this)
                }
            });

            oWizardStep.addEventDelegate({
                onBeforeShow: (oEvt) => {
                    oWizardStep.setValidated(this._fnIsStepValid(oSections, oWizardStep));
                }
            });

            return oWizardStep;
        },//End of fnCreateWizardStepsFactory

        fhCreateWizardTemplateFactory: function (sId, oContext) {
            const oQuestions = oContext.getObject();
            return this.fhCreateWizardTemplate(oQuestions);
        },//End of fhCreateWizardTemplateFactory

        fhCreateWizardTemplate: function (oQuestion) {
            let oControl;

            if (oQuestion?.responseType_code === "TEXTAREA") {
                oControl = new sap.m.TextArea({
                    value: "{oFormJsonModel>responseText}",
                    width: "20rem"
                });
            } else if (oQuestion?.responseType_code === "CHOICE") {
                oControl = new sap.m.RadioButtonGroup({
                    columns: 3,
                    selectedIndex: -1,
                    buttons: {
                        path: 'oFormJsonModel>questionsChoices',
                        templateShareable: true,
                        template: new sap.m.RadioButton({ text: '{oFormJsonModel>questionChoiceText}' })
                    },
                    select: this.fnHandleRadioBtnSelect.bind(this)
                });
            } else if (oQuestion?.responseType_code === "DROPDOWN") {
                oControl = new sap.m.ComboBox({
                    width: "20rem",
                    value: "{oFormJsonModel>responseText}",
                    change: this.fnHandleComboboxInputValue.bind(this)
                });

                if (oQuestion.questionsChoices) {
                    oQuestion.questionsChoices.forEach(choice => {
                        oControl.addItem(new sap.ui.core.Item({
                            key: choice?.questionChoiceText,
                            text: choice?.questionChoiceText
                        }));
                    });
                }
            } else {
                oControl = new sap.m.Input({
                    value: "{oFormJsonModel>responseText}",
                    width: "20rem",
                    liveChange: (oEvent) => {
                        const oStep = oEvent.getSource().getParent().getParent();

                        const oSection = oStep.getBindingContext("oFormJsonModel").getObject();

                        this._fnIsStepValid(oSection, oStep);
                    }

                });
            }

            const oLabel = new sap.m.Label({
                design: "Bold",
                wrapping: true,
                text: this._counter.count + '. ' + oQuestion?.questionText,
                required: true
            });

            const oInnerVBox = new sap.m.VBox().addStyleClass("sapUiSmallMarginBottom");
            oInnerVBox.addItem(oLabel);
            oInnerVBox.addItem(oControl);

            this._counter.count = this._counter.count + 1;

            if (this._counter.sFormType === "T496") {
                oInnerVBox.addItem(new sap.m.TextArea({
                    placeholder: "Comments/ Remarks",
                    width: "20rem",
                    value: "{oFormJsonModel>comment}"
                }).addStyleClass("sapUiSmallMarginTop"));
            }

            return oInnerVBox;
        },//End of fhCreateWizardTemplate

        fnHandleRadioBtnSelect: function (oEvent) {
            const sText = oEvent.getSource().getSelectedButton().getText();
            const sPath = oEvent.getSource().getBindingContext("oFormJsonModel").getPath();
            oEvent.getSource().getModel("oFormJsonModel").setProperty(sPath + "/responseText", sText);
            oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
            const oStep = oEvent.getSource().getParent().getParent();
            const oSection = oStep.getBindingContext("oFormJsonModel").getObject();
            this._fnIsStepValid(oSection, oStep);
        },//End of fnHandleRadioBtnSelect

        fnHandleComboboxInputValue: function (oEvent) {
            if (!(oEvent.getParameter('itemPressed'))) {
                oEvent.getSource().setValue('');
            }

            const oStep = oEvent.getSource().getParent().getParent();

            const oSection = oStep.getBindingContext("oFormJsonModel").getObject();

            this._fnIsStepValid(oSection, oStep);

        },//End of fnHandleComboboxInputValue

        _fnIsStepValid: function (oSection, oWizardStep) {
            if (!oSection || !Array.isArray(oSection.questions) || !oWizardStep) {
                return false;
            }

            const bStepValid = oSection.questions.every(oQuestion =>
                !!oQuestion.responseText && oQuestion.responseText.trim()
            );


            oWizardStep.setValidated(bStepValid);

            return bStepValid;
        }// End of _fnIsStepValid


    };
});
