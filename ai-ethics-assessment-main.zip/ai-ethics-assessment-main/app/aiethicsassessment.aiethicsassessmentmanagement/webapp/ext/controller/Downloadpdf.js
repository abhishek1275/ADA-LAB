sap.ui.define([
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function(MessageToast, MessageBox) {
    'use strict';

    return {
        downloadAspdf: async function(oEvent) {
            const ogroupedQuestion = oEvent.getObject();           
            const sPath = oEvent.sPath;
            const ServicePath = (window.location.hostname === "localhost" || window.location.hostname.includes("applicationstudio.cloud.sap"))
							? "/service/AIEthicsManagementService"
							: "./service/AIEthicsManagementService";
            const oService = ServicePath + sPath + `/AIEthicsManagementService.gqdownloadfunction()`;

            try {
                const oResponse = await fetch(oService);

                if (!oResponse.ok) {
                    // If the response is not OK, parse the error message
                    const oError = await oResponse.json();
                    const sErrorMessage = oError.error?.message || "An error occurred while downloading the PDF.";
                    MessageBox.error(sErrorMessage);
                    return;
                }

                const oResult = await oResponse.json();
                const binaryString = oResult.value;
                const fileName = `${ogroupedQuestion.questionnaire.questionnairetype_code}_${ogroupedQuestion.version}`;
                const fileType = "application/pdf";
                const isPreviewOnly = false;
                const byteArray = Uint8Array.from(atob(binaryString), (c) =>
                    c.charCodeAt(0),
                );
                const blob = new Blob([byteArray], { type: fileType });
                const blobUrl = URL.createObjectURL(blob);
                if (isPreviewOnly) {
                    window.open(blobUrl, "_blank");
                } else {
                    const link = document.createElement("a");
                    link.href = blobUrl;
                    link.download = fileName;
                    link.click();
                }
            } catch (oError) {
                // Handle network or unexpected errors
                MessageBox.error("Failed to download the PDF. Please try again later.");
                console.error("Error while downloading PDF:", oError);
            }
        }
    };
});
