sap.ui.define(["sap/ui/core/mvc/ControllerExtension",
	"sap/ui/mdc/enum/EditMode",
	"sap/ui/core/message/Message",
	"sap/ui/core/Fragment",
	"sap/ui/core/message/MessageType"
],
	function (ControllerExtension, EditMode, Message, Fragment, MessageType) {
		'use strict';

		return ControllerExtension.extend('aiethicsassessment.aiethicsassessmentapp.ext.controller.ObjectPageExtension', {
			// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
			override: {

				routing: {
					onAfterBinding: async function () {

						const oExtensionAPI = this.base.getExtensionAPI();
						const oView = this.base.getView();
						const oAppComponent = this.base.getAppComponent();
						const oContext = oView.getBindingContext();
						if (!oContext) {
							return
						}
						const oAssessmentDetails = await oContext.requestObject();
						const oModel = oView.getModel();
						oView.setBusy(true);

						//Remove . for local testing
						const ServicePath = (window.location.hostname === "localhost" || window.location.hostname.includes("applicationstudio.cloud.sap"))
							? "/service/AIEthicsAssessment"
							: "./service/AIEthicsAssessment";

						this.oControls.oTableCreateButton.setVisible(false);


						//message strip policy warning
						if (oContext) {
							const sAIEthicsAssessment = oContext.getPath();
							if (sAIEthicsAssessment) {
								const oBindinggroupedQuestionnaierResponse = oModel.bindList(`${sAIEthicsAssessment}/groupedQuestionnaireResponse`);
								oBindinggroupedQuestionnaierResponse.requestContexts().then(function (aContexts) {
									const aGroupedQuestionnaireResponse = aContexts.map(function (oCtx) {
										return oCtx.getObject();
									});


									const aWarnings = aGroupedQuestionnaireResponse.filter(function (policyselfAssessment) {
										return policyselfAssessment.questionnairetype == "Policy Self Assessment" && policyselfAssessment.Status_code == 'Done';
									});
									if (aWarnings.length == 0 && oAssessmentDetails.status_code == 'Completed') {
										const messages = [
											new Message({
												message: "Your case has been reviewed by AI Ethics Office, Please submitted Policy Self Assessement Form ",
												type: MessageType.Warning,
											}),
										];

										oExtensionAPI.showMessages(messages);
									}
								});
							}
						}

						const isDraft = oAssessmentDetails.IsActiveEntity === false;
						const message = isDraft
							? "You are in Edit mode. Save your changes using the 'Save Changes' button in the footer to avoid losing them."
							: "You are currently not in Edit mode. Please click on 'Edit' to modify the assessment details.";

						const messageType = sap.ui.core.MessageType.Information;

						// Show message
						oExtensionAPI.showMessages([
							new sap.ui.core.message.Message({
								message: message,
								type: messageType,
							}),
						]);

						// delay to ensure FE has rendered the toolbar/button
						setTimeout(() => {
							const sButtonText = "Start Use Case Impact Assessment";
							document.querySelectorAll("button").forEach(btn => {
								try {
									if (btn.innerText && btn.innerText.trim() === sButtonText) {
										const oCtrl = sap.ui.getCore().byId(btn.id);
										if (oCtrl && oCtrl.isA && oCtrl.isA("sap.m.Button")) {
											oCtrl.setType("Emphasized");
										}
									}
								} catch (e) { /* ignore */ }
							});
						}, 300);


						const oModelAIEthicsAssessment = new sap.ui.model.odata.v4.ODataModel({
							serviceUrl: ServicePath + "/",
							synchronizationMode: "None",
							autoExpandSelect: true
						});
						this.getView().setModel(oModelAIEthicsAssessment, "DataModel");
						const oBindingQuentionnaire = oModelAIEthicsAssessment.bindList("/Questionnaires");
						oBindingQuentionnaire.requestContexts(0, 1000);
						let activeUseCaseQ; let activepolicyUseCaseQ; let activeuseCaseVersion; let activePolicyVersion; let activeImpactModifiedDate; let activePolicyModifiedDate;
						let impactassessmentData; let impactAssessmentModel; let policyUseCaseData; let policyUseCaseModel;
						await oBindingQuentionnaire.requestContexts(0, 1000).then(function (aContexts) {
							aContexts.forEach(function (oContext) {
								if (oContext.getObject().isActive == true && oContext.getObject().questionnairetype_code == 'Usecase Impact Assessment') {
									activeUseCaseQ = oContext.getObject().ID;
									activeuseCaseVersion = oContext.getObject().version;
									activeImpactModifiedDate = oContext.getObject().modifiedAt;
									impactassessmentData = { ID: activeUseCaseQ, version: activeuseCaseVersion, code: oContext.getObject().questionnairetype_code, modifiedAt: activeImpactModifiedDate };
									impactAssessmentModel = new sap.ui.model.json.JSONModel(impactassessmentData);
									sap.ui.getCore().setModel(impactAssessmentModel, "impactAssessmentModel");

								}
								if (oContext.getObject().isActive == true && oContext.getObject().questionnairetype_code == "Policy Self Assessment") {
									activepolicyUseCaseQ = oContext.getObject().ID;
									activePolicyVersion = oContext.getObject().version;
									activePolicyModifiedDate = oContext.getObject().modifiedAt;
									policyUseCaseData = { ID: activepolicyUseCaseQ, version: activePolicyVersion, code: oContext.getObject().questionnairetype_code, modifiedAt: activePolicyModifiedDate };
									policyUseCaseModel = new sap.ui.model.json.JSONModel(policyUseCaseData);
									sap.ui.getCore().setModel(policyUseCaseModel, "policyUseCaseModel");

								}
							})
						});

						const sPath = oContext.getPath();
						const oData = await oContext.requestObject();
						const isActive = oData.IsActiveEntity;
						let responsibilityArea = oData.responsibilityArea;
						let useCaseName = oData.name;
						let URLParameters = "";
						const urlParams = new URLSearchParams(window.location.search);

						// Ensure sourceSystem is converted to uppercase
						const sourceSystem = urlParams.get("sourceSystem")?.toUpperCase();
						const sourceID = urlParams.get("sourceID");
						let editBtn;

						// Simplified the if-else structure for better readability
						if (oData.sourceSystem && oData.sourceSystemID) {
							URLParameters = {
								sourceSystem: oData.sourceSystem,
								sourceID: oData.sourceSystemID,
								additionalSourceSystemIdentifier: oData.additionalSourceSystemIdentifier
							};
						} else {
							const defaultParams = {
								sourceSystem: 'AIEA',
								sourceID: 'AIEA-ID',
								additionalSourceSystemIdentifier: 'None'
							};

							if (sourceSystem) {
								const sourceID = sourceSystem === 'SIRIUS' ? urlParams.get("sourceID") : urlParams.get("productID");
								const additionalSourceSystemIdentifier = sourceSystem === 'HYCOM' ? urlParams.get("rvis") : 'None';

								URLParameters = {
									sourceSystem: sourceSystem,
									sourceID: sourceID,
									additionalSourceSystemIdentifier: additionalSourceSystemIdentifier
								};
							} else {
								URLParameters = defaultParams;
							}
						}
						const jsonModel = new sap.ui.model.json.JSONModel(URLParameters);
						sap.ui.getCore().setModel(jsonModel, "URLParameters");

						const assessmentID = oContext.sPath.split("/AIEthicsImpactAssessments(ID=")[1].split(",")[0];
						const assessment = { ID: assessmentID, path: oContext.sPath, IsActiveEntity: isActive };
						const assessmentModel = new sap.ui.model.json.JSONModel(assessment);
						sap.ui.getCore().setModel(assessmentModel, "assessmentModel");

						const data = sap.ui.getCore().getModel("URLParameters").getData();

						//Hiding all source system related field
						this.oControls.oFieldSourceSystem.setVisible(false);
						this.oControls.oFieldSourceSystemID.setVisible(false);
						this.oControls.oFieldAdditionalSourceSystemIdentifier.setVisible(false);

						//Setting all fields as non-editable

						try {

							this.oControls.oLinkSirius.setText(data.sourceSystem);
							this.oControls.oFieldName.setEditable(false);
							this.oControls.oFieldBoardAreaRequestor.setEditMode(EditMode.Display);
							this.oControls.oFieldSapProducts.setEditMode(EditMode.Display);
							this.oControls.oFieldUseCaseOwner.setEditMode(EditMode.Display);
							this.oControls.oFieldResponsibilityArea.setEditMode(EditMode.Display);
							this.oControls.oTableCreateButton.setVisible(false);
							this.oControls.oTableBasicSearchButton.setVisible(false);
							this.oControls.oFieldUseCaseClassification.setEditMode('Display');
							this.oControls.oFieldStatusCode.setEditMode('Display');
							this.oControls.oCustomFormElementOwner.setVisible(isActive);
							this.oControls.oFieldSourceSystem.setVisible(false);
							this.oControls.oFieldSourceSystemID.setVisible(false);
							this.oControls.oFieldAdditionalSourceSystemIdentifier.setVisible(false);
						} catch (error) {
							sap.m.MessageBox.error("Technical error occurred, please try again after sometime or reach out to support team", {
								onClose: function () {
									// Navigate back in browser history
									var oHistory = sap.ui.core.routing.History.getInstance();
									var sPreviousHash = oHistory.getPreviousHash();
									if (sPreviousHash !== undefined) {
										window.history.go(-1);
									} else {

										var oRouter = oAppComponent.getRouter();
										oRouter.navTo("AIEthicsImpactAssessmentsList", {}, true);
									}
								}
							});
							// Stop further execution
							return;
						}

						//When source system is 'SIRIUS',link will be enabled. Otherwise, disabled.
						if (data.sourceSystem == 'SIRIUS' || data.sourceSystem == 'HYCOM') {
							this.oControls.oLinkSirius.setEnabled(true);
						} else {
							this.oControls.oLinkSirius.setEnabled(false);
						}

						if ((oData.status_code === "New" || oData.status_code === "Draft" || oData.status_code == "Ready To Submit" || oData.status_code === "Action On Requestor")&& isActive === false) {
							try {
									this.oControls.oFieldName.setEditable(true);
									this.oControls.oFieldBoardAreaRequestor.setEditMode(EditMode.Editable);
									this.oControls.oFieldSapProducts.setEditMode(EditMode.Editable);
									this.oControls.oFieldUseCaseOwner.setEditMode(EditMode.Editable);
									this.oControls.oFieldResponsibilityArea.setEditMode(EditMode.Editable);
									this.oControls.oFieldSourceSystemEdit.setValue(data.sourceSystem);
									this.oControls.oFieldAdditionalSourceSystemIdentifierEdit.setValue(data.additionalSourceSystemIdentifier);
									this.oControls.oLinkSirius.setText(data.sourceSystem);
									this.oControls.oFieldSourceSystemIDEdit.setValue(data.sourceID);
									this.oControls.oTableCreateButton.setVisible(false);
									this.oControls.oTableBasicSearchButton.setVisible(false);
									editBtn = this.oControls.oTableStandardActionEdit.getVisible();
									assessmentModel.setProperty("/isEditBtn", editBtn);

									if ((oData.status_code == "New" || oData.status_code == "Draft" || oData.status_code == "Ready To Submit" || oData.status_code == "Action On Requestor")) {
										assessmentModel.setProperty("/isNewOrAction", true);
									} else {
										assessmentModel.setProperty("/isNewOrAction", false);
									}
							} catch (error) {
								sap.m.MessageBox.error("Technical error occurred, please try again after sometime or reach out to support team", {
									onClose: function () {
										// Navigate back in browser history
										var oHistory = sap.ui.core.routing.History.getInstance();
										var sPreviousHash = oHistory.getPreviousHash();
										if (sPreviousHash !== undefined) {
											window.history.go(-1);
										} else {

											var oRouter = oAppComponent.getRouter();
											oRouter.navTo("AIEthicsImpactAssessmentsList", {}, true);
										}
									}
								});
								// Stop further execution
								return;
							}

						}

						//Default value for responsibility area
						if ((URLParameters.sourceSystem == 'SIRIUS' && !oData.sourceSystem) || (URLParameters.sourceSystem == 'SIRIUS' && !oData.responsibilityArea)) {
							const oService = ServicePath + sPath + `/AIEthicsAssessment.getdefaultResponsibilityArea(SystemId=${URLParameters.sourceID})`;
							try {
								const oResponse = await fetch(oService);
								if (!oResponse.ok) {
									throw new Error(`Responsibility Area Error: ${oResponse.status} - ${oResponse.statusText}`);
								}
								const oResult = await oResponse.json();
								responsibilityArea = oResult.value;
							} catch (error) {
								const messages = [
									new Message({
										message: "Unable to fetch responsibility area from SIRIUS. Please set it manually.",
										type: MessageType.Warning,
									}),
								];
								oExtensionAPI.showMessages(messages);
							}

							const oServiceuseCaseName = ServicePath + sPath + `/AIEthicsAssessment.getusecasenamefromsirius(SystemId=${URLParameters.sourceID})`;
							try {
								const oResponse = await fetch(oServiceuseCaseName);
								if (!oResponse.ok) {
									throw new Error(`Use Case Name Error: ${oResponse.status} - ${oResponse.statusText}`);
								}
								const oResult = await oResponse.json();
								useCaseName = oResult.value;
							} catch (error) {
								const messages = [
									new Message({
										message: "Unable to fetch use case name from SIRIUS. Please set it manually.",
										type: MessageType.Warning,
									}),
								];
								oExtensionAPI.showMessages(messages);
							}

						}

						setTimeout(function () {
							this.oControls.oFieldResponsibilityArea.setValue(responsibilityArea);
							this.oControls.oFieldName.setValue(useCaseName);
						}.bind(this), 500);

						oView.setBusy(false);

					}
				},


				onInit: function () {

					this.oControls ={
						oLinkSirius : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::NavigateToPreviousPortal--linkSirius"),
						oFieldName : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::name::Field-edit"),
						oFieldBoardAreaRequestor : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::boardAreaRequestor_code::Field-edit"),
						oFieldSapProducts : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::sapProductsAndTechnologies::productAndTechnology_code::MultiValueField::_mvf"),
						oFieldUseCaseOwner : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::useCaseOwner::Field-edit"),
						oFieldResponsibilityArea : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::responsibilityArea::Field-edit"),
						oTableCreateButton : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::table::groupedQuestionnaireResponse::LineItem::Submissions::StandardAction::Create"),
						oTableBasicSearchButton : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::table::groupedQuestionnaireResponse::LineItem::Submissions::StandardAction::BasicSearch"),
						oFieldUseCaseClassification : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::ImpactAssessmentStatus::FormElement::DataField::useCaseclassification_code::Field-edit"),
						oFieldStatusCode : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::ImpactAssessmentStatus::FormElement::DataField::status_code::Field-edit"),
						oCustomFormElementOwner : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::CustomFormElement::Owner"),
						oFieldSourceSystem : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::FormElement::DataField::sourceSystem"),
						oFieldSourceSystemID : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::FormElement::DataField::sourceSystemID"),
						oFieldAdditionalSourceSystemIdentifier : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::FormElement::DataField::additionalSourceSystemIdentifier"),
						oFieldSourceSystemEdit : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::FormElement::DataField::sourceSystem::Field-edit"),
						oFieldSourceSystemIDEdit : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::FormElement::DataField::sourceSystemID::Field-edit"),
						oFieldAdditionalSourceSystemIdentifierEdit : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::FormContainer::SourceDetails::FormElement::DataField::additionalSourceSystemIdentifier::Field-edit"),
						oTableStandardActionEdit : sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::StandardAction::Edit"),
						oDelegateButton:  sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::table::delegates::LineItem::Delegates::StandardAction::Create")
					}

	
					//Delegate Create action tooltip
					const oDelegateButton = this.oControls.oDelegateButton;

					if (oDelegateButton) {
						oDelegateButton.setTooltip("Click to add a new Delegate. A Delegate is authorized to manage this request on your behalf in your absence.");
					}

				}
				/**
				 * Called when a controller is instantiated and its View controls (if available) are already created.
				 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
				 * @memberOf aiethicsassessment.aiethicsassessmentapp.ext.controller.ObjectPageExtension
				 */


			},


			onArtifactHelpPressed: function _onArtifactHelpPressed() {
				const sLink = 'https://workzone.one.int.sap/site#workzone-home&/groups/byIKlmidd8ACgYb2l7KvG5/workpage_tabs/k0Z5S64aceu7dkfnbPBwuN';
				sap.m.URLHelper.redirect(sLink, true);
			},


			onAddComment: function () {

				if (this._oDialog) {
					this._oDialog.destroy();
					this._oDialog = null;
				}
				Fragment.load({
					name: "aiethicsassessment.aiethicsassessmentapp.ext.fragment.AddCommentDialog",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					this.getView().addDependent(this._oDialog);
					const oComboBox = sap.ui.getCore().byId("groupedQuestionnaireResponseDropdown");

					// Get the current Impact Assessment ID
					const oContext = this.getView().getBindingContext();
					const sImpactAssessmentID = oContext.getProperty("ID");

					// Bind the ComboBox with a filter
					const oBinding = oComboBox.getBinding("items");
					const oFilter = new sap.ui.model.Filter("assessment_ID", sap.ui.model.FilterOperator.EQ, sImpactAssessmentID);
					oBinding.filter([oFilter]);

					this._oDialog.open();
				}.bind(this));
			},
			onSubmitComment: async function () {
				const comment = sap.ui.getCore().byId("commentInput").getValue();
				const assessmentID = sap.ui.getCore().byId("groupedQuestionnaireResponseDropdown").getSelectedKey();

				if (!comment) {
					sap.m.MessageToast.show("Please enter a comment.");
					return;
				}

				if (!assessmentID) {
					sap.m.MessageToast.show("Please select a Grouped Questionnaire Response.");
					return;
				}

				const oView = this.getView();
				const oModel = oView.getModel();
				const oContext = oView.getBindingContext();

				const oOperation = oModel.bindContext("AIEthicsAssessment.addComment(...)", oContext);
				oOperation.setParameter("Comment", comment);
				oOperation.setParameter("AssessmentID", assessmentID);
				await oOperation.execute();

				sap.m.MessageToast.show("Comment added successfully.");
				this._oDialog.close();

				// Scroll to the bottom of the table
				const oTable = sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::AIEthicsImpactAssessmentsObjectPage--fe::CustomSubSection::CustomComment--customCommentsTable");
				//const oBinding = oTable.getBinding("items");
				oTable.bindItems({
					path: "comment",
					sorter: new sap.ui.model.Sorter("createdAt", true),
					template: oTable.getBindingInfo("items").template // Reuse the existing template
				});

				setTimeout(() => {
					const oItems = oTable.getItems();
					if (oItems.length > 0) {
						oTable.scrollToIndex(0);
					}
				}, 500);

				oModel.refresh();
			},
			onCancelComment: function () {
				this._oDialog.close();
			},
			//Use Case Impact Assessment Navigation
			NavigateToAssessmentPage: async function (oEvent) {
				const oModel = this.getView().getModel();
				const oContext = this.getView().getBindingContext();
				const parentPath = oContext.getPath(); // Path to existing draft parent
				const oExtensionAPI = this.base.getExtensionAPI(); // Get extension API
				const aBindings = oEvent.oModel.aAllBindings;
				let draftGroupedQ = 0; let orgAssessmentID;
				const AssessmentValue = sap.ui.getCore().getModel("assessmentModel").getData();
				orgAssessmentID = AssessmentValue.ID;

				let questionnaireID = "";
				const oBindingQuentionnaire = oModel.bindList("/Questionnaires");
				const questionnaireContextData = await oBindingQuentionnaire.requestContexts(0, 1000);
				questionnaireContextData.forEach(binding => {
					const ctx = binding.getObject();
					if (ctx.questionnairetype_code == "Usecase Impact Assessment" && ctx.isActive === true) {
						questionnaireID = ctx.ID;
						return;
					}
				});
				aBindings.forEach(binding => {
					if (binding.sPath == 'groupedQuestionnaireResponse' && binding.oContext.sPath.includes(orgAssessmentID) == true) {
						if (binding.aContexts.length > 0) {
							const hasDraft = binding.aContexts.some(ctx => {
								const data = ctx.getObject();
								return data.Status_code == "Work In Progress" && data.questionnaire.questionnairetype_code == 'Usecase Impact Assessment';
							});
							if (hasDraft) draftGroupedQ++;
						}
					}
				});
				if (draftGroupedQ == 0) {
					const useCaseName = this.oControls.oFieldName.getValue();
					const responsibilityAreaVal = this.oControls.oFieldResponsibilityArea.getValue();
					const useCaseNameValue = { usecaseName: useCaseName, responsibilityArea: responsibilityAreaVal };
					const usecaseNameModel = new sap.ui.model.json.JSONModel(useCaseNameValue);
					sap.ui.getCore().setModel(usecaseNameModel, "usecaseNameModel");

					// Create grouped questionnaire response as composition
					const oGroupedBinding = oModel.bindList(`${parentPath}/groupedQuestionnaireResponse`);
					const createPromise = oGroupedBinding.create({
						Status_code: 'Work In Progress',
						questionnaire_ID: questionnaireID,
						IsActiveEntity: false
					});
					await createPromise.created(); // Wait for creation to complete

					// Extract ID from the createPromise path
					const createdId = createPromise.getPath().match(/ID=([^,]+)/)[1];

					const fullPath = createPromise.getPath();
					const groupedQRMatch = /groupedQuestionnaireResponse\(ID=([^,]+)/.exec(fullPath);
					const createdGpId = groupedQRMatch ? groupedQRMatch[1] : null;

					const assessmentType = { assessmentType: "ImpactAssessment", navThroughCustBtn: "Create", groupedQID: createdGpId };
					const jsonModel = new sap.ui.model.json.JSONModel(assessmentType);
					sap.ui.getCore().setModel(jsonModel, "assessmentType");

					const oExtensionAPI = this.base.getExtensionAPI();
					await oExtensionAPI.routing.navigateToRoute(
						"GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage",
						{
							key: `ID=${createdId},IsActiveEntity=false`,
							groupedQuestionnaireResponseKey: `ID=${createdGpId},IsActiveEntity=false`
						}
					);
					//his.routing.navigateToRoute("GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage", { "key": "ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=false", "groupedQuestionnaireResponseKey": "ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=false" });
				}
				else {
					sap.m.MessageBox.error("There exists a Use Case Imapact Assessment with Work In Progress status. Please update the same.");
				}
			},

			//Policy Self Assessment Navigation
			NavigateToPolicySelfAssessmentPage: async function (oEvent) {

				const oModel = this.getView().getModel();
				const oContext = this.getView().getBindingContext();
				const parentPath = oContext.getPath(); // Path to existing draft parent
				const aBindings = oEvent.oModel.aAllBindings;
				let draftGroupedQ = 0; let orgAssessmentID;
				const AssessmentValue = sap.ui.getCore().getModel("assessmentModel").getData();
				orgAssessmentID = AssessmentValue.ID;

				let questionnaireID = "";
				const oBindingQuentionnaire = oModel.bindList("/Questionnaires");
				const questionnaireContextData = await oBindingQuentionnaire.requestContexts(0, 1000);
				questionnaireContextData.forEach(binding => {
					const ctx = binding.getObject();
					if (ctx.questionnairetype_code == "Policy Self Assessment" && ctx.isActive === true) {
						questionnaireID = ctx.ID;
						return;
					}
				});
				aBindings.forEach(binding => {
					if (binding.sPath == 'groupedQuestionnaireResponse' && binding.oContext.sPath.includes(orgAssessmentID) == true) {
						if (binding.aContexts.length > 0) {
							{
								const hasDraft = binding.aContexts.some(ctx => {
									const data = ctx.getObject();
									return data.Status_code == "Work In Progress" && data.questionnaire.questionnairetype_code == 'Policy Self Assessment';
								});
								if (hasDraft) draftGroupedQ++;
							}
						}
					}
				});
				if (draftGroupedQ == 0) {

					const useCaseName = this.oControls.oFieldName.getValue();
					const useCaseNameValue = { usecaseName: useCaseName };
					const usecaseNameModel = new sap.ui.model.json.JSONModel(useCaseNameValue);
					sap.ui.getCore().setModel(usecaseNameModel, "usecaseNameModel");

					// Create grouped questionnaire response as composition
					const oGroupedBinding = oModel.bindList(`${parentPath}/groupedQuestionnaireResponse`);
					const createPromise = oGroupedBinding.create({
						Status_code: 'Work In Progress',
						questionnaire_ID: questionnaireID,
						IsActiveEntity: false
					});
					await createPromise.created(); // Wait for creation to complete

					// Extract ID from the createPromise path
					const createdId = createPromise.getPath().match(/ID=([^,]+)/)[1];

					const fullPath = createPromise.getPath();
					const groupedQRMatch = /groupedQuestionnaireResponse\(ID=([^,]+)/.exec(fullPath);
					const createdGpId = groupedQRMatch ? groupedQRMatch[1] : null;

					const oExtensionAPI = this.base.getExtensionAPI();

					const assessmentType = { assessmentType: "PolicySelfAssessment", navThroughCustBtn: "Create", groupedQID: createdGpId };
					const jsonModel = new sap.ui.model.json.JSONModel(assessmentType);
					sap.ui.getCore().setModel(jsonModel, "assessmentType");

					await oExtensionAPI.routing.navigateToRoute(
						"GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage",
						{
							key: `ID=${createdId},IsActiveEntity=false`,
							groupedQuestionnaireResponseKey: `ID=${createdGpId},IsActiveEntity=false`
						}
					);
					//this.routing.navigateToRoute("GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage", { "key": "ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=false", "groupedQuestionnaireResponseKey": "ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=false" });
				}
				else {
					sap.m.MessageBox.error("There exists a Policy Self Assessment with Work In Progress status. Please update the same.");
				}
			},

		});
	});

