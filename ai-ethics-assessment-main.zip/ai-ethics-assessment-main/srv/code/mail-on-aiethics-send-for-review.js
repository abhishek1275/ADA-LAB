/**
 * It sends notification when the assessment is submitted
 * @After(event = { "Send for Review" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

const path = require('path');
const MailSender = require("../email/MailSender");

module.exports = async function(results, request) {
    const employeeDataService = await cds.connect.to("employee_data");
    const { Employees } = employeeDataService.entities;
    const targetPath = path.join(__dirname,"..","email/","images");
    const assessmentId = request.params[0].ID;
    const assessmentDetails = await SELECT.one("sapit.acoe.aiea.AIEthicsImpactAssessments").where({ID: assessmentId});
    const questionnaireDetails = await SELECT.one("sapit.acoe.aiea.Questionnaires").where({questionnairetype_code: 'Usecase Impact Assessment', isActive: true});
    const questionnaireType = questionnaireDetails.questionnairetype_code;
    const reportManagerId = assessmentDetails.createdBy;
    const requestNumber = 'AIE-' + String(assessmentDetails.aiEthicsAssessment_id).padStart(7,'0');
    const reportManagerInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: reportManagerId}));
    const nameOfUsecase = assessmentDetails.name;
    const status = assessmentDetails.status_code;
    const useCaseClassification = assessmentDetails.useCaseclassification_code
    const sourceSystem = assessmentDetails.sourceSystem;
    const ccList = "";
    const assessmentUrl = `${request.headers.referer}#/AIEthicsImpactAssessments(ID=${assessmentId},IsActiveEntity=true)`;
    const managementUrl = assessmentUrl.replace("aiethicsassessmentapp","aiethicsassessmentmanagement");
    const delegateDetails  = await SELECT.from("sapit.acoe.aiea.AIEthicsAssessmentsDelegates").columns("userID")
                            .where({aIEthicsImpactAssessment_ID: assessmentId, toBeNotified:true});
    const delegateEmails = [];
    for (const delegate of delegateDetails) {
        const delegateUserInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: delegate.userID }));
        delegateEmails.push(delegateUserInfo.email);
    };

    const toMailList = delegateEmails.length > 0 ? [reportManagerInfo.email, ...delegateEmails] : [reportManagerInfo.email];

    const attachments = [{
        filename: "sap-logo.png",
        cid: "sap-logo",
        path: targetPath + "/sap-logo.png",
        },
        {
        filename: "impact-assessment.png",
        cid: "center-image",
        path: targetPath + "/impact-assessment.png",
    }];

    if(status == "Submitted"){
        const to = toMailList;
        const subject = `AI Ethics Assessment Status Update - Submitted`;
		const body = `We would like to inform you that Use Case Impact Assessment form for your use case '${nameOfUsecase}' has been submitted.`;
		const belowbody = `Please ensure you review the comments section for queries or feedback. To view the request click <a href=${assessmentUrl}>here</a>`
	  const download_Groupedquestionnaireresponses = require('../code/download-groupedquestionnaireresponses');
        request.mail = true;
        const pdfbuffer =  await download_Groupedquestionnaireresponses(request);
        attachments.push({
            filename: "Usecase Impact Assessment.pdf",
            content: pdfbuffer,
            encoding: "base64",
            contentType: "application/pdf"
            },);
        sendMail(to,subject,body,belowbody);
        const officer_email = questionnaireDetails.email;
        const officier_cc = "";
        const officer_subject = `AI Ethics Assessment Submitted For Your Review`;
        const officer_bodycontent  = `The Use Case Impact Assessment form has been submitted and is now awaiting your review`;
        const officer_closecontent = `Kindly access the submission via <a href=${managementUrl}>here</a> and provide your feedback or approval at your earliest convenience.`;
        sendMail(officer_email,officer_subject,officer_bodycontent,officer_closecontent);
	}

    async function sendMail(to,subject,bodycontent,closingcontent){
		await MailSender.getInstance().send(to,ccList, subject, "status_notification_template", {
			bodycontent:bodycontent,
			name: reportManagerInfo.firstName,
			requestNumber: requestNumber,
			nameOfUsecase: nameOfUsecase,
			status: status,
			sourceSystem: sourceSystem,
			belowBody: closingcontent
		},attachments);
	}
}