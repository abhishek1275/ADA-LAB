/**
 * 
 * @Before(event = { "CREATE" }, entity = "GbaasQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
const httpclient = require("@sap-cloud-sdk/http-client");
module.exports = async function(request) {

     try {
		const sDestinationName = 'sirius';
		const sPathDeliveryDetails = '/zprs/api/v1/deliveryDetails?deliveryGuid='+request.data.sourceSystemID;
		const oGetdeliveryDetails = await _fnCallSiriusApi(request,sPathDeliveryDetails,sDestinationName, sMethod="GET" );
		console.log("oGetdeliveryDetails --> ", JSON.stringify(oGetdeliveryDetails));
		console.log("oGetdeliveryDetails URL--> ", sPathDeliveryDetails);

		const progGuid= oGetdeliveryDetails.data[0].PROGRAM_GUID
		const sPathgetProgramDetails = '/zprs/api/v1/programDetails?programGuid='+ progGuid;
		const getProgramDetails = await _fnCallSiriusApi(request,sPathgetProgramDetails,sDestinationName, sMethod="GET" );
		console.log("getProgramDetails --> ", JSON.stringify(getProgramDetails));
		console.log("sPathgetProgramDetails URL--> ", sPathgetProgramDetails);

		const siriusResponsibilityArea=getProgramDetails.data[0].DEVELOPMENT_UNIT;
		const sResponsibiltyAreaUrl ='/zorg/v1/productArea?id=' + siriusResponsibilityArea;
		const oResponsibiltyAreaDetails = await _fnCallSiriusApi(request,sResponsibiltyAreaUrl,sDestinationName, sMethod="GET" );
		console.log("oResponsibiltyAreaDetails --> ", JSON.stringify(oResponsibiltyAreaDetails));
		console.log("sPathgetProgramDetails URL--> ", sResponsibiltyAreaUrl);

		const oSiriusResponse = {
			
				"siriusDeliveryName":oGetdeliveryDetails?.data[0]?.["DELIVERY_NAME"],
				"siriusProgramId":oGetdeliveryDetails?.data[0]?.["PROGRAM_GUID"],
				"siriusProgramName":oGetdeliveryDetails?.data[0]?.["PROGRAM_DELIVERY_NAME"],
				"responsibilityArea":oResponsibiltyAreaDetails?.data?.data?.name
			};
		 console.log("oSiriusResponse...", JSON.stringify(oSiriusResponse));
		 await UPDATE("GbaasAssessment.Assessments.drafts").where({ID: request.data.ID}).set(oSiriusResponse);
		
					
	}catch (error) {	
		request.notify(`Failed to load sirius information with error message : ${error.message}`);
		
	}
        
}

async function _fnCallSiriusApi(request,sUrl,sDestinationName, sMethod="GET" ){
	const userToken = request.user.tokenInfo?.getTokenValue();
	return await httpclient.executeHttpRequest(
			{
				destinationName: sDestinationName,
				jwt: userToken
			},
			{
				method: sMethod,
				url: sUrl ?? "/",
				headers: {
					'content-type': 'application/json'
				}
			},
			{
				fetchCsrfToken: false
			},
		)

}
