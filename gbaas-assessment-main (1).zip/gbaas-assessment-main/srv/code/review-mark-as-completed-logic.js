/**
 * 
 * @On(event = { "markAsCompleted" }, entity = "GbaasReviewService.Assessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

module.exports = async function(request) {
	// Your code here
	const assessmentID = request.params[0].ID;

    // Change the status to Completed
    try {
        await UPDATE("sapit.acoe.gbaas.Assessments").where({
            ID: assessmentID
        }).set({
            status_code: "Completed"
        });

    } catch (error) {
        request.error(500, `Failed to mark assessment as completed: ${error.message}`);
    }

    request.notify("Assessment marked as Completed");
}