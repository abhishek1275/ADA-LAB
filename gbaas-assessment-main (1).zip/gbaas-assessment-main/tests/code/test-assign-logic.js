/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;

module.exports = async function(GET, POST, PATCH, DELETE, expect) {
  // Your code here
  const GbaasAssessments = {
    ID : uuid(),
    name : "SAP Assessment",
    sourceSystem                : "SIRIUS",
    sourceSystemID              : "SysID-2345",
    responsibilityArea          : "Ethics and Compliance",
    useCaseOwner                : "admin",
    processor                   : "admin",
    status_code                 : "Submitted",
    createdBy                   : "bob"
  }

  await INSERT.into("sapit.acoe.gbaas.Assessments").entries([GbaasAssessments]);

   // Act
   await POST(
    `/service/GbaasReviewService/Assessments(ID=${GbaasAssessments.ID})/GbaasReviewService.assign`,
    {},
    {
      withCredentials: true,
      auth: {
        username: "bob", 
        password: "bob" 
      }
    }
  );

  //Assert
  const  assessmentdetails= await SELECT.from("sapit.acoe.gbaas.Assessments", GbaasAssessments.ID);
  expect(assessmentdetails.status_code).to.equal("In Review");
};
