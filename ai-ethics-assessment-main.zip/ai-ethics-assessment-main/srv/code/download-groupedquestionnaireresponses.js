/**
 * 
 * @On(event = { "gqdownloadfunction" }, entity = "AIEthicsManagementService.GroupedQuestionnaireResponses")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

const PDFDocument = require('pdfkit');
const { PassThrough } = require("stream");
const { Readable } = require('stream');
module.exports = async function (request) {

	let groupedquestionnaireresponse;
	if (request.mail || request.uploadToSirius || request.event == 'markAsCompleted') {
		const requestID = request.params[0].ID;
		groupedquestionnaireresponse = await SELECT.one.from('sapit.acoe.aiea.GroupedQuestionnaireResponses')
			.where({ assessment_ID: requestID })
			.where({ 'questionnaire.questionnairetype.code': 'Usecase Impact Assessment' })
			.orderBy("version desc");
	} else if (request.GroupId) {
		const requestID = request.GroupId;
		groupedquestionnaireresponse = await SELECT.one.from('sapit.acoe.aiea.GroupedQuestionnaireResponses').where({ ID: requestID });
	}
	else {
		const requestID = request.params[1].ID;
		groupedquestionnaireresponse = await SELECT.one.from('sapit.acoe.aiea.GroupedQuestionnaireResponses').where({ ID: requestID });
	}

	const {
		assessment_ID,
		questionnaire_ID,
		Status
	} = groupedquestionnaireresponse;

	const assessmentDetails = await SELECT.one.from('sapit.acoe.aiea.AIEthicsImpactAssessments')
		.where({ ID: groupedquestionnaireresponse.assessment_ID });

	const customRequestNumber = "AIE-" + String(assessmentDetails.aiEthicsAssessment_id || 0).padStart(7, '0');

	const sapProductsAndTechnologies = await SELECT.from('sapit.acoe.aiea.AIEthicsImpactAssessments_ProductsAndTechnologies')
		.where({ aIEthicsImpactAssessment_ID: assessmentDetails.ID });

	const productCodes = sapProductsAndTechnologies?.length
		? sapProductsAndTechnologies
			.filter(product => product.productAndTechnology_code)
			.map(product => product.productAndTechnology_code)
		: [];
	let productsAndTechString = productCodes.length > 0 ? productCodes.join(', ') : 'Not specified';

	const assessmentType = await SELECT.one.from('sapit.acoe.aiea.Questionnaires')
		.where({ ID: questionnaire_ID });
	const {
		questionnairetype_code
	} = assessmentType

	const questionnaireResponse = await SELECT.from('sapit.acoe.aiea.QuestionnaireResponses')
		.where({ groupedQuestionnaireResponse_ID: groupedquestionnaireresponse.ID })
		.orderBy('question.questionNumber');

	const {
		question_ID,
		responseText,
		responseChoice_ID
	} = questionnaireResponse

	// Create a PDF document
	const doc = new PDFDocument();
	const passthroughStream = new PassThrough();

	doc.pipe(passthroughStream);
	doc.image('./srv/templates/sap-logo.png', 400, 50, { fit: [150, 150], align: 'left', valign: 'top' });
	doc.image('./srv/templates/CentreLogo.png', 60, 97, { fit: [500, 450], align: 'center', valign: 'top' });


	doc.fillColor('white');
	doc
		.font("Helvetica-Bold")
		.fontSize(15)
		.moveDown(6)
		.text(`${assessmentType.questionnairetype_code}`, {
			align: 'left',
			underline: false,
		});

	doc.addNamedDestination(`top`);

	// User details
	doc.fillColor('black');
	//Text after image
	doc.fontSize(15)
		.font('Helvetica')
		.moveDown(7)
		.text(`General Information`);

	doc.fontSize(10)
		.font('Helvetica')

	const topY = doc.y;
	const topPage = doc.page;



	var pdfText = `Use Case Name: ${assessmentDetails.name} \n\nRequest Number: ${customRequestNumber}\n\nStatus: ${assessmentDetails.status_code}\n\nClassification: ${assessmentDetails.useCaseclassification_code}\n\nType of Use Case : ${assessmentDetails.typeOfUseCase_code}\n\nSource system: ${assessmentDetails.sourceSystem}\n\nSource system ID: ${assessmentDetails.sourceSystemID}\n\nResponsibility Area: ${assessmentDetails.responsibilityArea}\n\nSAP Technologies/Product Involved : ${productsAndTechString}\n\nBoard Area Requestor :${assessmentDetails.boardAreaRequestor_code}`;


	doc
		.moveDown(1)
		.text(pdfText);

	doc.fontSize(15)
		.font('Helvetica')
		.moveDown(1)
		.text(assessmentType.questionnairetype_code + ` Response Summary`)

	doc.fontSize(10)
		.font('Helvetica')

	let responseTable = [];

	if (questionnaireResponse.length > 0) {
		for (let index = 0; index < questionnaireResponse.length; index++) {
			await formatcontent(questionnaireResponse[index], index + 1);
		}
	}
	async function formatcontent(item, serialNumber) {
		const question = await SELECT.one.from('sapit.acoe.aiea.Questions').where({ ID: item.question_ID });
		const choice = await SELECT.one.from('sapit.acoe.aiea.Choices').where({ ID: item.responseChoice_ID });
		responseTable.push(serialNumber + ") " + question.questionText + "\n" + (choice ? "\nOption Selected: " + choice.text : "") + (item.responseText ? "\nAnswer: " + item.responseText : ""));
	}


	doc.moveDown(1)

	responseTable.forEach((item, index) => {
		doc
			.text(item);
		doc.moveDown();
	})


	doc.fontSize(12)
		.font('Helvetica')
		.moveDown(1)
		.text(`Best Regards \n\nAI Ethics Office`);

	doc
		.fontSize(8)
		.fillColor('gray')
		.text('Back to top', 500, doc.y + 20, {
			link: '#top',
			underline: true
		});

	doc
		.moveDown(1)
		.lineWidth(3)
		.moveTo(50, doc.y)
		.lineTo(550, doc.y)
		.stroke();

	const pageHeight = doc.page.height;
	const pageWidth = doc.page.width;
	const margin = 405;
	const baseY = doc.y + 10;
	let baseX = margin;

	doc.fontSize(7);

	const footerlinks = [
		{ label: 'Copyright/Trademark', link: 'https://www.sap.com/about/legal/copyright.html' },
		{ label: 'Privacy', link: 'https://www.sap.com/about/legal/privacy.html' },
		{ label: 'Impressum', link: 'https://www.sap.com/about/legal/impressum.html' }];

	footerlinks.forEach((item, i) => {
		doc.text(item.label, baseX, baseY, { link: item.link, underline: false });
		baseX += doc.widthOfString(item.label + ' | ');
		if (i < footerlinks.length - 1) {
			doc.fillColor('gray').text(' | ', baseX - doc.widthOfString(' | '), baseY);
			doc.fillColor('gray');	// for privacy and Impressum		
		}
	});

	doc.fontSize(6).fillColor('gray')
		.moveDown(1)
		.text(`SAP SE, Dietmar-Hopp-Allee 16, 69190 Walldorf, Germany`, 50);

	doc.fontSize(6).fillColor('gray')
		.moveTo(100, doc.y)
		.moveDown(2)
		.text(`Pflichtangaben/Mandatory Disclosure Statements: http://www.sap.com/about/legal/impressum.html
Diese E-Mail kann Betriebs- oder Geschäftsgeheimnisse oder sonstige vertrauliche Informationen enthalten. Sollten Sie diese E-Mail 
irrtümlich erhalten haben, ist Ihnen eine Kenntnisnahme des Inhalts, eine Vervielfältigung oder Weitergabe der E-Mail ausdrücklich untersagt. 
Bitte benachrichtigen Sie uns und vernichten Sie die empfangene E-Mail. Vielen Dank.`, 50);


	doc.fontSize(6).fillColor('gray')
		.moveTo(100, doc.y)
		.moveDown(2)
		.text(`This e-mail may contain trade secrets or privileged, undisclosed, or otherwise confidential information. If you have received this e-mail in 
error, you are hereby notified that any review, copying, or distribution of it is strictly prohibited. Please inform us immediately and destroy the 
original transmittal. Thank you for your cooperation.`, 50);


	doc.end();

	//converting stream to Buffer
	const readableStream = Readable.from(passthroughStream);
	function streamToBuffer(readableStream) {
		return new Promise((resolve, reject) => {
			const buf = [];
			readableStream.on("data", (chunk) => buf.push(chunk));
			readableStream.on("end", () => resolve(Buffer.concat(buf)));
			readableStream.on("error", (err) => reject(err));
		});
	}
	let myBuffer;
	await streamToBuffer(readableStream)
		.then((buffer) => {
			myBuffer = buffer;
		})
		.catch((err) => {

			console.error(err);
		});

	return myBuffer.toString("base64");
}