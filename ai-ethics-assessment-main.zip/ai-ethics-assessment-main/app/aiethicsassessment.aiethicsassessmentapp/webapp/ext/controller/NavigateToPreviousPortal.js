sap.ui.define([
    "sap/m/MessageToast"
], function (MessageToast) {
    'use strict';

    return {
        /**
         * Generated event handler.
         *
         * @param oEvent the event object provided by the event provider.
         */
        onCustomSiriusNavBack: function () {
            const sourceSystem = sap.ui.getCore().getModel("URLParameters").getProperty("/sourceSystem");
            let navigationUrl;

            if (sourceSystem === 'SIRIUS') {
                 const sourceID = sap.ui.getCore().getModel("URLParameters").getProperty("/sourceID");
                if (window.location.hostname.includes("dev") || window.location.hostname.includes("applicationstudio.cloud.sap") || window.location.hostname === "localhost") {
                    navigationUrl = 'https://sirius-dev.tools.sap.corp/prs/link.do?entityGuid=' + sourceID

                } else if (window.location.hostname.includes('test')) {
                    navigationUrl = 'https://sirius-test.tools.sap.corp/prs/link.do?entityGuid=' + sourceID
                } else if (window.location.hostname.includes('prod')) {
                    navigationUrl = 'https://sirius.tools.sap.corp/prs/link.do?entityGuid=' + sourceID
                }
            
                sap.m.URLHelper.redirect(navigationUrl, true);

            }

            if (sourceSystem ==='HYCOM'){
                 const sourceID = sap.ui.getCore().getModel("URLParameters").getProperty("/sourceID");
                  const additionalSourceSystemIdentifier = sap.ui.getCore().getModel("URLParameters").getProperty("/additionalSourceSystemIdentifier");
                  if (window.location.hostname.includes("dev") || window.location.hostname.includes("applicationstudio.cloud.sap") || window.location.hostname === "localhost") {
                    navigationUrl = 'https://portal.d1.hyperspace.tools.sap/continuous-programs/' + sourceID +'/hycom/rvi/'+ additionalSourceSystemIdentifier

                } else if (window.location.hostname.includes('test')) {
                    navigationUrl = 'https://portal.i1.hyperspace.tools.sap/continuous-programs/' + sourceID +'/hycom/rvi/'+ additionalSourceSystemIdentifier

                } else if (window.location.hostname.includes('prod')) {
                     navigationUrl = 'https://portal.hyperspace.tools.sap/continuous-programs/' + sourceID +'/hycom/rvi/'+ additionalSourceSystemIdentifier

                }            
                sap.m.URLHelper.redirect(navigationUrl, true);
            }
            
        }
    };
});
