/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;

async function testQuestionnairesManagementActivateLogicSuccess(GET, POST, PATCH, DELETE, expect) {
  const Questionnaires1 = {
    ID : uuid(),
    questionnaireTypeCode_code  : 'T496',
    version            : 'v1',
    versionDescription : 'Testing',
    isActive           : false,
    submitted          : true,                         
  }
  const Questionnaires2 = {
    ID : uuid(),
    questionnaireTypeCode_code  : 'T496',
    version            : 'v2',
    versionDescription : 'Testing',
    isActive           : true,
    submitted          : true,                         
  }

  await INSERT.into("sapit.acoe.gbaas.Questionnaires").entries([Questionnaires1]);
  await INSERT.into("sapit.acoe.gbaas.Questionnaires").entries([Questionnaires2]);

  await POST(
    `/service/GbaasQuestionnaireManagement/Questionnaires(ID=${Questionnaires1.ID},IsActiveEntity=true)/GbaasQuestionnaireManagement.activate`,
    {},
    {
      withCredentials: true,
      auth: {
        username: "bob", 
        password: "bob" 
      }
    }
  );

  //Assert
  const  questionnairedetails1= await SELECT.from("sapit.acoe.gbaas.Questionnaires", Questionnaires1.ID);
  const  questionnairedetails2= await SELECT.from("sapit.acoe.gbaas.Questionnaires", Questionnaires2.ID);
  expect(questionnairedetails1.isActive).to.equal(true);
  expect(questionnairedetails2.isActive).to.equal(false);
};


async function testQuestionnairesManagementActivateLogicFailure(GET, POST, PATCH, DELETE, expect) {
  const Questionnaires1 = {
    ID : uuid(),
    questionnaireTypeCode_code  : 'Inventory',
    version            : 'v1',
    versionDescription : 'Testing',
    isActive           : true,
    submitted          : true,                         
  }

  await INSERT.into("sapit.acoe.gbaas.Questionnaires").entries([Questionnaires1]);

    await expect(
      POST(
      `/service/GbaasQuestionnaireManagement/Questionnaires(ID=${Questionnaires1.ID},IsActiveEntity=true)/GbaasQuestionnaireManagement.activate`,
      {},
      {
        withCredentials: true,
        auth: {
          username: "bob", 
          password: "bob" 
        }
      }
    )
  ).to.be.rejectedWith(500, /this Questionnaire is already active/i);
};

module.exports = { testQuestionnairesManagementActivateLogicSuccess,testQuestionnairesManagementActivateLogicFailure };
