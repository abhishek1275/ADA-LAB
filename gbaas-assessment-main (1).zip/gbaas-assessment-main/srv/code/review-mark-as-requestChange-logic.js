/**
 * 
 * @On(event = { "requestChange" }, entity = "GbaasReviewService.Assessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/

module.exports = async function(request) {
	// Your code here
	const assessmentID = request.params[0].ID;
	 const  commentText  = request.data.Reason; // pass comment from UI

	try {
		await UPDATE("sapit.acoe.gbaas.Assessments").where({
			ID: assessmentID
		}).set({
			status_code: 'Action On Requestor'
		});


		await INSERT.into("sapit.acoe.gbaas.Comments").entries({
            comment: commentText,
            assessment_ID: assessmentID
        });

	} catch (error) {
		request.error(500, `Failed to update assessment status: ${error.message}`);
	}

	request.notify("Action On Requestor Updated");
}