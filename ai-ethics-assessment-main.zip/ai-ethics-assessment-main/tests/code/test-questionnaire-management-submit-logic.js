/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;

async function testQuestionnaireSubmissionSuccess(GET, POST, PATCH, DELETE, expect) {
  const Questionnaires = {
    ID : uuid(),
    questionnairetype_code  : 'Policy Self Assessment',
    version            : 'v2',
    versionDescription : 'Testing',
    isActive           : false,
    submitted          : false,                         
  }

  await INSERT.into("sapit.acoe.aiea.Questionnaires").entries([Questionnaires]);

  await POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires(ID=${Questionnaires.ID},IsActiveEntity=true)/AIEthicsQuestionnaireManagement.submit `,
    {},
    {
      withCredentials: true,
      auth: {
        username: "bob", 
        password: "bob" 
      }
    }
  );

  //Assert
  const  questionnairedetails= await SELECT.from("sapit.acoe.aiea.Questionnaires", Questionnaires.ID);
  expect(questionnairedetails.submitted).to.equal(true);

};

async function testQuestionnaireSubmissionFailure(GET, POST, PATCH, DELETE, expect) {
  const Questionnaires = {
    ID : uuid(),
    questionnairetype_code  : '',
    version            : 'v2',
    versionDescription : 'Testing',
    isActive           : false,
    submitted          : false,                         
  }

  await INSERT.into("sapit.acoe.aiea.Questionnaires").entries([Questionnaires]);

  await expect(
    POST(
    `/service/AIEthicsQuestionnaireManagement/Questionnaires(ID=${Questionnaires.ID},IsActiveEntity=true)/AIEthicsQuestionnaireManagement.submit `,
    {},
    {
      withCredentials: true,
      auth: {
        username: "bob", 
        password: "bob" 
      }
    }
  )).to.be.rejectedWith(500, /Fill the mandatory fields/i);

};

module.exports = {testQuestionnaireSubmissionSuccess,testQuestionnaireSubmissionFailure }