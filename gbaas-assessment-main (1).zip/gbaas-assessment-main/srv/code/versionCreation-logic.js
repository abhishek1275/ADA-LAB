/**
 * 
 * @Before(event = { "CREATE" }, entity = "GbaasQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
	  const sType = request.data.questionnaireTypeCode_code;
  // Get total count of existing questionnaires of same type
  const oQuestionnairetypecount = await SELECT.one.from("sapit.acoe.gbaas.Questionnaires").where({ questionnaireTypeCode_code: sType })
  .columns(`count(*) as count`);
 // Create version as per questionnaire type
	request.data.version = oQuestionnairetypecount .count + 1;

}