/**
 * It assigns the Usecase  assessment 
 * @On(event = { "Assign" }, entity = "AIEthicsManagementService.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
	//Initializations
	const currentUserId = request.user.id;
	const assessmentId = request.params[0].ID;
	const assessmentdetails = await SELECT.one("sapit.acoe.aiea.AIEthicsImpactAssessments")
								.where({ID: assessmentId});

	//update the processor
	if(assessmentdetails.processor != currentUserId){
		await UPDATE("sapit.acoe.aiea.AIEthicsImpactAssessments").where({
			ID: assessmentId
		}).set({
			processor: currentUserId
		});

		request.notify( "Assigned to you");
	}

	if(assessmentdetails.status_code == "Submitted"){
		await UPDATE("sapit.acoe.aiea.AIEthicsImpactAssessments").where({
			ID: assessmentId
		}).set({
			status_code: "In Review"
		});
	}
}