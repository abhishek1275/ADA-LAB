/**
 * 
 * @On(event = { "requestException" }, entity = "GbaasReviewService.Assessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {
	// Your code here

	

    try {
		const assessmentID = request.params[0]?.ID;
        if (!assessmentID) {
            request.error(400, 'Assessment ID is required');
            return;
        }

        await UPDATE("sapit.acoe.gbaas.Assessments").where({ ID: assessmentID }).set({
            exceptionHandlingEnabled: "Inventory",
            status_code: 'Action On Requestor'
        });

        await INSERT.into("sapit.acoe.gbaas.Comments").entries({
            comment: 'Please submit Inventory form.',
            assessment_ID: assessmentID
        });


    } catch (error) {
        request.error(500, `Failed to request Inventory: ${error.message}`);
    }

    request.notify("Requested for Inventory Form");
}