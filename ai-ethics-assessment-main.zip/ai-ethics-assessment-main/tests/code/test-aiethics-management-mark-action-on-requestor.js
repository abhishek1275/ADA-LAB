/**
 * Given a running CAP service, the unit test should be able to get passed.
 *
 * @param {Function} GET - The `axios` function to send a GET request
 * @param {Function} POST - The `axios` function to send a POST request
 * @param {Function} PATCH - The `axios` function to send a PATCH request
 * @param {Function} DELETE - The `axios` function to send a DELETE request
 * @param {Function} expect - The `chai` function to assert the response
 */

const cds = require("@sap/cds");
const { uuid } = cds.utils;

module.exports = async function (GET, POST, PATCH, DELETE, expect) {
    // Your code here
    const AIEthicsImapactAssessment = {
        ID: uuid(),
        name: "AI Ethics Impact Assessment",
        sourceSystem: "SIRIUS",
        sourceSystemID: "SysID-2345",
        responsibilityArea: "Ethics and Compliance",
        processor: "admin",
        isSteeringExceptionProvided: true,
        status_code: "In Review",
        useCaseOwner: "admin",
        createdBy: "bob"
    };
    await INSERT.into("sapit.acoe.aiea.AIEthicsImpactAssessments").entries([AIEthicsImapactAssessment]);

    // Act
    await POST(
        `/service/AIEthicsManagementService/AIEthicsImpactAssessments(ID=${AIEthicsImapactAssessment.ID},IsActiveEntity=true)/AIEthicsManagementService.requestChange`,
        { reason: "Please describe your use case" },
        {
            withCredentials: true,
            auth: {
                username: "bob",
                password: "bob"
            }
        }
    );

    //Assert
    const assessmentdetails = await SELECT.from("sapit.acoe.aiea.AIEthicsImpactAssessments", AIEthicsImapactAssessment.ID);
    expect(assessmentdetails.status_code).to.equal("Action On Requestor");

    const comments = await SELECT.one.from(`sapit.acoe.aiea.Comments`).where({
        useCase_ID: AIEthicsImapactAssessment.ID,
    });

    expect(comments.comment).to.equal("Requested Modification : Please describe your use case");
    expect(comments.createdBy).to.equal("bob");
};
