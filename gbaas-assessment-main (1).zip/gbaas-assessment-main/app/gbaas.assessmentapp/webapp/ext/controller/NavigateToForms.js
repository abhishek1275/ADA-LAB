sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        /**
         * Generated event handler.
         *
         * @param oContext the context of the page on which the event was fired. `undefined` for list report page.
         * @param aSelectedContexts the selected contexts of the table rows.
         */
        NavigateToT496Form: async function(oContext, aSelectedContexts) {
            try{
                
                this.getEditFlow().getView().setBusy(true);
                const ID = oContext?.getProperty("ID");
                const bIsActiveEntity = oContext?.getProperty("IsActiveEntity");
                const sKey = `ID=${ID},IsActiveEntity=${bIsActiveEntity}`;

                this.getEditFlow().getView().setBusy(false);

                this.routing.navigateToRoute("FormsFormsPage",{ "key": sKey, "formsKey":"ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=true", query:{Display:false, formType:"T496"}});

            }catch(oErr){
                //show message in message box
                this.getEditFlow().getView().setBusy(false);
            }
           
        },
        NavigateToInventoryForm: async function(oContext, aSelectedContexts) {
            try{
                
                this.getEditFlow().getView().setBusy(true);
                const ID = oContext?.getProperty("ID");
                const bIsActiveEntity = oContext?.getProperty("IsActiveEntity");
                const sKey = `ID=${ID},IsActiveEntity=${bIsActiveEntity}`;

                this.getEditFlow().getView().setBusy(false);

                this.routing.navigateToRoute("FormsFormsPage",{ "key": sKey, "formsKey":"ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=true", query:{Display:false, formType:"Inventory"}});

            }catch(oErr){
                //show message in message box
                this.getEditFlow().getView().setBusy(false);
            }
        },
        NavigateToExceptionForm: async function(oContext, aSelectedContexts) {

             try{
                
                this.getEditFlow().getView().setBusy(true);
                const ID = oContext?.getProperty("ID");
                const bIsActiveEntity = oContext?.getProperty("IsActiveEntity");
                const sKey = `ID=${ID},IsActiveEntity=${bIsActiveEntity}`;

                this.getEditFlow().getView().setBusy(false);

                this.routing.navigateToRoute("FormsFormsPage",{ "key": sKey, "formsKey":"ID=11111138-aaaa-bbbb-cccc-ddddeeeeffff,IsActiveEntity=true", query:{Display:false, formType:"Exception"}});

            }catch(oErr){
                //show message in message box
                this.getEditFlow().getView().setBusy(false);
            }
           
       
        },



    };
});