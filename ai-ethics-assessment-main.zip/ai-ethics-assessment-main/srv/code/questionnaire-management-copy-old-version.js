/**
 * It will change the submitted value in questionnaire
 * @On(event = { "submit" }, entity = "AIEthicsQuestionnaireManagement.Questionnaires")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function (request) {
	const questionnaireId = request.params[0].ID;
		const currentQuestionnaire = await SELECT.one.from('AIEthicsQuestionnaireManagement.Questionnaires.drafts')
			.where({ ID: questionnaireId });

		if (!currentQuestionnaire.questionnairetype_code) {
			request.error(400, "Please Select the Questionnaire type first");
		} else {
			// Check if questions already exist and delete them
			const existingQuestions = await SELECT
				.from('AIEthicsQuestionnaireManagement.Questions.drafts')
				.where({ questionnaire_ID: questionnaireId });

			if (existingQuestions.length > 0) {
				// Delete existing questions (this will cascade to choices and dependent answers)
				await DELETE.from('AIEthicsQuestionnaireManagement.Questions.drafts')
					.where({ questionnaire_ID: questionnaireId });

				//console.log(`Deleted ${existingQuestions.length} existing questions before copying`);
			}


			const lastActiveQuestionnaire = await SELECT.one.from('sapit.acoe.aiea.Questionnaires')
				.where({ questionnairetype_code: currentQuestionnaire.questionnairetype_code, isActive: true, submitted: true })
				.orderBy("version desc");

			if (!lastActiveQuestionnaire) {
				return request.error(404, `No active version found for questionnaire type: ${currentQuestionnaire.questionnairetype_code}`);
			}

			//console.log("Copying from questionnaire:", lastActiveQuestionnaire.ID);

			// Get all questions from the last active version
			const questionsList = await SELECT
				.from('sapit.acoe.aiea.Questions')
				.where({ questionnaire_ID: lastActiveQuestionnaire.ID })
				.orderBy('questionNumber asc');

			//console.log("Questions to copy:", questionsList.length);

			if (questionsList.length === 0) {
				return request.error(404, "No questions found in the last active version");
			}
			// Get all choices for the questions
			const questionIds = questionsList.map(q => q.ID);
			const choicesList = await SELECT
				.from('sapit.acoe.aiea.Choices')
				.where({ question_ID: { in: questionIds } })
				.orderBy('sequence asc');

			//console.log("Choices to copy:", choicesList.length);


			// Get all dependent question answers
			const dependentAnswers = await SELECT
				.from('sapit.acoe.aiea.DependentQuestionAnswer')
				.where({ question_ID: { in: questionIds } });

			//console.log("Dependent answers to copy:", dependentAnswers.length);

			// Get risk score references
			const riskScoreReferences = await SELECT
				.from('sapit.acoe.aiea.RiskScoreReferences')
				.where({questionnaire_ID: lastActiveQuestionnaire.ID});

			await UPDATE('AIEthicsQuestionnaireManagement.Questionnaires.drafts')
				.where({ ID: questionnaireId })
				.set({
					versionDescription: `Copied from version ${lastActiveQuestionnaire.version}`,
					email: lastActiveQuestionnaire.email,
					individualRiskScoreFormula: lastActiveQuestionnaire.individualRiskScoreFormula,
					overAllRiskScoreFormula: lastActiveQuestionnaire.overAllRiskScoreFormula
				});

			// Create mapping for old question IDs to new question IDs
			const questionIdMapping = {};
			const choiceIdMapping = {};

			// Copy questions
			for (const question of questionsList) {
				const newQuestionId = cds.utils.uuid();
				questionIdMapping[question.ID] = newQuestionId;

				await INSERT.into('AIEthicsQuestionnaireManagement.Questions.drafts').entries({
					ID: newQuestionId,
					IsActiveEntity: false,
					HasActiveEntity: false,
					HasDraftEntity: true,
					DraftAdministrativeData_DraftUUID: currentQuestionnaire.DraftAdministrativeData_DraftUUID,
					questionNumber: question.questionNumber,
					questionText: question.questionText,
					questionID: question.questionID,
					responseType_code: question.responseType_code,
					section_ID: question.section_ID,
					questionnaire_ID: questionnaireId,
					isRequired: question.isRequired,
					policyDescription: question.policyDescription,
					examples: question.examples,
					createdAt: new Date(),
					createdBy: request.user.id,
					modifiedAt: new Date(),
					modifiedBy: request.user.id,
					highRiskFramework_code: question.highRiskFramework_code,
					riskQuestionType_code: question.riskQuestionType_code

				});
			}

			const updatedquestionsList = await SELECT
				.from('AIEthicsQuestionnaireManagement.Questions.drafts')
				.where({ questionnaire_ID: questionnaireId });
			//console.log("Updated Questions List:", updatedquestionsList);

			// Copy choices
			for (const choice of choicesList) {
				const newChoiceId = cds.utils.uuid();
				choiceIdMapping[choice.ID] = newChoiceId;
				const newQuestionId = questionIdMapping[choice.question_ID];

				if (newQuestionId) {
					await INSERT.into('AIEthicsQuestionnaireManagement.Choices.drafts').entries({
						ID: newChoiceId,
						IsActiveEntity: false,
						HasActiveEntity: false,
						HasDraftEntity: true,
						DraftAdministrativeData_DraftUUID: currentQuestionnaire.DraftAdministrativeData_DraftUUID,
						text: choice.text,
						question_ID: newQuestionId,
						sequence: choice.sequence,
						explanation_required: choice.explanation_required,
						high_risk_score: choice.high_risk_score
					});
				}
			}

			// Copy dependent question answers
			for (const depAnswer of dependentAnswers) {
				const newQuestionId = questionIdMapping[depAnswer.question_ID];
				const newChoiceId = choiceIdMapping[depAnswer.choices_ID];

				if (newQuestionId && newChoiceId) {
					await INSERT.into('AIEthicsQuestionnaireManagement.DependentQuestionAnswer.drafts').entries({
						ID: cds.utils.uuid(),
						IsActiveEntity: false,
						HasActiveEntity: false,
						HasDraftEntity: true,
						DraftAdministrativeData_DraftUUID: currentQuestionnaire.DraftAdministrativeData_DraftUUID,
						question_ID: newQuestionId,
						choices_ID: newChoiceId,
						createdAt: new Date(),
						createdBy: request.user.id,
						modifiedAt: new Date(),
						modifiedBy: request.user.id
					});
				}
			}

			//Copy risk scores references
			const existingRiskScoreRefs = await SELECT
                .from('AIEthicsQuestionnaireManagement.RiskScoreReferences.drafts')
                .where({ questionnaire_ID: questionnaireId });

			if(existingRiskScoreRefs.length > 0){		
				await DELETE.from('AIEthicsQuestionnaireManagement.RiskScoreReferences.drafts')
                    .where({ questionnaire_ID: questionnaireId });
			}

			for (const riskScoreRef of riskScoreReferences) {
				await INSERT.into('AIEthicsQuestionnaireManagement.RiskScoreReferences.drafts').entries({
					ID: cds.utils.uuid(),	
					IsActiveEntity: false,
					HasActiveEntity: false,
					HasDraftEntity: true,
					DraftAdministrativeData_DraftUUID: currentQuestionnaire.DraftAdministrativeData_DraftUUID,
					questionnaire_ID: questionnaireId,
					classification_code: riskScoreRef.classification_code,
					createdAt: new Date(),
					createdBy: request.user.id,
					modifiedAt: new Date(),
					modifiedBy: request.user.id,
					start: riskScoreRef.start,
					end: riskScoreRef.end
				});
			}

			const successMessage = `Successfully copied ${questionsList.length} questions, ${choicesList.length} choices, and ${dependentAnswers.length} dependent answers from version ${lastActiveQuestionnaire.version} to new draft version.`;
			return { message: successMessage };
		}
};