sap.ui.define(
    [
        'sap/fe/core/PageController',
        'gbaas/assessmentapp/utils/Helper',
        'sap/m/MessageBox'
    ],
    function(PageController, Helper, MessageBox) {
        'use strict';

        return PageController.extend('gbaas.assessmentapp.ext.view.Forms', {

//******************************** --> Start of life cycle method <--**********************/
//*************************************************************************************** */          
         
        
        onInit: function () {
            PageController.prototype.onInit.apply(this, arguments); // needs to be called to properly initialize the page controller
            // This code ensures that the onAfterBinding function inside your routing object always has the correct this context
            // if (this.routing && this.routing.onAfterBinding) {
            //     this.routing.onAfterBinding = this.routing.onAfterBinding.bind(this);
            // }
            const oModel = new sap.ui.model.json.JSONModel();
			this.getAppComponent().setModel(oModel, "oFormJsonModel");
            this.getAppComponent().getRouter().getRoute("FormsFormsPage").attachPatternMatched(this._fnOnPatternMatched, this);
               
        },   
//******************************** --> End of life cycle method <--**********************/
//*************************************************************************************** */          
   
//******************************** --> Start of Public method <--**********************/
//*************************************************************************************** */          
fnOnPressStart:function(oEvent){
     this.byId("formwizardNavContainer").to(this.byId("formwizardContentPage"));
},

fnWizardCompletedHandler: function (oEvent) {
    this.byId("formwizardNavContainer").to(this.byId("formWizardReviewPage"));
},//End of fnWizardCompleteHandler
fnFormEdit:function(oEvent){
    this.byId("formwizardNavContainer").to(this.byId("formwizardContentPage"));
},//fnFormEdit

fnT496Evaluate:function(oEvent){
    const oResponseData = this.getAppComponent()
            .getModel("oFormJsonModel")
            .getData().sections

    const aQuestionResponses = {};

    oResponseData.forEach(section => {
        const aQuestions = section.questions || [];
        aQuestions.forEach( oQuestion => {
            if(oQuestion.questionText === "Other"){
                oQuestion.questionText = oQuestion.questionText+"("+ oQuestion.section_sectionName+")";
            }
            aQuestionResponses[oQuestion["questionText"]] = oQuestion;
        });
    });
    
    // Gets the each question responses
    const oGeneralQuestion = aQuestionResponses["Is any of your cloud service end points accessible via public internet?"];
    const oAnonymousAccess = aQuestionResponses["Anonymous access"];
    const oAuthenticatedUsers = aQuestionResponses["Authenticated users"];
    const oSystemtoSystemConnectionsInbound = aQuestionResponses["System-to-system connections(inbound)"];
    const oSystemtoSystemConnectionsOutbound = aQuestionResponses["System-to-system connections(outbound)"];
    const oEmbeddedURLsFromExternalSystems = aQuestionResponses["Embedded URLs of external system"];
    const oInternalUsersidc = aQuestionResponses["Internal users (i/d/c)"];
    const oIASSAPCPIdentityAuthenticationService = aQuestionResponses["IAS(SAP CP Identity and Authentication Service)"];
    const oXSUUA = aQuestionResponses["XSUAA"];
    const oSAPIDServiceIDS = aQuestionResponses["SAP ID Service(IDS)"];
    const oCustomerIdPsusingIASasProxy = aQuestionResponses["Customer IdP(s) using IAS as Proxy"];
    const oCustomerIdPnotusingIASasProxy = aQuestionResponses["Customer IdP(s) not using IAS as Proxy"];
    const oByDesignC4C = aQuestionResponses["ByDesign / C4C"];
    const oOtherAuth = aQuestionResponses["Other(Identity provider for authenticated access)"];
    const oCPNeo = aQuestionResponses["CP Neo"];
    const oCpNeoBTPServiceSeparation = aQuestionResponses["Is the Cloud Service in scope for BTP Service Separation?"]; // Need to change the question it is temporary
    const oCpNeoBTPServiceSeparationImplemented = aQuestionResponses["Has BTP Service Separation been activated?"];// Need to change the question it is temporary
    const oCPCF = aQuestionResponses["CP CF"];
    const oCPCFBTPServiceSeparation = aQuestionResponses["Is the Cloud Service in scope for BTP Service Separation?"];// Need to change the question it is temporary
    const oCPCFBTPServiceSeparationImplemented = aQuestionResponses["Has BTP Service Separation been activated?"];// Need to change the question it is temporary
    const oCPGardner = aQuestionResponses["CP Gardner"];
    const oSAPS4HANACloud = aQuestionResponses["SAP S/4 HANA Cloud"];
    const oByDesignC4C2 = aQuestionResponses["ByDesign / C4C"];
    const oCommerceCloudv2 = aQuestionResponses["Commerce Cloud v2"];
    const oOtherPlat = aQuestionResponses["Other(Underlying SAP platform/Product)"];
    const oSAPGSCdatacenternative = aQuestionResponses["SAP GSC datacenter (native)"];
    const oHyperscalerNativeAWSGCPAzure = aQuestionResponses["Hyperscaler (native): AWS, GCP, Azure"];
    const oOtherInfra = aQuestionResponses["Other(Usage of cloud infrastructure (native consumption, in addition to the platform/products above))"];

    let message = "UnKnown",status = "Unknown";
    // The Evaluate logic implementation
    if(oGeneralQuestion.responseText === "No"){
        MessageBox.warning("None of your cloud service end points accessible via public internet");
        message = "None of your cloud service end points accessible via public internet";
        status = "Non-Compliant";
    }else if(oEmbeddedURLsFromExternalSystems.responseText === "No" && oCustomerIdPnotusingIASasProxy.responseText === "No" && oByDesignC4C.responseText === "No" && oOtherAuth.responseText === "No" && oCPGardner.responseText === "No" && oSAPS4HANACloud.responseText === "No" && oByDesignC4C2.responseText === "No" 
        && oCommerceCloudv2.responseText === "No" && oOtherPlat.responseText === "No" && oSAPGSCdatacenternative.responseText === "No" && oHyperscalerNativeAWSGCPAzure.responseText === "No" && oOtherInfra.responseText === "No"){
        MessageBox.success("Covered by SAP CP & GBaaS-Release 2 Coverage: Yes, \n GBaaS-Release 3 Coverage: Yes, BTP Service Separation activated", {title : "Compliant"});
        message = "Covered by SAP CP & GBaaS-Release 2 Coverage: Yes, GBaaS-Release 3 Coverage: Yes, BTP Service Separation activated";
        status = "Compliant";
    }else if (oIASSAPCPIdentityAuthenticationService.responseText === "Yes" && oCustomerIdPnotusingIASasProxy.responseText === "No" && oByDesignC4C.responseText === "No" && oOtherAuth.responseText === "No" && oCPGardner.responseText === "No" && oSAPS4HANACloud.responseText === "Yes"
         && oCPNeo.responseText === "No" && oOtherPlat.responseText === "No" && oSAPGSCdatacenternative.responseText === "No" && oHyperscalerNativeAWSGCPAzure.responseText === "No" && oOtherInfra.responseText === "No"){
        MessageBox.success("Covered by S/4 HANA & GBaaS-Release 2 Coverage: Yes, \n GBaaS-Release 3 Coverage: Yes, BTP Service Separation activated", {title : "Compliant"});
        message = "Covered by S/4 HANA & GBaaS-Release 2 Coverage: Yes, GBaaS-Release 3 Coverage: Yes, BTP Service Separation activated";
        status = "Compliant";
    }else if(oAnonymousAccess.responseText === "No" && oAuthenticatedUsers.responseText === "Yes" && oSystemtoSystemConnectionsInbound.responseText === "No" && oSystemtoSystemConnectionsOutbound.responseText === "No" && oInternalUsersidc.responseText === "Yes" && oCustomerIdPnotusingIASasProxy.responseText === "No" 
        && oByDesignC4C.responseText === "Yes" && oOtherAuth.responseText === "No" && oCPGardner.responseText === "No" && oSAPS4HANACloud.responseText === "No" && oByDesignC4C2.responseText === "Yes" && oCommerceCloudv2.responseText === "No" && oOtherPlat.responseText === "No"){
        MessageBox.success("Covered by SAP Business ByDesign & GBaaS-Release 2 Coverage: Yes, \n GBaaS-Release 3 Coverage: n/a, BTP Service Separation activated", {title : "Compliant"});
        message = "Covered by SAP Business ByDesign & GBaaS-Release 2 Coverage: Yes, GBaaS-Release 3 Coverage: n/a, BTP Service Separation activated";
        status = "Compliant";
    }else if(oAnonymousAccess.responseText === "No" && oEmbeddedURLsFromExternalSystems.responseText === "No" && oCustomerIdPnotusingIASasProxy.responseText === "No" && oByDesignC4C.responseText === "No" && oOtherAuth.responseText === "No" && oCPGardner.responseText === "Yes" && oSAPS4HANACloud.responseText === "No"
         && oByDesignC4C2.responseText === "No" && oCommerceCloudv2.responseText === "No" && oOtherPlat.responseText === "No" && oSAPGSCdatacenternative.responseText === "No" && oHyperscalerNativeAWSGCPAzure.responseText === "No" && oOtherInfra.responseText === "No"){
        MessageBox.warning("Covered by IAS/XSUAA & GBaaS-Release 2 Coverage: Yes, \n GBaaS-Release 3 Coverage: No, BTP Service Separation activated", {title : "Non-Compliant"});
        message = "Covered by IAS/XSUAA & GBaaS-Release 2 Coverage: Yes, GBaaS-Release 3 Coverage: No, BTP Service Separation activated";
        status = "Non-Compliant";
    }else if(oAnonymousAccess.responseText === "No" && oEmbeddedURLsFromExternalSystems.responseText === "No" && oCPNeo.responseText === "No" && oCPCF.responseText === "No"  && oCPGardner.responseText === "Yes" && oSAPS4HANACloud.responseText === "No"
         && oByDesignC4C2.responseText === "No" && oCommerceCloudv2.responseText === "Yes" && oOtherPlat.responseText === "No" && oSAPGSCdatacenternative.responseText === "No" && oHyperscalerNativeAWSGCPAzure.responseText === "No" && oOtherInfra.responseText === "No"){
        MessageBox.warning("Covered by Commerce Cloud v2 (Generic Phase 1 inbound blocking) & \n GBaaS-Release 2 Coverage: partly, admin users only, BTP Service Separation not applicable", {title : "Non-Compliant"});
        message = "Covered by Commerce Cloud v2 (Generic Phase 1 inbound blocking) & \n GBaaS-Release 2 Coverage: partly, admin users only, BTP Service Separation not applicable";
        status = "Non-Compliant";
    }else if(oAnonymousAccess.responseText === "Yes" && oEmbeddedURLsFromExternalSystems.responseText === "Yes"  && oCustomerIdPnotusingIASasProxy.responseText === "Yes" && oOtherPlat.responseText === "Yes" && oSAPGSCdatacenternative.responseText === "Yes" && oHyperscalerNativeAWSGCPAzure.responseText === "Yes" && oOtherInfra.responseText === "Yes"){
        MessageBox.warning("Please contact your GBaaS liaison for further evaluation", {title : "Non-Compliant"});
        message = "Please contact your GBaaS liaison for further evaluation";
        status = "Non-Compliant";
    };

    // Additional Evaluation
    /*
    if((oCPNeoOtherPlat.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "No" && oCPCFoOtherPlat.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "No") || 
        ((oCPNeo.responseText === "No" && oCPCFoOtherPlat.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "No") || (oCPNeooOtherPlat.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "No" && oCPCF.responseText === "No") || (oCPNeo.responseText === "No" && oCPCF.responseText === "No"))){
        console.log("BTP Service Separation not applicable");
    }else if((oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "Yes" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "No") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "No" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "Yes") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "Yes" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "Yes") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "Yes" && oCPCF.responseText === "No") || 
    (oCPNeo.responseText === "Yes" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "Yes")){
        console.log("BTP Service Separation activated");
    }else if((oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "Yes" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "No") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "No" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "Yes") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "Yes" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "No") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "No" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "Yes" && oCPCFBTPServiceSeparationImplemented.responseText === "No") || 
    (oCPNeo.responseText === "Yes" && oCpNeoBTPServiceSeparation.responseText === "Yes" && oCpNeoBTPServiceSeparationImplemented.responseText === "No" && oCPCF.responseText === "Yes" && oCPCFBTPServiceSeparation.responseText === "No")){
        console.log("BTP Service Separation not yet activated");
    }*/  // Once all the fields in UI is configured this logic will be uncommented
    
    return {message,status};
},

//******************************** --> End of Public method <--**********************/
//*************************************************************************************** */          


//******************************** --> Start of Private method <--**********************/
//*************************************************************************************** */          

_fnOnPatternMatched: async function(oEvent){
     
    try{

        this.getView().setBusy(true);
        this.getView().byId("formwizardContentPage")?.destroyContent();

        
        let oFormAssessmentsModel=new sap.ui.model.json.JSONModel();
        let oParameters = oEvent.getParameter('arguments');
        let oModel = this.getAppComponent().getModel();
        let sEntityAssessments  = `/Assessments(${oParameters?.key})`;
        let oContextsAssessments = await Helper._fnReadOdataModel(oModel,sEntityAssessments, undefined);
        oFormAssessmentsModel.setData(oContextsAssessments);
        this.getAppComponent().setModel(oFormAssessmentsModel,"oFormAssessmentsModel");


        // const oParameters = oEvent.getParameter('arguments');
    if(oParameters['?query']?.Display === 'true'){
        //write logic for display only
        const oModel = this.getAppComponent().getModel();
        const sFormType = oParameters['?query']?.formType;
        const sEntity  = `/Assessments(${oParameters?.key})/forms(${oParameters?.formsKey})/questionnaireResponses`;
        const oExpand  = {question:true};
        const sOrderBy = 'question_questionNumber asc';
        const oContexts = await Helper._fnReadOdataModel(oModel,sEntity, undefined, oExpand,sOrderBy);
        const aQuestions = oContexts?.value ?? [];
        const aSections = Helper._fnGroupByResponseSection(aQuestions);
        this.getAppComponent().getModel("oFormJsonModel").setData({"sections":aSections, "formType":sFormType, "display":true});
        this._assessmentID = oParameters.key.match(/ID=([^,]+)/)[1]; // to get assessment ID
        this.IsActiveEntity = oParameters.key.match(/IsActiveEntity=([^,]+)/)?.[1];// to get Key

        this.byId("formwizardNavContainer").to(this.byId("formWizardReviewPage"));    
    }
    else if(oParameters['?query']?.Display === 'false'){
        //write logic when create is happening

        this.byId("formwizardNavContainer").to(this.byId("formwizardLandingPage")); 

        const sFormType = oParameters['?query']?.formType;
        if(!sFormType){  return this._fnOnNavBack();}

        Helper._counter = { count: 1, sFormType:sFormType};
        //call the odata v4
        const oModel = this.getAppComponent().getModel();
        const sEntity = `/Questionnaires`;
       // const sOrderBy ='questions_questionNumber asc';
        const sFilters = `questionnaireTypeCode_code eq '${sFormType}' and isActive eq true`;
        const oExpand = {questions:{'$expand':{questionsChoices:{'$orderby':'choiceSeqNum asc'},dependentQuestions:true}, '$orderby':'questionNumber asc'}};
        const oContexts = await Helper._fnReadOdataModel(oModel,sEntity, sFilters, oExpand);
        const aQuestions = oContexts?.value[0]?.questions ?? [];
        const aSections = Helper._fnGroupBySections(aQuestions);
        this.getAppComponent().getModel("oFormJsonModel").setData({"sections":aSections, "formType":sFormType, "display":false});
        this._assessmentID = oParameters.key.match(/ID=([^,]+)/)[1]; // to get assessment ID
        this.IsActiveEntity = oParameters.key.match(/IsActiveEntity=([^,]+)/)?.[1];// to get Key

        
        
        const oWiards = new sap.m.Wizard({complete:this.fnWizardCompletedHandler.bind(this),steps:{path: 'oFormJsonModel>/sections', templateShareable:false, factory: Helper.fnCreateWizardStepsFactory.bind(Helper)}}).addStyleClass("sapUiResponsivePadding--header sapUiResponsivePadding--content");       
        this.getView().byId("formwizardContentPage")?.addContent(oWiards);

         
       
        
  
    }else{  this._fnOnNavBack(); }

     this.getView().setBusy(false);
    }catch(oErr){
    
        MessageBox.warning("Please refresh the page. If issue persist please contact admin.");
        this.getView().setBusy(false);
    }
    
    
   

},//end of _fnOnPatternMatched
    fnHandleWizardSubmit: async function (oEvent) {
                const oView = this.getView();
                const oModel = this.getOwnerComponent().getModel();

                try {
                    oView.setBusy(true);

                    // Assessment context (IMPORTANT)
                    const oAssessmentContext = oView.getBindingContext();

                    // Retrieving Assessment ID & Active flag
                    const sAssessmentID = this._assessmentID;
                    this._bIsActiveEntity =
                        this.IsActiveEntity === true || this.IsActiveEntity === "true";

                    // Form data
                    const oFormData = this.getAppComponent()
                        .getModel("oFormJsonModel")
                        .getData();

                    const aSections = oFormData.sections || [];

                    // Build questionnaire responses
                    const aResponses = [];
                    aSections.forEach(section => {
                        section.questions.forEach(questionData => {
                            aResponses.push({
                                question_questionnaire_ID: questionData.questionnaire_ID,
                                question_questionNumber: questionData.questionNumber,
                                responseText: questionData.responseText || '',
                                comment: questionData.comment || ''
                            });
                        });
                    });

                    let formstatus = '';
                    if(oFormData.formType === 'T496'){
                    const oEvaluationResult = this.fnT496Evaluate(aResponses);
                     formstatus = oEvaluationResult.status;
                    }else{
                    formstatus = 'InReview';
                    }
                    // Form payload
                    const oPayload = {
                        formType: oFormData.formType,
                        formVersion: 1,
                        questionnaire_ID:
                        oFormData.sections[0].questions[0].questionnaire_ID,
                        status_code:formstatus,
                        IsActiveEntity: this._bIsActiveEntity,
                        questionnaireResponses: aResponses
                    };

                    // Create Form under Assessment
                    const sPath = `/Assessments(ID='${sAssessmentID}',IsActiveEntity=${this._bIsActiveEntity})/forms`;
                    const oFormList = oModel.bindList(sPath);

                    const oFormContext = oFormList.create(oPayload);
                    await oFormContext.created();

                    const sFormID = oFormContext.getProperty("ID");
                    console.log("Form created with ID:", sFormID);


                    const sUpdatePath =
                        `/Assessments(ID='${sAssessmentID}',IsActiveEntity=${this._bIsActiveEntity})`;

                    const oContextBinding = oModel.bindContext(sUpdatePath);

                    // IMPORTANT: request the context first
                    const oAssessmentContext1 = await oContextBinding.requestObject();
                 

                    // Decide exception handling
                    const sExceptionHandling = 'Others';
                    ((formstatus === "Compliant" && oFormData.formType === "T496") || (oFormData.formType === "Inventory") || (oFormData.formType === "Exception")) === "allHidden";

              
                    // Now get the actual Context
                    const oBoundContext = oContextBinding.getBoundContext();

                    // Update property
                    oBoundContext.setProperty(
                        "exceptionHandlingEnabled",
                        sExceptionHandling
                    );
                    oBoundContext.setProperty(
                        "isFormSubmitted",
                        true
                    );
                    // Persist change
                    await oModel.submitBatch(oModel.getGroupId());

                    sap.m.MessageToast.show("Form submitted successfully");
                    oView.setBusy(false);
                    window.history.go(-1);

                } catch (err) {
                    console.error(err);
                    oView.setBusy(false);
                    sap.m.MessageBox.error(err.message || "Save failed");
                }
            },

    
_fnOnNavBack: function () {
    let oHistory = sap.ui.core.routing.History.getInstance();
    let sPreviousHash = oHistory.getPreviousHash();

    if (sPreviousHash !== undefined) {
        window.history.go(-1);
    } else {
        let oAppComponent = this.getAppComponent();
        let oRouter = oAppComponent.getRouter();
        oRouter.navTo(sPreviousHash);
    }
},//end of _fnOnNavBack

            fnHandleWizardCancel: function () {


                var oHistory = sap.ui.core.routing.History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    //this is not working as routing is not set correctly , Can be tested after the issue is fixed
                    const assessment = sap.ui.getCore().getModel("oFormJsonModel").getData();
                    const oAppComponent = this.getAppComponent();
                    const oRouter = oAppComponent.getRouter();
                    oRouter.navTo("AssessmentsObjectPage", true);

                }
            },

//******************************** --> End of Private method <--**********************/
//*************************************************************************************** */          
   
           
            
        });
    }
);