sap.ui.define(['sap/ui/core/mvc/ControllerExtension',
	"sap/ui/core/message/Message",
	"sap/ui/core/Fragment",
	"sap/ui/core/message/MessageType", "sap/ui/core/mvc/Controller",
	"sap/m/MessageToast", "sap/m/MessageBox", 'sap/ui/layout/form/SimpleForm'
], 
	
	function (ControllerExtension,Message, Fragment, MessageType, SimpleForm) {
	'use strict';

	return ControllerExtension.extend('aiethicsassessment.aiethicsassessmentmanagement.ext.controller.ObjectPageHeaderBackButton', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf aiethicsassessment.aiethicsassessmentmanagement.ext.controller.ObjectPageHeaderBackButton
			 */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI

				//Create Delegate tooltip
					const oDelegateButton = sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentmanagement::AIEthicsImpactAssessmentsObjectPage--fe::table::delegates::LineItem::Delegates::StandardAction::Create");
					if (oDelegateButton) {
						oDelegateButton.setTooltip("Click to add a new Delegate. Delegates are authorized to support and modify assessments in the Assessment App as needed.");
					}
			}
		},

		onAddComment: function () {

				if (this._oDialog) {
					this._oDialog.destroy();
					this._oDialog = null;
				}
				Fragment.load({
					name: "aiethicsassessment.aiethicsassessmentmanagement.ext.fragment.AddCommentDialog",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					this.getView().addDependent(this._oDialog);
					const oComboBox = sap.ui.getCore().byId("groupedQuestionnaireResponseDropdown");

					// Get the current Impact Assessment ID
					const oContext = this.getView().getBindingContext();
					const sImpactAssessmentID = oContext.getProperty("ID");

					// Bind the ComboBox with a filter
					const oBinding = oComboBox.getBinding("items");
					const oFilter = new sap.ui.model.Filter("assessment_ID", sap.ui.model.FilterOperator.EQ, sImpactAssessmentID);
					oBinding.filter([oFilter]);

					this._oDialog.open();
				}.bind(this));
			},
			onSubmitComment: async function () {
				const comment = sap.ui.getCore().byId("commentInput").getValue();
				const assessmentID = sap.ui.getCore().byId("groupedQuestionnaireResponseDropdown").getSelectedKey();

				if (!comment) {
					sap.m.MessageToast.show("Please enter a comment.");
					return;
				}

				if (!assessmentID) {
					sap.m.MessageToast.show("Please select a Grouped Questionnaire Response.");
					return;
				}

				const oView = this.getView();
				const oModel = oView.getModel();
				const oContext = oView.getBindingContext();

				const oOperation = oModel.bindContext("AIEthicsManagementService.addComment(...)", oContext);
				oOperation.setParameter("Comment", comment);
				oOperation.setParameter("AssessmentID", assessmentID);

				try {
					await oOperation.execute();
					sap.m.MessageToast.show("Comment added successfully.");
					this._oDialog.close();

					// Scroll to the bottom of the table
					const oTable = sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentmanagement::AIEthicsImpactAssessmentsObjectPage--fe::CustomSubSection::CustomComment--customCommentsTable");
					const oBinding = oTable.getBinding("items");
					oTable.bindItems({
						path: "comment",
						sorter: new sap.ui.model.Sorter("createdAt", true),
						template: oTable.getBindingInfo("items").template // Reuse the existing template
					});

					setTimeout(() => {
						const oItems = oTable.getItems();
						if (oItems.length > 0) {
							oTable.scrollToIndex(0);
						}
					}, 500);

					oModel.refresh();
				} catch (oError) {
					sap.m.MessageBox.error("Failed to add the comment: " + oError.message);
					console.error("Error while submitting comment:", oError);
					this._oDialog.close();
				}
			},
			onCancelComment: function () {
				this._oDialog.close();
			},

		onCustomNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oAppComponent = this.base.getAppComponent();
				var oRouter = oAppComponent.getRouter();
				oRouter.navTo("AIEthicsImpactAssessmentsList", {}, true);
			}
		}
	});
});
