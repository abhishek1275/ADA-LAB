sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"gbaas/assessmentreviewapp/test/integration/pages/AssessmentsList",
	"gbaas/assessmentreviewapp/test/integration/pages/AssessmentsObjectPage",
	"gbaas/assessmentreviewapp/test/integration/pages/FormsObjectPage"
], function (JourneyRunner, AssessmentsList, AssessmentsObjectPage, FormsObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('gbaas/assessmentreviewapp') + '/test/flpSandbox.html#gbaasassessmentreviewapp-tile',
        pages: {
			onTheAssessmentsList: AssessmentsList,
			onTheAssessmentsObjectPage: AssessmentsObjectPage,
			onTheFormsObjectPage: FormsObjectPage
        },
        async: true
    });

    return runner;
});

