const test_add_dependent_questions_logic = require('./code/test-add-dependent-questions-logic');
const test_questionnaires_management_activate_logic = require('./code/test-questionnaires-management-activate-logic');
const test_questionnaire_management_submit_logic = require('./code/test-questionnaire-management-submit-logic');
const test_copy_from_old_active_version_logic = require('./code/test-copy-from-old-active-version-logic');
const cds = require('@sap/cds/lib');
const {
  GET,
  POST,
  PATCH,
  DELETE,
  expect
} = cds.test(__dirname + '../../', '--with-mocks');

describe('Test for Questionnaire Management App Testing', () => {
  // it('test-add-dependent-questions-logic', async () => {
  //   await test_add_dependent_questions_logic.adddependentquestionanswerSucceed(GET, POST, PATCH, DELETE, expect);
  // });
  // it('test-add-dependent-questions-logic', async () => {
  //   await test_add_dependent_questions_logic.adddependentquestionanswerFailure(GET, POST, PATCH, DELETE, expect);
  // });
  it('test-questionnaire-management-submit-logic', async () => {
    await test_questionnaire_management_submit_logic.testQuestionnaireSubmissionSuccess(GET, POST, PATCH, DELETE, expect);
  });
  it('test-questionnaire-management-submit-logic', async () => {
    await test_questionnaire_management_submit_logic.testQuestionnaireSubmissionFailure(GET, POST, PATCH, DELETE, expect);
  });
  it('test-questionnaires-management-activate-logic', async () => {
    await test_questionnaires_management_activate_logic.testQuestionnairesManagementActivateLogicSuccess(GET, POST, PATCH, DELETE, expect);
  });
  it('test-questionnaires-management-activate-logic', async () => {
    await test_questionnaires_management_activate_logic.testQuestionnairesManagementActivateLogicFailure(GET, POST, PATCH, DELETE, expect);
  });

  it('test-copy-from-old-active-version-logic', async () => {
    await test_copy_from_old_active_version_logic.testCopyFromOldActiveVersionSuccess(GET, POST, PATCH, DELETE, expect);
  });
  it('test-copy-from-old-active-version-logic', async () => {
    await test_copy_from_old_active_version_logic.testCopyFromOldActiveVersionFailure(GET, POST, PATCH, DELETE, expect);
  });
});