/**
 * It changes the status to completed 
 * @On(event = { "Assign" }, entity = "AIEthicsManagementService.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function (request) {

    const aieID = request.params[0].ID;

    // Change the status to Completed
    await UPDATE("sapit.acoe.aiea.AIEthicsImpactAssessments").where({
        ID: aieID
    }).set({
        status_code: "Completed"
    });

    request.notify("Assessment marked as Completed");

};