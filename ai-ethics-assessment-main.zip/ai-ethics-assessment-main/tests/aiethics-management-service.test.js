const test_aiethics_management_assign_logic = require('./code/test-aiethics-management-assign-logic');
const test_aiethics_management_mark_as_completed = require('./code/test-aiethics-management-mark-as-completed');
const test_aiethics_management_mark_as_obsolete = require('./code/test-aiethics-management-mark-as-obsolete');
const test_aiethics_management_mark_action_on_requestor = require('./code/test-aiethics-management-mark-action-on-requestor');
const test_aiethics_management_mark_as_stopped = require('./code/test-aiethics-management-mark-as-stopped');
const cds = require('@sap/cds/lib');
const {
  GET,
  POST,
  PATCH,
  DELETE,
  expect
} = cds.test(__dirname + '../../', '--with-mocks');

describe('AIEthics Management Service Testing', () => {
  it('test aiethics-management-assign-logic', async () => {
    await test_aiethics_management_assign_logic(GET, POST, PATCH, DELETE, expect);
  });
  it('test aiethics-management-mark-as-completed', async () => {
    await test_aiethics_management_mark_as_completed(GET, POST, PATCH, DELETE, expect);
  });
  it('test aiethics-management-mark-as-obsolete', async () => {
    await test_aiethics_management_mark_as_obsolete(GET, POST, PATCH, DELETE, expect);
  });
    it('test aiethics-management-mark-as-stopped', async () => {
    await test_aiethics_management_mark_as_stopped(GET, POST, PATCH, DELETE, expect);
  });
    it('test aiethics-management-mark-action-on-requestor', async () => {
    await test_aiethics_management_mark_action_on_requestor(GET, POST, PATCH, DELETE, expect);
  });
});