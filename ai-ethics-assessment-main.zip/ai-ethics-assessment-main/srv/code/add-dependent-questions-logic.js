/**
 * 
 * @On(event = { "LinkDependentQuestion" }, entity = "AIEthicsQuestionnaireManagement.Questions")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function(request) {

    const currentquestionID = request.params[1];
    const { dependentQuestionAnswer} = request.data;

    if (!dependentQuestionAnswer) {
        return request.reject(400, 'DependentQuestion and ExpectedAnswer are required');
    }

    const { DependentQuestionAnswer } = cds.entities;

    //Check if mapping already exists

    const dependentQnAExist = await SELECT.one.from(DependentQuestionAnswer).where({ question_ID: currentquestionID.ID,choices_ID:dependentQuestionAnswer });
    if (!dependentQnAExist){
    // Insert the new dependent question answer
    await INSERT.into(DependentQuestionAnswer).entries({question_ID:currentquestionID.ID,choices_ID:dependentQuestionAnswer});
    
    request.notify( "Dependent question linked successfully!");

    return { message: 'Dependent question answer linked successfully' };

    } else {
        request.error(500, "Dependent Question and answer already exists for this Question"); 
    }

}