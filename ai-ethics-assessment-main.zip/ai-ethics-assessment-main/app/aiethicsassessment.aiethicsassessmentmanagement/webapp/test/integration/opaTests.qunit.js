sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'aiethicsassessment/aiethicsassessmentmanagement/test/integration/FirstJourney',
		'aiethicsassessment/aiethicsassessmentmanagement/test/integration/pages/AIEthicsImpactAssessmentsList',
		'aiethicsassessment/aiethicsassessmentmanagement/test/integration/pages/AIEthicsImpactAssessmentsObjectPage',
		'aiethicsassessment/aiethicsassessmentmanagement/test/integration/pages/QuestionnaireResponsesObjectPage'
    ],
    function(JourneyRunner, opaJourney, AIEthicsImpactAssessmentsList, AIEthicsImpactAssessmentsObjectPage, QuestionnaireResponsesObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('aiethicsassessment/aiethicsassessmentmanagement') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheAIEthicsImpactAssessmentsList: AIEthicsImpactAssessmentsList,
					onTheAIEthicsImpactAssessmentsObjectPage: AIEthicsImpactAssessmentsObjectPage,
					onTheQuestionnaireResponsesObjectPage: QuestionnaireResponsesObjectPage
                }
            },
            opaJourney.run
        );
    }
);