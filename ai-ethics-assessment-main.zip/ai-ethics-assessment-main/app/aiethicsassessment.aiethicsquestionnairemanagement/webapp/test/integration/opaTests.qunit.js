sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'aiethicsassessment/aiethicsquestionnairemanagement/test/integration/FirstJourney',
		'aiethicsassessment/aiethicsquestionnairemanagement/test/integration/pages/QuestionnairesList',
		'aiethicsassessment/aiethicsquestionnairemanagement/test/integration/pages/QuestionnairesObjectPage',
		'aiethicsassessment/aiethicsquestionnairemanagement/test/integration/pages/QuestionsObjectPage'
    ],
    function(JourneyRunner, opaJourney, QuestionnairesList, QuestionnairesObjectPage, QuestionsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('aiethicsassessment/aiethicsquestionnairemanagement') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheQuestionnairesList: QuestionnairesList,
					onTheQuestionnairesObjectPage: QuestionnairesObjectPage,
					onTheQuestionsObjectPage: QuestionsObjectPage
                }
            },
            opaJourney.run
        );
    }
);