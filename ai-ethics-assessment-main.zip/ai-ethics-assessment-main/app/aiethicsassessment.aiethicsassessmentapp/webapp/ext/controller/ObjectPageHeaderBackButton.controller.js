sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('aiethicsassessment.aiethicsassessmentapp.ext.controller.ObjectPageHeaderBackButton', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf aiethicsassessment.aiethicsassessmentapp.ext.controller.ObjectPageHeaderBackButton
			 */
			/*onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
			}*/
		},

		// Custom navigation back button handler

		onCustomNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oAppComponent = this.base.getAppComponent();
				var oRouter = oAppComponent.getRouter();
				oRouter.navTo("AIEthicsImpactAssessmentsList", {}, true);
			}
		}
	});
});
