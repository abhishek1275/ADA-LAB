sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('gbaas.assessmentapp.ext.controller.AssessmentObjectPage', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf gbaas.assessmentapp.ext.controller.AssessmentObjectPage
             */
			
			routing: {

				onBeforeNavigation:function(oEvent){
					
					const oContext = oEvent?.bindingContext;
					if(oContext){

						const sPath = oContext.getPath();
						const [sKey, sFormKey] = (sPath.match(/\([^()]*\)/g) || []).map(sKey => sKey.slice(1, -1));
						// const questionnaireID = oContext.getProperty("questionnaire_ID");
						const sFormType = oContext.getProperty("formType");
						this.base.routing.navigateToRoute("FormsFormsPage",{ "key": sKey, "formsKey":sFormKey, query:{Display:true, formType:sFormType}});
 
						 // return false to trigger the default internal navigation
						 // return true is necessary to prevent further default navigation
						 return true
					}
					
				},

				onAfterBinding: async function (oEvent) {

					if(oEvent){
						
						let sPath = oEvent.getPath();
						if(sPath){this.getView().byId("gbaas.assessmentapp::AssessmentsObjectPage--fe::CustomSubSection::Comments--idCommentsList")?.bindElement(sPath); }

						
						oEvent.getBinding()?.attachEventOnce("dataReceived",function(oDataRcvd){
							
							if(!(oDataRcvd?.getSource()?.getBoundContext()?.getProperty("HasActiveEntity"))){
								
								//1. Read query parameter value of delivery Id
								const urlParams = new URLSearchParams(window.location.search);
								let sDeliveryId = urlParams.get("sourceId") ?? 'GBAAS-ID';
								
								//2. set property value
								oDataRcvd?.getSource()?.getBoundContext()?.setProperty("sourceSystemID", sDeliveryId);

								//3. set sourceId disabled
								this.getView().byId("gbaas.assessmentapp::AssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::sourceSystemID::Field-edit").setEnabled(false);
								//gbaas.assessmentapp::AssessmentsObjectPage--fe::FormContainer::GeneratedFacet1::FormElement::DataField::sourceSystemID::Field-edit
						
						

							}//end of if
							
						}.bind(this))//end of dataRcvd

					}//end of if 



										
				}//end of onBeforeBinding




				},//end of routing

			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				//const oModel = this.base.getExtensionAPI().getModel();

				
			},//end of onInit function


		}//end of ControllerExtension 
	});
});
