const test_review_mark_as_requestChange_logic = require('./code/test-review-mark-as-requestChange-logic');
const test_review_mark_as_completed_logic = require('./code/test-review-mark-as-completed-logic');
const test_assign_logic = require('./code/test-assign-logic');
const cds = require('@sap/cds/lib');
const {
  GET,
  POST,
  PATCH,
  DELETE,
  expect
} = cds.test(__dirname + '../../', '--with-mocks');

describe('Service Testing', () => {
  it('test assign-logic', async () => {
    await test_assign_logic(GET, POST, PATCH, DELETE, expect);
  });
  it('test review-mark-as-completed-logic', async () => {
    await test_review_mark_as_completed_logic(GET, POST, PATCH, DELETE, expect);
  });
  it('test review-mark-as-requestChange-logic', async () => {
    await test_review_mark_as_requestChange_logic(GET, POST, PATCH, DELETE, expect);
  });
});
