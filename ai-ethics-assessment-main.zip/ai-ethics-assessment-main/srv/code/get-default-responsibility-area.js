/**
 * 
 * @On(event = { "defaultResponsibilityArea" }, entity = "AIEthicsManagementService.ResponsibiltyArea")
 * @param {cds.Request} request
 *  - User information, tenant-specific CDS model, headers and query parameters
*/

const httpclient = require("@sap-cloud-sdk/http-client");
const { error } = require("@sap/cds");
const logger = cds.log('aiethic-sassessment');
module.exports = async function(request) {

     try {
                    
                    const destinationName = 'aiethicsassessment-sirius-api'
                    const pathDeliveryDetails = '/zprs/api/v1/deliveryDetails?deliveryGuid='+request.data.SystemId
                    const userToken = request.user.tokenInfo?.getTokenValue();
                    const getdeliveryDetails = await httpclient.executeHttpRequest(
                        {
                            destinationName: destinationName,
                            jwt: userToken
                        },
                        {
                            method: "GET",
                            url: pathDeliveryDetails ?? "/",
                            headers: {
                                'content-type': 'application/json'
                            }
                        },
                        {
                            fetchCsrfToken: false
                        },
                    );

                    const progGuid= getdeliveryDetails.data[0].PROGRAM_GUID

                    const pathgetProgramDetails = '/zprs/api/v1/programDetails?programGuid='+ progGuid


                     const getProgramDetails = await httpclient.executeHttpRequest(
                        {
                            destinationName: destinationName,
                            jwt: userToken
                        },
                        {
                            method: "GET",
                            url: pathgetProgramDetails ?? "/",
                            headers: {
                                'content-type': 'application/json'
                            }
                        },
                        {
                            fetchCsrfToken: false
                        },
                    )

                    const siriusResponsibilityArea=getProgramDetails.data[0].DEVELOPMENT_UNIT;

                    const getRepAreaTextfromResponsibiltyAreaAPI ='/zorg/v1/productArea?id=' + siriusResponsibilityArea

                    const getResponsibiltyAreaDetails = await httpclient.executeHttpRequest(
                        {
                            destinationName: destinationName,
                            jwt: userToken
                        },
                        {
                            method: "GET",
                            url: getRepAreaTextfromResponsibiltyAreaAPI ?? "/",
                            headers: {
                                'content-type': 'application/json'
                            }
                        },
                        {
                            fetchCsrfToken: false
                        },
                    )
                    const getResponsibilityArea=getResponsibiltyAreaDetails.data.data.name;
                    if(!getResponsibilityArea){
                      return  request.error('Responsibility Area Not Found In SIRIUS');                        
                    }
    
                    return getResponsibilityArea;
                               
                }catch (error) {
                    logger.error("Failed to get default responsibility area", error);                    
                     return request.error(500,error.message);
    
                }
        
}
