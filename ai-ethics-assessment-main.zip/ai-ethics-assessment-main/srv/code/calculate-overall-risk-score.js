const { db } = require("@sap/cds");
const { message } = require("@sap/cds/lib/log/cds-error");

/**
 * Calculates the overall risk score for a given assessment draft.
 * @On(event = { "calculateOverallRiskScore" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
 * @param {Function} next - Callback function to the next handler
 * 
*/
module.exports = async function (request) {


    try {
        const assessmentdraftuuid = request.params[0].ID;
        const { f1, f2, f3, f4 } = request.params[0];
        const ID = request.params[0].ID;
       // const score = [f1, f2, f3, f4].map(s => parseFloat(s) || 0)
        const individualRiskScore = await SELECT.one.from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                .where({ ID: assessmentdraftuuid });
        const score =[individualRiskScore.processingPersonalDataRiskScore,individualRiskScore.consequenceOnPeopleRiskScore,individualRiskScore.automatedDecisionMakingRiskScore,individualRiskScore.highRiskSectorRiskScore]

        const overallscore = Math.max(...score);

        const RiskScoreReferences = await db.run(SELECT.from("sapit.acoe.aiea.RiskScoreReferences"));

        if (!RiskScoreReferences || RiskScoreReferences.length < 0) {
            request.error(400, "No risk score reference table is found")
        }

        const matched = RiskScoreReferences.find(t => overallscore >= t.start && overallscore <= t.end);
        const classification = matched ? matched.classification_code : null;

        await UPDATE('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
            .where({ ID: assessmentdraftuuid })
            .set({
                overAllRiskScore : overallscore,
                useCaseclassification_code: classification
            });

            const currentAssessmentValue = await SELECT.one.from('AIEthicsAssessment.AIEthicsImpactAssessments.drafts')
                .where({ ID: assessmentdraftuuid });

        return { ID, overallscore: currentAssessmentValue.overAllRiskScore, classification: currentAssessmentValue.useCaseclassification_code, message: "Overall risk calculated and riskstatus has been updated" };

    }

    catch (error) {
        console.error('Error calculating overall risk score:', error);
        return { error: 'Failed to calculate overall risk score' };
    }

}