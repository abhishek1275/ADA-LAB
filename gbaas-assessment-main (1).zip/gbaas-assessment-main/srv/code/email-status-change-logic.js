/**
 * It sends the mail notifications when the status gets changed (reclassification)
 * @After(event = { "CREATE","UPDATE" }, entity = "GbaasAssessment.Assessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
const path = require('path');
const MailSender = require("../email/MailSender");

module.exports = async function(results, request) {
	try {
		const employeeDataService = await cds.connect.to("employee_data");
		const { Employees } = employeeDataService.entities;
		const targetPath = path.join(__dirname,"..","email/","images");
		const assessmentId = results.ID;
		const assessmentDetails = await SELECT.one.from("sapit.acoe.gbaas.Assessments").where({ID: assessmentId});
		
		if (!assessmentDetails) {
			console.error("Assessment not found:", assessmentId);
			return;
		}

		const useCaseOwnerId = assessmentDetails.useCaseOwner;
		const requestNumber = assessmentDetails.sourceSystemID || assessmentId;
		const useCaseOwnerInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: useCaseOwnerId}));
		
		if (!useCaseOwnerInfo || !useCaseOwnerInfo.email) {
			console.error("Use case owner not found or no email:", useCaseOwnerId);
			return;
		}

		const nameOfUsecase = assessmentDetails.name;
		const status = assessmentDetails.statusCode_code;
		const useCaseClassification = assessmentDetails.useCaseclassification_code;
		const sourceSystem = assessmentDetails.sourceSystem || 'N/A';
		const ccList = "";
		const assessmentManageUrl = `${request.headers.referer}#/Assessments(ID=${assessmentId},IsActiveEntity=true)`;
		const assessmentUrl = assessmentManageUrl.replace("management-","app-");
		const delegateDetails  = await SELECT.from("sapit.acoe.gbaas.AssessmentsDelegates").columns("userID")
								.where({assessments_ID: assessmentId, toBeNotified:true});
		const delegateEmails = [];
		for (const delegate of delegateDetails) {
			const delegateUserInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: delegate.userID }));
			if (delegateUserInfo && delegateUserInfo.email) {
				delegateEmails.push(delegateUserInfo.email);
			}
		}

		const toMailList = delegateEmails.length > 0 ? [useCaseOwnerInfo.email, ...delegateEmails] : [useCaseOwnerInfo.email];

		const attachments = [{
			filename: "sap-logo.png",
			cid: "sap-logo",
			path: targetPath + "/sap-logo.png",
		  },
		  {
			filename: "Gbaas_img.png",
			cid: "center-image",
			path: targetPath + "/Gbaas_img.png",
		  }];


		if(request.data && request.data.useCaseclassificationChange ){
			const subject = "GBAAS Impact Assessment Reclassified from "+request.data.useCaseclassificationPrevious+" to "+request.data.useCaseclassificationPresent;
			const body = "We would like to inform you that your use case has been reclassified from "+request.data.useCaseclassificationPrevious +" to "+ request.data.useCaseclassificationPresent+" by the GBAAS Office.";
			const belowbody = `If you have any questions or require further clarification regarding this reclassification, please leave a comment <a href=${assessmentManageUrl}>here</a> or contact GBAAS Office.`;
			await sendMail(subject,body,belowbody);
		}

		async function sendMail(subject,bodycontent,closingcontent){
			await MailSender.getInstance().send(toMailList,ccList, subject, "status_notification_template", {
				bodycontent:bodycontent,
				name: useCaseOwnerInfo.firstName,
				requestNumber: requestNumber,
				nameOfUsecase: nameOfUsecase,
				status: status,
				sourceSystem: sourceSystem,
				belowBody: closingcontent
			},attachments);
		}
	} catch (error) {
		console.error("Failed to send email notification:", error);
	}
}
