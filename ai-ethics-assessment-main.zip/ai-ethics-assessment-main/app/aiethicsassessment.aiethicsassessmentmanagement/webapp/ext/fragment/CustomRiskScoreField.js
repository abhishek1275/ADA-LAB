sap.ui.define([
    "sap/m/MessageToast",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (MessageToast, ODataModel, Filter, FilterOperator) {
    "use strict";

    return {
        /**
         * Event handler for the press event.
         * Fetches data from the entity and binds it to the Popover.
         *
         * @param {sap.ui.base.Event} oEvent The event object.
         */
        onPress: function (oEvent) {

            // Get the source of the event (the button)
            const oButton = oEvent.getSource();
            const oView = oButton.getParent().getParent(); // Adjust this based on your layout
            // Define the ODataModel (replace with your service URL)

            const ServicePath = (window.location.hostname === "localhost" || window.location.hostname.includes("applicationstudio.cloud.sap"))
							? "/service/AIEthicsManagementService"
							: "./service/AIEthicsManagementService";
            const sServiceUrl = ServicePath; // Replace with your OData service URL
            const oModel = new ODataModel({
                serviceUrl: sServiceUrl + "/",
                synchronizationMode: "None",
                autoExpandSelect: true
            });

            // Create the List
            const oList = new sap.m.List({
                class: "sapUiLargeMarginBegin"
            });

            // Bind the List to the entity set with filters and sorters
            oList.bindItems({
                path: "/RiskScoreReferences", // Entity set path
                parameters: {
                    $filter: "questionnaire/isActive eq true", // OData V4 filter syntax
                    $orderby: "start asc" // OData V4 sorting syntax
                },
                template: new sap.m.CustomListItem({
                    content: [
                        new sap.m.ObjectStatus({
                            text: " {='   ' + ${classification/code} + ': ' + ${start} + ' - ' + ${end} }",
                            state: "{= Number(${classification/criticality}) === 1 ? 'Error' : " +
                                "Number(${classification/criticality}) === 2 ? 'Warning' : " +
                                "'Success' }"
                        })
                    ]
                })
            });

            // Check if the Popover already exists
            if (!this._oLegendPopover) {
                this._oLegendPopover = new sap.m.Popover({
                    title: "Risk Score Legend",
                    contentWidth: "200px",
                    content: oList
                });

                // Add the Popover as a dependent to the view
                oView.addDependent(this._oLegendPopover);
            }

            // Set the ODataModel on the view
            oView.setModel(oModel, "popoverModel");

            // Open the Popover next to the button
            this._oLegendPopover.openBy(oEvent.getSource());
        }
    };
});