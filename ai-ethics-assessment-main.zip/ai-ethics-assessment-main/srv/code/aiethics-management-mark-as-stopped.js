/**
 * It will update the status
 * @On(event = { "CREATE","UPDATE" }, entity = "AIEthicsAssessment.AIEthicsImpactAssessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
module.exports = async function (request) {

	const aieID = request.params[0].ID;

	await UPDATE("sapit.acoe.aiea.AIEthicsImpactAssessments").where({
		ID: aieID
	}).set({
		status_code: 'Stopped'
	});

	//Update the comments
	if (request.data.reason) {
		const comment = {
			useCase_ID: aieID,
			comment: "Reason for Stopped: " + request.data.reason,
		};
		await INSERT.into("sapit.acoe.aiea.Comments").entries(comment);
	}
	request.notify("Usecase has been marked as Stopped!!!");

}