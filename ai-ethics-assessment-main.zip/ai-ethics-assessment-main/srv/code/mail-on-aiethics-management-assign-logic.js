/**
 * It sends the mail notifications when the status gets changed as In Review
 * @After(event = { "Assign" }, entity = "AIEthicsManagementService.AIEthicsImpactAssessments")
 * @param {(Object|Object[])} results - For the After phase only: the results of the event processing
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
*/
const path = require('path');
const MailSender = require("../email/MailSender");

module.exports = async function(results, request) {
    const employeeDataService = await cds.connect.to("employee_data");
    const { Employees } = employeeDataService.entities;
    const targetPath = path.join(__dirname,"..","email/","images");
	const assessmentId = request.params[0].ID;
	const assessmentDetails = await SELECT.one("sapit.acoe.aiea.AIEthicsImpactAssessments").where({ID: assessmentId});
	const reportManagerId = assessmentDetails.createdBy;
	const requestNumber = 'AIE-' + String(assessmentDetails.aiEthicsAssessment_id).padStart(7,'0');
	const reportManagerInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: reportManagerId}));
	const nameOfUsecase = assessmentDetails.name;
	const status = assessmentDetails.status_code;
	const useCaseClassification = assessmentDetails.useCaseclassification_code
	const sourceSystem = assessmentDetails.sourceSystem;
	const ccList = "";
	const assessmentManageUrl = `${request.headers.referer}#/AIEthicsImpactAssessments(ID=${assessmentId},IsActiveEntity=true)`;
	const assessmentUrl = assessmentManageUrl.replace("aiethicsassessmentmanagement","aiethicsassessmentapp");
	const delegateDetails  = await SELECT.from("sapit.acoe.aiea.AIEthicsAssessmentsDelegates").columns("userID")
                            .where({aIEthicsImpactAssessment_ID: assessmentId, toBeNotified:true});
    const delegateEmails = [];
    for (const delegate of delegateDetails) {
        const delegateUserInfo = await employeeDataService.run(SELECT.one.from(Employees).where({ ID: delegate.userID }));
        delegateEmails.push(delegateUserInfo.email);
    };

    const toMailList = delegateEmails.length > 0 ? [reportManagerInfo.email, ...delegateEmails] : [reportManagerInfo.email];

    const attachments = [{
		filename: "sap-logo.png",
		cid: "sap-logo",
		path: targetPath + "/sap-logo.png",
	  },
	  {
		filename: "impact-assessment.png",
		cid: "center-image",
		path: targetPath + "/impact-assessment.png",
	}];

    if (status == "In Review"){
        const subject = "AI Ethics Assessment Status Update - In Review";
        const body = "Your assessment has been picked up by AI Ethics Office for review. Our team will reach out to you shortly for further discussion or clarification required.";
        const belowbody = `Please ensure you review the comments section for queries or feedback. To view the request click <a href=${assessmentUrl}>here</a>`;
        sendMail(subject,body,belowbody);
    }

    async function sendMail(subject,bodycontent,closingcontent){
		await MailSender.getInstance().send(toMailList,ccList, subject, "status_notification_template", {
			bodycontent:bodycontent,
			name: reportManagerInfo.firstName,
			requestNumber: requestNumber,
			nameOfUsecase: nameOfUsecase,
			status: status,
			sourceSystem: sourceSystem,
			belowBody: closingcontent
		},attachments);
	}
}