sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"gbaas/assessmentapp/test/integration/pages/AssessmentsList",
	"gbaas/assessmentapp/test/integration/pages/AssessmentsObjectPage"
], function (JourneyRunner, AssessmentsList, AssessmentsObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('gbaas/assessmentapp') + '/test/flpSandbox.html#gbaasassessmentapp-tile',
        pages: {
			onTheAssessmentsList: AssessmentsList,
			onTheAssessmentsObjectPage: AssessmentsObjectPage
        },
        async: true
    });

    return runner;
});

