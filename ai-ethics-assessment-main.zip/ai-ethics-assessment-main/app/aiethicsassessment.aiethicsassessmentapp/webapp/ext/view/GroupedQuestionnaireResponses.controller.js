sap.ui.define(
    [
        'sap/fe/core/PageController',
        'sap/ui/model/odata/type/Date'
    ],
    function (PageController, ODataDate) {
        'use strict';
        return PageController.extend('aiethicsassessment.aiethicsassessmentapp.ext.view.GroupedQuestionnaireResponses', {
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf aiethicsassessment.aiethicsassessmentapp.ext.view.QuestionnaireResponses
             */

            onInit: async function () {
                PageController.prototype.onInit.apply(this, arguments);
                this.isBtnVisible = false;
                if (!this._isModelContextChangeAttached) {
                    this.getView().attachModelContextChange(this.onAfterBinding, this);
                    this._isModelContextChangeAttached = true;
                }

                // Add a flag to ensure the event listener is attached only once


                // This code ensures that the onAfterBinding function inside your routing object always has the correct this context
                if (this.routing && this.routing.onAfterBinding) {
                    this.routing.onAfterBinding = this.routing.onAfterBinding.bind(this);
                }
                //  console.log("Routing object:", this.routing);
                //console.log("onAfterBinding function:", this.routing?.onAfterBinding);
                //   const oBindingContext = this.base.getView().getBindingContext();
                //  console.log("oBindingContext in onInit:", oBindingContext);
            },
            onAfterBinding: async function () {
                if (this._isProcessingOnAfterBinding) {
                    console.log("onAfterBinding is already processing. Skipping redundant call.");
                    return;
                }
                this._isProcessingOnAfterBinding = true;
                try {
                    const oView = this.getView(); // Replaced this.base.getView() with this.getView()
                    console.log('Inside On after binding');

                    // Check if the model is defined
                    let oModel = await oView.getModel();
                    let oModelCore = sap.ui.getCore().getModel();
                    if (!oModel) {
                        console.warn("Model is not immediately available. Retrying...");

                        // Retry mechanism to wait for the model to be set
                        await new Promise(resolve => setTimeout(resolve, 1000));
                        oModel = oView.getModel();

                        if (!oModel) {
                            console.error("Model is still not set on the view.");
                            return;
                        }
                    }

                    // Check if the binding context is defined
                    const oContext = await oView.getBindingContext();
                    if (!oContext) {
                        console.error("Binding context is not available.");
                        return;
                    }

                    const oPage = this.byId("QuestionnaireResponses");
                    oPage.setBusy(true);
                    oPage.setEnableScrolling(false);
                    const that = this;
                    // Uncomment for testing loading behaviour: await new Promise(resolve => setTimeout(resolve, 15000));
                    try {
                        const oBindingGroupedResponses = oModel.bindList("/GroupedQuestionnaireResponses");
                        const oBinding = oModel.bindList("/Questions");
                        const oBindingChoices = oModel.bindList("/Choices");
                        const oBindingQuentionnaire = oModel.bindList("/Questionnaires");
                        const oBindingDependent = oModel.bindList("/DependentQuestionAnswer");

                        const questionnaireContextData = await this.loadAllContexts(oBindingQuentionnaire);
                        await this.loadAllContexts(oBindingChoices);
                        await this.loadAllContexts(oBindingDependent);

                        const questionmodel = new sap.ui.model.json.JSONModel();
                        const choiceModel = new sap.ui.model.json.JSONModel();
                        const questionData = [];
                        const dataQuestion = {};
                        const totalChoices = [];
                        const questionIDs = [];
                        const DependentQuestions = [];
                        const DependentQuestionIDs = [];
                        const questionnaireData = [];
                        let impactFilterData = [];
                        let policyFilterData = [];
                        let isNewAssessment = "", readOnly = "";

                        const urlPath = oContext.getPath();
                        const gQRregex = /groupedQuestionnaireResponse\(ID=([^,]+),/;
                        const groupedQRID = urlPath.match(gQRregex)[1];
                        let isEditable = false, isUseCaseImpact = false;

                        let assessmentID = "", AssessmentValue = {}, AssessmentObj = {};

                        let currentQuestionnaireID = ''; let currentQuestionnaireCode = "";
                        let aiOfficerEmail = "";
                        let activeQuestionnaireData = {};

                        try {
                            await oModel.bindContext(urlPath, null, { $expand: "questionnaire,assessment" })
                                .requestObject().then((oQuestionaireData) => {
                                    aiOfficerEmail = oQuestionaireData.questionnaire?.email;
                                    assessmentID = oQuestionaireData.assessment_ID;
                                    currentQuestionnaireID = oQuestionaireData.questionnaire.ID;
                                    currentQuestionnaireCode = oQuestionaireData.questionnaire.questionnairetype_code;
                                    if (currentQuestionnaireCode == "Usecase Impact Assessment") {
                                        isUseCaseImpact = true;
                                    }

                                    AssessmentObj = {
                                        ID: oQuestionaireData.assessment_ID,
                                        isEditBtn: oQuestionaireData.IsActiveEntity,
                                        isActiveEntity: oQuestionaireData.IsActiveEntity
                                    }
                                    let assessmentStatusCode = oQuestionaireData.assessment.status_code;
                                    if ((assessmentStatusCode == "New" || assessmentStatusCode == "Draft" || assessmentStatusCode == "Ready To Submit" || assessmentStatusCode == "Action On Requestor")) {
                                        AssessmentObj.isNewOrAction = true;
                                    } else AssessmentObj.isNewOrAction = false

                                    //Add here
                                    let highRiskVal = { classification: oQuestionaireData.assessment.initialClassification_code };
                                    let highRiskValModel = new sap.ui.model.json.JSONModel(highRiskVal);
                                    this.getView().setModel(highRiskValModel, "highRiskVal");
                                });
                        } catch (e) { };

                        const questionnairePath = `/Questionnaires(${currentQuestionnaireID})`;
                        const ctx = questionnaireContextData.find(c => c.getPath && c.getPath() === questionnairePath);
                        const obj = ctx.getObject();
                        activeQuestionnaireData = {
                            ID: obj.ID,
                            code: obj.questionnairetype_code,
                            version: obj.version,
                            modifiedAt: obj.modifiedAt,
                            aiOfficerEmail: aiOfficerEmail,
                            isActive: obj.isActive
                        }

                        try {
                            // try to get from object page
                            // AssessmentValue = sap.ui.getCore().getModel("assessmentModel").getData();
                            const assessmentModel = new sap.ui.model.json.JSONModel(AssessmentObj);
                            sap.ui.getCore().setModel(assessmentModel, "assessmentModel");
                            AssessmentValue = sap.ui.getCore().getModel("assessmentModel").getData();
                            AssessmentValue.path = `/${urlPath.split("/")[1]}`;
                        }
                        catch (e) { }

                        AssessmentValue.questionnaireID = activeQuestionnaireData.ID;
                        AssessmentValue.code = activeQuestionnaireData.code;
                        AssessmentValue.isActive = activeQuestionnaireData.isActive;

                        let messageStripObj = { impactAssessmentText: "", policyAssessmentText: "", impactVisible: false, policyVisible: false };

                        if (AssessmentValue.isEditBtn == true && AssessmentValue.isNewOrAction == true) {
                            messageStripObj.impactAssessmentText = "You’re viewing this form in read-only mode. To make changes, please return to the previous screen and click <strong>Edit</strong>.";
                            messageStripObj.policyAssessmentText = messageStripObj.impactAssessmentText;
                            messageStripObj.impactVisible = true;
                            messageStripObj.policyVisible = true;
                            readOnly = "(Read Only)";
                        }
                        else if (AssessmentValue.isNewOrAction == false) {
                            messageStripObj.impactAssessmentText = "This form has already been submitted and can no longer be edited.";
                            messageStripObj.impactVisible = true;
                            readOnly = "(Read Only)";
                        } else {
                            messageStripObj.impactAssessmentText = "";
                            messageStripObj.policyAssessmentText = ""
                        }

                        let messageStripData = new sap.ui.model.json.JSONModel(messageStripObj);
                        this.getView().setModel(messageStripData, "messageStripDataModel");

                        let impactHeadingData = new sap.ui.model.json.JSONModel(activeQuestionnaireData);
                        this.getView().setModel(impactHeadingData, "impactHeadingDataModel");

                        let policyHeadingData = new sap.ui.model.json.JSONModel(activeQuestionnaireData);
                        this.getView().setModel(policyHeadingData, "policyHeadingDataModel");

                        let progressIndicatorObj = { currentSection: "1", totalSection: "", value: "0" };
                        let progressIndicatorData = new sap.ui.model.json.JSONModel(progressIndicatorObj);
                        this.getView().setModel(progressIndicatorData, "ProgressIndicatorModel");
                        const ProgressIndicatorModel = this.getView().getModel("ProgressIndicatorModel");

                        if (isUseCaseImpact) {
                            ProgressIndicatorModel.setProperty("/totalSection", "6");
                            ProgressIndicatorModel.setProperty("/value", "17");
                        }
                        else {
                            ProgressIndicatorModel.setProperty("/totalSection", "7");
                            ProgressIndicatorModel.setProperty("/value", "15");
                        }


                        await oModel.bindContext(oBindingGroupedResponses.getPath()).requestObject().then((aContexts) => {
                            aContexts.value?.forEach(function (oContext) {
                                const responseData = oContext;
                                if (responseData.assessment_ID == assessmentID && responseData.questionnaire_ID == currentQuestionnaireID) {
                                    switch (currentQuestionnaireCode) {
                                        case "Usecase Impact Assessment":
                                            impactFilterData.push(responseData);
                                            break;
                                        case "Policy Self Assessment":
                                            policyFilterData.push(responseData);
                                            break;
                                    }
                                }
                            })

                            // Check if it's New Assessment or in Draft
                            const isDraftData = aContexts.value?.find(function (item) {
                                return item.ID === groupedQRID;
                            });

                            const getLatestVersion = (data) =>
                                data.length > 0 ? data.reduce((max, item) => item.version > max.version ? item : max, data[0]) : null;

                            const latestImpact = getLatestVersion(impactFilterData);
                            const latestPolicy = getLatestVersion(policyFilterData);

                            const latestImptVerData = impactFilterData.find(item => item.Status_code === "Done");
                            const latestPolicyVerData = policyFilterData.find(item => item.Status_code === "Done");

                            let impactVersion = latestImpact ? latestImpact.version : 0;
                            let policyVersion = latestPolicy ? latestPolicy.version : 0;

                            // if ((latestImpact?.ID == groupedQRID && AssessmentValue.isNewOrAction === true) || !isDraftData) {
                            //     isEditable = true;
                            // } else if (latestImpact?.ID != groupedQRID && isNewAssessment != "Create" && isUseCaseImpact === true) {
                            //     isEditable = false;
                            //     this.getView().getModel("messageStripDataModel").setProperty("/impactAssessmentText", "You are viewing an older version of this assessment. Editing is only allowed in the latest version.")
                            //     this.getView().getModel("messageStripDataModel").setProperty("/impactVisible", true);
                            //     readOnly = "(Read Only)";
                            // }

                            // if ((latestPolicy?.ID == groupedQRID) || !isDraftData) {
                            //     isEditable = true;
                            // } else if (latestPolicy?.ID != groupedQRID && isNewAssessment != "Create" && isUseCaseImpact === false) {
                            //     isEditable = false;
                            //     this.getView().getModel("messageStripDataModel").setProperty("/policyAssessmentText", "You are viewing an older version of this assessment. Editing is only allowed in the latest version.")
                            //     this.getView().getModel("messageStripDataModel").setProperty("/policyVisible", true);
                            //     readOnly = "(Read Only)";
                            // }

                            const msgModel = this.getView().getModel("messageStripDataModel");
                            const showOlderVersionMessage = (textProp, visibleProp) => {
                                msgModel.setProperty(`/${textProp}`,
                                    "You are viewing an older version of this assessment. Editing is only allowed in the latest version."
                                );
                                msgModel.setProperty(`/${visibleProp}`, true);
                                readOnly = "(Read Only)";
                            };

                            // ----- IMPACT ASSESSMENT -----
                            if (isUseCaseImpact === true) {
                                if ((latestImpact?.ID === groupedQRID && AssessmentValue.isNewOrAction === true) || !isDraftData) {
                                    isEditable = true;
                                } else if (isNewAssessment !== "Create") {
                                    isEditable = false;
                                    showOlderVersionMessage("impactAssessmentText", "impactVisible");
                                }
                            }

                            // ----- POLICY ASSESSMENT -----
                            if (isUseCaseImpact === false) {
                                if ((latestPolicy?.ID === groupedQRID) || !isDraftData) {
                                    isEditable = true;
                                } else if (isNewAssessment !== "Create") {
                                    isEditable = false;
                                    showOlderVersionMessage("policyAssessmentText", "policyVisible");
                                }
                            }

                            if (!AssessmentValue.isActive) {
                                isEditable = false;
                                msgModel.setProperty(`/impactAssessmentText`, "You are viewing an in-active version of this assessment. Editing is only allowed in the active version.");
                                msgModel.setProperty(`/impactVisible`, true);
                                msgModel.setProperty(`/policyAssessmentText`, "You are viewing an in-active version of this assessment. Editing is only allowed in the active version.");
                                msgModel.setProperty(`/policyVisible`, true);
                                readOnly = "(Read Only)";
                            }

                            const versionModel = new sap.ui.model.json.JSONModel({
                                "impactVersion": impactVersion,
                                "policyVersion": policyVersion
                            });

                            sap.ui.getCore().setModel(versionModel, "versionModel");
                            if (AssessmentValue.isEditBtn || (AssessmentValue.isNewOrAction == false && isUseCaseImpact == true)) {
                                isEditable = false;
                            }

                            if ((aContexts?.length == 0) || !isDraftData) {
                                isEditable = true;
                            }
                            if (isEditable) readOnly = "";
                        }).catch(function (e) { });

                        let isExecuted = false;
                        await oModel.bindContext(oBinding.getPath(), null, { $expand: "section" }).requestObject().then((aContexts) => {
                            aContexts.value.forEach(function (oContext) {
                                const oData = oContext;
                                if (oData.questionnaire_ID == currentQuestionnaireID) {
                                    if (!isExecuted) {
                                        isExecuted = true;
                                        let choices = 0; let dependentQ = 0; let questionnaire = 0;
                                        oBinding.oModel.aAllBindings.forEach(function (aBinding) {
                                            if (aBinding.sPath == "/Choices") {
                                                if (choices == 0) {
                                                    aBinding.aContexts.forEach(function (oChoiceContext) {
                                                        const choiceData = oChoiceContext.getObject();
                                                        choiceData.selected = 'false';
                                                        totalChoices.push(choiceData);
                                                        questionIDs.push(choiceData.question_ID);
                                                    })
                                                    choices++;
                                                }
                                            }
                                            if (aBinding.sPath == "/DependentQuestionAnswer") {
                                                if (dependentQ == 0) {
                                                    aBinding.aContexts.forEach(function (oChoiceContext) {
                                                        const DependentData = oChoiceContext.getObject();
                                                        DependentQuestions.push(DependentData);
                                                        DependentQuestionIDs.push(DependentData.question_ID);
                                                    })
                                                    dependentQ++;
                                                }
                                            }
                                            if (aBinding.sPath == "/Questionnaires") {
                                                if (questionnaire == 0) {
                                                    aBinding.aContexts.forEach(function (oChoiceContext) {
                                                        const QuestionnaireDataObject = oChoiceContext.getObject();
                                                        questionnaireData.push(QuestionnaireDataObject);
                                                    })
                                                    questionnaire++;
                                                }
                                            }
                                        })
                                    }
                                    const questionChoices = [];
                                    const questionDependent = [];
                                    if (questionIDs.includes(oData.ID)) {
                                        totalChoices.forEach(function (oChoiceContext) {
                                            if (oChoiceContext.question_ID === oData.ID) {
                                                questionChoices.push(oChoiceContext);
                                            }
                                        })
                                        oData.choices = questionChoices;
                                    }
                                    else
                                        oData.responseText = '';

                                    if (DependentQuestionIDs.includes(oData.ID)) {
                                        DependentQuestions.forEach(function (oChoiceContext) {
                                            if (oChoiceContext.question_ID === oData.ID) {
                                                questionDependent.push(oChoiceContext);
                                            }
                                        })
                                        oData.dependsOnQuestionAnswerValue = questionDependent;
                                        oData.visibility = "false";
                                    }
                                    else
                                        oData.visibility = "true";
                                    questionnaireData.forEach(function (oQuestionnaireContext) {
                                        if (oQuestionnaireContext.ID == oData.questionnaire_ID) {
                                            oData.questionnaireType = oQuestionnaireContext.questionnairetype_code;
                                        }
                                    });
                                    oData.otherResponse = '';
                                    // Explanation Required
                                    oData.explanationRequired = false;
                                    oData.isEditable = isEditable;
                                    oData.textValueState = "None";
                                    oData.choiceValueState = "None";
                                    oData.otherValueState = "None";
                                    oData.explValueState = "None";

                                    oData.valueStateText = "";
                                    questionData.push(oData);
                                }
                            });
                            choiceModel.setData(totalChoices);
                            sap.ui.getCore().setModel(choiceModel, "choiceModel");
                            const demoModel = new sap.ui.model.json.JSONModel({
                                "results": questionData
                            });

                            const impactVersionData = questionnaireData.filter(
                                item => item.questionnairetype_code === "Usecase Impact Assessment" && item.submitted == true
                            );

                            const policyVersionData = questionnaireData.filter(
                                item => item.questionnairetype_code === "Policy Self Assessment" && item.submitted == true
                            );

                            const impactQuestionnaireModel = new sap.ui.model.json.JSONModel({
                                "results": impactVersionData
                            });

                            const policyQuestionnaireModel = new sap.ui.model.json.JSONModel({
                                "results": policyVersionData
                            });

                            if (isUseCaseImpact)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--impactVersionList").setModel(impactQuestionnaireModel, "questionnaireModel");
                            else
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--policySelfVersionList").setModel(policyQuestionnaireModel, "questionnaireModel");

                            questionmodel.setData(dataQuestion);
                            const ImpactAssessmentFilter = new sap.ui.model.Filter("questionnaireType", sap.ui.model.FilterOperator.Contains, "Usecase Impact Assessment");
                            const PolicySelfAssessmentFilter = new sap.ui.model.Filter("questionnaireType", sap.ui.model.FilterOperator.Contains, "Policy Self Assessment");

                            const GeneralUserCaseSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "General Usecase Information");
                            const ProhibitedSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Determining Prohibited Use Cases");
                            const HighRiskSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Determining High-Risk Use Cases");
                            const EUActSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "EU AI Act Compliance Assessment");
                            const HarmlessSecuritySection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Harmlessness, Safety and Security");
                            const EnableHumanAgencySection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Enable Human Agency and Oversight");
                            const AvoidingBiasSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Avoid Bias and Discrimination");
                            const EnsureTransparencySection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Ensure Transparency and Explainability");

                            const GeneralUseCaseFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, GeneralUserCaseSection], and: true });
                            const ProhibitedFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, ProhibitedSection], and: true });
                            const HighRiskFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, HighRiskSection], and: true });
                            const EUActFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, EUActSection], and: true });
                            const GeneralUseCaseFilterPS = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, GeneralUserCaseSection], and: true });
                            const HarmlessSecurityFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, HarmlessSecuritySection], and: true });
                            const EnableHumanAgencyFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, EnableHumanAgencySection], and: true });
                            const AvoidingBiasFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, AvoidingBiasSection], and: true });
                            const EnsureTransparencyFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, EnsureTransparencySection], and: true });

                            sap.ui.getCore().setModel(demoModel, "ViewModel");
                            //                   sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").unbindItems();
                            //                   sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").bindItems({
                            //     path: "demoModel>/results",
                            //     sorter: new sap.ui.model.Sorter("questionNumber", false),
                            //     template: oTemplate // reuse XML template
                            // });
                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").setData(demoModel.getData());
                            }

                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getBinding("items").filter(GeneralUseCaseFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--prohibitedUseCaseList").getBinding("items").filter(ProhibitedFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--highRiskUseCaseList").getBinding("items").filter(HighRiskFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getModel("demoModel").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--EUActList").getBinding("items").filter(EUActFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO1").getBinding("items").filter(GeneralUseCaseFilterPS);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--harmlessSecuritySectionList").getBinding("items").filter(HarmlessSecurityFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--enableHumanAgencySectionList").getBinding("items").filter(EnableHumanAgencyFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getBinding("items").refresh();

                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--avoidingBiasSectionList").getBinding("items").filter(AvoidingBiasFilter);

                            if (sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getModel("demoModel") == undefined)
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").setModel(demoModel, "demoModel");
                            else {
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getModel("demoModel").getData().results = demoModel.getData().results;
                                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getModel("demoModel").setData(demoModel.getData());
                            }
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getModel("demoModel").refresh;
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getModel("demoModel").refresh(true);
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getBinding("items").refresh();
                            sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ensureTransparencySectionSectionList").getBinding("items").filter(EnsureTransparencyFilter);
                            let demoData;
                            const model = oContext.getModel();
                            const path = oContext.getPath();
                            var assesmentPath = path.split("/groupedQuestionnaireResponse")[0]; let questionnaireID; let questionnaireType;
                            const gQregex = /groupedQuestionnaireResponse\(ID=([^,]+),/;
                            const groupedQID = path.match(gQregex)[1];
                            if (isNewAssessment != "Create") {
                                model.bindContext(path).requestObject().then(async function (oData) {
                                    questionnaireID = AssessmentValue.questionnaireID;
                                    questionnaireType = AssessmentValue.code;
                                    let assessmentType;
                                    console.log('OnAfterbinding - calling _onInitPanelVisibility');
                                    await that._onInitPanelVisibility(oView, questionnaireType, readOnly);
                                    if (questionnaireType == "Usecase Impact Assessment")
                                        assessmentType = "ImpactAssessment";
                                    else assessmentType = "PolicySelfAssessment";
                                    const assessmentTypeData = { assessmentType: assessmentType, groupedQID: groupedQID };
                                    const jsonModel = new sap.ui.model.json.JSONModel(assessmentTypeData);
                                    sap.ui.getCore().setModel(jsonModel, "assessmentType");
                                });

                                const oDemoControl = sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO");
                                const oDemoModel = oDemoControl.getModel("demoModel");
                                if (sap.ui.getCore().getModel("ViewModel") != undefined) {
                                    demoData = sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").getData();

                                    model.bindContext(path + "/questionnaireResponse").requestObject().then(function (aContexts) {
                                        aContexts.value.forEach(function (oContext) {
                                            if (groupedQID == oContext.groupedQuestionnaireResponse_ID && demoData != undefined) {
                                                const iIndex = demoData.results.findIndex(item => item.ID === oContext.question_ID);
                                                if (iIndex > -1) {
                                                    const sPath = "/results/" + iIndex;

                                                    oDemoModel.setProperty(sPath + "/visibility", "true");
                                                    if (demoData.results[iIndex].responseType_code == "TEXT")
                                                        oDemoModel.setProperty(sPath + "/responseText", oContext.responseText);
                                                    if (demoData.results[iIndex].responseType_code == "CHOICE") {
                                                        const jIndex = demoData.results[iIndex].choices.findIndex(item => item.ID === oContext.responseChoice_ID);
                                                        if (jIndex > -1) {
                                                            oDemoModel.setProperty(sPath + "/choices/" + jIndex + "/selected", 'true');
                                                        }
                                                        if (oContext.responseText && oContext.responseText != "") {
                                                            demoData.results[iIndex].otherResponse = "other";
                                                            oDemoModel.setProperty(sPath + "/responseText", oContext.responseText);
                                                        }
                                                    }
                                                }
                                            }
                                        })
                                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").refresh;
                                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getModel("demoModel").refresh(true);
                                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--ID_DEMO").getBinding("items").refresh();
                                    });
                                }
                            }
                        }).catch(function (oError) { });


                        if (sap.ui.getCore().getModel("assessmentType") != undefined) {
                            const data = sap.ui.getCore().getModel("assessmentType").getData();// needs to be called to properly initialize the page controller
                            console.log('OnAfterbinding - calling _onInitPanelVisibility is not undefined');
                            //   await that._onInitPanelVisibility(oView, data.assessmentType, readOnly);
                        }
                    } catch (e) {
                        const that = this;
                        sap.m.MessageBox.error("Service is not available. Please try again later.", {
                            onClose: function () {
                                // Navigate back in browser history
                                var oHistory = sap.ui.core.routing.History.getInstance();
                                var sPreviousHash = oHistory.getPreviousHash();
                                const assessmentID = sap.ui.getCore().getModel("assessmentModel").getData().ID;
                                const isActive = sap.ui.getCore().getModel("assessmentModel").getData().IsActiveEntity;

                                if (assessmentID !== undefined) {
                                    var oAppComponent = that.getAppComponent();
                                    var oRouter = oAppComponent.getRouter();
                                    oRouter.navTo("AIEthicsImpactAssessmentsObjectPage", { key: `ID=${assessmentID},IsActiveEntity=${isActive}` }, true);
                                }
                                else if (sPreviousHash !== undefined) {
                                    window.history.go(-1);
                                }
                            }
                        });
                        oPage.setBusy(false);
                        oPage.setEnableScrolling(true);
                    }

                    setTimeout(function () {
                        oPage.setBusy(false);
                        oPage.setEnableScrolling(true);
                    }, 0);
                } finally {
                    this._isProcessingOnAfterBinding = false;

                }
            },


            onCustomNavBack: function () {
                var oHistory = sap.ui.core.routing.History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    //this is not working as routing is not set correctly , Can be tested after the issue is fixed
                    const assessment = sap.ui.getCore().getModel("assessmentModel").getData();
                    const oAppComponent = this.getAppComponent();
                    const oRouter = oAppComponent.getRouter();
                    oRouter.navTo("AIEthicsImpactAssessmentsObjectPage", { key: `ID=${assessment.ID},IsActiveEntity=${assessment.isActiveEntity}` }, true);

                }
            },
            onPressNextImpactAssessment: async function () {
                const viewModel = sap.ui.getCore().getModel("ViewModel");
                const data = viewModel?.getData()?.results?.[0];
                this.isBtnVisible = data.isEditable;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "2");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "34");

                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
            },

            onPressNextPolicySelfAssessment: function () {
                const viewModel = sap.ui.getCore().getModel("ViewModel");
                const data = viewModel?.getData()?.results?.[0];
                this.isBtnVisible = data.isEditable;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "2");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "30");

                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSectionPS").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHarmlessSecuritySection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnableHumanAgencySection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelAvoidingBiasSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnsureTransparencySection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelThankYouSection").setVisible(false);
            },

            formatQuestionNumber: function (questionNumber) {
                if (questionNumber !== undefined && questionNumber !== null) {
                    return questionNumber + ". ";
                }
                else
                    return "";
            },

            dateFormatter: function (dateValue) {
                const type = new ODataDate({
                    pattern: "MMMM yyyy"
                });
                return type.formatValue(new Date(dateValue), "string");
            },

            onInputChange: function (oEvent) {
                const oInput = oEvent.getSource();
                const sValue = oInput.getValue();
                if (sValue && sValue.trim()) {
                    oInput.setValueState(sap.ui.core.ValueState.None);
                }
            },

            onRadioGroupSelect: function (oEvent) {
                const oGroup = oEvent.getSource();
                const iIndex = oEvent.getParameter("selectedIndex");

                if (iIndex > -1) {
                    oGroup.setValueState(sap.ui.core.ValueState.None);
                }

                const oSelectedButton = oGroup.getButtons()[iIndex];
                if (!oSelectedButton) return;

                // Call onRadioButtonSelect logic
                this.onRadioButtonSelect({
                    getSource: () => oSelectedButton
                });
            },
            onRadioButtonSelect: async function (oEvent) {
                // const selectedChoiceID = oEvent.oSource.getBindingContext("demoModel").getProperty("ID");
                // const selectedQuestionID = oEvent.oSource.getBindingContext("demoModel").getObject().question_ID;
                // const isSelected = oEvent.getParameter('selected');
                // const selectedText = oEvent.oSource.getBindingContext("demoModel").getObject().text;
                const choiceObj = oEvent.getSource().getBindingContext("demoModel").getObject();
                const selectedChoiceID = choiceObj.ID;
                const selectedQuestionID = choiceObj.question_ID;
                const isSelected = oEvent.getSource().getSelected();
                const selectedText = choiceObj.text;
                // oEvent.oSource.getBindingContext("demoModel").getObject().selected = 'true';
                choiceObj.selected = 'true';
                sap.ui.getCore().getModel("choiceModel").getData().filter(item => item.ID === selectedChoiceID)[0].selected = "true";
                // const bindingContext = oEvent.oSource.getBindingContext("demoModel");
                const bindingContext = oEvent.getSource().getBindingContext("demoModel");
                let demoModelData = bindingContext.getModel().getData();
                let demoModelResults = demoModelData.results;
                if (choiceObj.text == 'other' || choiceObj.text == 'Other' || choiceObj.text == 'OTHER')
                    demoModelResults.filter(item => item.ID === selectedQuestionID)[0].otherResponse = "other";
                else {
                    demoModelResults.filter(item => item.ID === selectedQuestionID)[0].otherResponse = "";
                    demoModelResults.filter(item => item.ID === selectedQuestionID)[0].responseText = "";
                }
                // Explanation Required
                if (choiceObj.explanation_required == true) {
                    demoModelResults.filter(item => item.ID === selectedQuestionID)[0].explanationRequired = true;
                } else {
                    demoModelResults.filter(item => item.ID === selectedQuestionID)[0].explanationRequired = false;
                }

                const choiceData = sap.ui.getCore().getModel("choiceModel").getData();
                var selectedQuestion = demoModelResults.filter(item => item.ID === selectedQuestionID)[0];
                await selectedQuestion.choices.forEach(function (choices) {
                    if (choices.ID != selectedChoiceID) {
                        choices.selected = 'false';
                        sap.ui.getCore().getModel("choiceModel").getData().filter(item => item.ID === choices.ID)[0].selected = "false";
                    }
                });

                if (selectedQuestion.section.text != "Determining Prohibited Use Cases") {
                    await demoModelResults.forEach(async function (modelContent) {
                        if (modelContent.dependsOnQuestionAnswerValue != undefined) {
                            let count = 0; let selectedCount = 0;
                            await modelContent.dependsOnQuestionAnswerValue.forEach(function (choice) {
                                if (choice.choices_ID == selectedChoiceID) {
                                    modelContent.visibility = 'true';// Handle the selected ChoiceID of the selected choice
                                    selectedCount++;
                                }
                                else {
                                    sap.ui.getCore().getModel("choiceModel").getData().forEach(function (ChoiceContent) {
                                        if (choice.choices_ID == ChoiceContent.ID)
                                            if (ChoiceContent.selected == "true") {
                                                count++;
                                            }
                                    });
                                }
                            });
                            if (selectedCount == 0) {
                                if (count > 0)
                                    modelContent.visibility = 'true';
                                else
                                    modelContent.visibility = 'false';
                            }
                            else {
                                if (modelContent.responseType_code == "CHOICE") {
                                    modelContent.choices?.forEach(choice => choice.selected = false)
                                }
                                else { modelContent.responseText = ""; }
                                modelContent.otherResponse = "";
                            }
                        }
                    });
                } else {
                    await demoModelResults.forEach(async function (modelContent) {
                        if (modelContent.dependsOnQuestionAnswerValue != undefined) {
                            let count = 0; let selectedCount = 0;
                            await modelContent.dependsOnQuestionAnswerValue.forEach(function (choice) {
                                if (choice.choices_ID == selectedChoiceID) {
                                    modelContent.visibility = 'true';// Handle the selected ChoiceID of the selected choice
                                    selectedCount++;
                                }
                                else {
                                    sap.ui.getCore().getModel("choiceModel").getData().forEach(function (ChoiceContent) {
                                        if (choice.choices_ID == ChoiceContent.ID)
                                            if (ChoiceContent.selected == "true") {
                                                count++;
                                            }
                                    });
                                }
                            });
                            if (selectedCount == 0) {
                                if (count > 0) {
                                    modelContent.visibility = 'true';
                                    if (((isSelected == true && selectedText == 'Yes') || (isSelected == false && selectedText == 'No'))
                                        && modelContent.section.text == "Determining Prohibited Use Cases" && modelContent.ID != selectedQuestionID
                                        && selectedQuestion.questionNumber < modelContent.questionNumber) {
                                        modelContent.visibility = 'false';
                                    }
                                }
                                else
                                    modelContent.visibility = 'false';
                            }
                            else {
                                if (modelContent.responseType_code == "CHOICE") {
                                    modelContent.choices?.forEach(choice => choice.selected = false)
                                }
                                else { modelContent.responseText = ""; }
                                modelContent.otherResponse = "";
                            }
                        }
                    });
                }

                this.getView().byId("ID_DEMO").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("ID_DEMO").getModel("demoModel").setData(demoModelData);

                this.getView().byId("ID_DEMO").getModel("demoModel").refresh;
                this.getView().byId("ID_DEMO").getModel("demoModel").refresh(true);
                this.getView().byId("ID_DEMO").getBinding("items").refresh();

                this.getView().byId("prohibitedUseCaseList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("prohibitedUseCaseList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("prohibitedUseCaseList").getModel("demoModel").refresh;
                this.getView().byId("prohibitedUseCaseList").getModel("demoModel").refresh(true);
                this.getView().byId("prohibitedUseCaseList").getBinding("items").refresh();

                this.getView().byId("highRiskUseCaseList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("highRiskUseCaseList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("highRiskUseCaseList").getModel("demoModel").refresh;
                this.getView().byId("highRiskUseCaseList").getModel("demoModel").refresh(true);
                this.getView().byId("highRiskUseCaseList").getBinding("items").refresh();

                this.getView().byId("EUActList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("EUActList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("EUActList").getModel("demoModel").refresh();
                this.getView().byId("EUActList").getModel("demoModel").refresh(true);
                this.getView().byId("EUActList").getBinding("items").refresh();

                this.getView().byId("ID_DEMO1").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("ID_DEMO1").getModel("demoModel").setData(demoModelData);

                this.getView().byId("ID_DEMO1").getModel("demoModel").refresh;
                this.getView().byId("ID_DEMO1").getModel("demoModel").refresh(true);
                this.getView().byId("ID_DEMO1").getBinding("items").refresh();

                this.getView().byId("harmlessSecuritySectionList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("harmlessSecuritySectionList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("harmlessSecuritySectionList").getModel("demoModel").refresh;
                this.getView().byId("harmlessSecuritySectionList").getModel("demoModel").refresh(true);
                this.getView().byId("harmlessSecuritySectionList").getBinding("items").refresh();

                this.getView().byId("enableHumanAgencySectionList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("enableHumanAgencySectionList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("enableHumanAgencySectionList").getModel("demoModel").refresh;
                this.getView().byId("enableHumanAgencySectionList").getModel("demoModel").refresh(true);
                this.getView().byId("enableHumanAgencySectionList").getBinding("items").refresh();

                this.getView().byId("avoidingBiasSectionList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("avoidingBiasSectionList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("avoidingBiasSectionList").getModel("demoModel").refresh;
                this.getView().byId("avoidingBiasSectionList").getModel("demoModel").refresh(true);
                this.getView().byId("avoidingBiasSectionList").getBinding("items").refresh();

                this.getView().byId("ensureTransparencySectionSectionList").getModel("demoModel").getData().results = demoModelResults;
                this.getView().byId("ensureTransparencySectionSectionList").getModel("demoModel").setData(demoModelData);

                this.getView().byId("ensureTransparencySectionSectionList").getModel("demoModel").refresh;
                this.getView().byId("ensureTransparencySectionSectionList").getModel("demoModel").refresh(true);
                this.getView().byId("ensureTransparencySectionSectionList").getBinding("items").refresh();

                const ImpactAssessmentFilter = new sap.ui.model.Filter("questionnaireType", sap.ui.model.FilterOperator.Contains, "Usecase Impact Assessment");
                const PolicySelfAssessmentFilter = new sap.ui.model.Filter("questionnaireType", sap.ui.model.FilterOperator.Contains, "Policy Self Assessment");

                const GeneralUserCaseSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "General Usecase Information");
                const ProhibitedSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Determining Prohibited Use Cases");
                const HighRiskSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Determining High-Risk Use Cases");
                const EUActSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "EU AI Act Compliance Assessment");
                const HarmlessSecuritySection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Harmlessness, Safety and Security");
                const EnableHumanAgencySection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Enable Human Agency and Oversight");
                const AvoidingBiasSection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Avoid Bias and Discrimination");
                const EnsureTransparencySection = new sap.ui.model.Filter("section/text", sap.ui.model.FilterOperator.EQ, "Ensure Transparency and Explainability");

                const GeneralUseCaseFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, GeneralUserCaseSection], and: true });
                const ProhibitedFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, ProhibitedSection], and: true });
                const HighRiskFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, HighRiskSection], and: true });
                const EUActFilter = new sap.ui.model.Filter({ filters: [ImpactAssessmentFilter, EUActSection], and: true });
                const GeneralUseCaseFilterPS = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, GeneralUserCaseSection], and: true });
                const HarmlessSecurityFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, HarmlessSecuritySection], and: true });
                const EnableHumanAgencyFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, EnableHumanAgencySection], and: true });
                const AvoidingBiasFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, AvoidingBiasSection], and: true });
                const EnsureTransparencyFilter = new sap.ui.model.Filter({ filters: [PolicySelfAssessmentFilter, EnsureTransparencySection], and: true });

                this.getView().byId("ID_DEMO").getBinding("items").filter(GeneralUseCaseFilter);
                this.getView().byId("prohibitedUseCaseList").getBinding("items").filter(ProhibitedFilter);
                this.getView().byId("highRiskUseCaseList").getBinding("items").filter(HighRiskFilter);
                this.getView().byId("EUActList").getBinding("items").filter(EUActFilter);
                this.getView().byId("ID_DEMO1").getBinding("items").filter(GeneralUseCaseFilterPS);
                this.getView().byId("harmlessSecuritySectionList").getBinding("items").filter(HarmlessSecurityFilter);
                this.getView().byId("enableHumanAgencySectionList").getBinding("items").filter(EnableHumanAgencyFilter);
                this.getView().byId("avoidingBiasSectionList").getBinding("items").filter(AvoidingBiasFilter);
                this.getView().byId("ensureTransparencySectionSectionList").getBinding("items").filter(EnsureTransparencyFilter);

                // this.getView().byId("ID_DEMO").getBinding("items").filter(ImpactAssessmentFilter);
                // this.getView().byId("ID_DEMO1").getBinding("items").filter(PolicySelfAssessmentFilter);
                //this.getView().byId("ID_DEMO").getBinding("items").refresh();
                //If user select option as other inputbox will be provided
            },


            onSavePress: async function (oEvent) {
                const oContext = this.getView().getBindingContext();
                const btnText = oEvent.getSource().getText();
                const assesmentStatusCode = btnText == "Save As Draft" ? "Work In Progress" : "Done";
                const oView = this.getView();
                oView.setBusy(true);
                const data = sap.ui.getCore().getModel("assessmentType").getData();
                let list = ''; let useCaseQuestion; let questionnaireID = '';
                const oListData = this.getView().byId("ID_DEMO").getModel("demoModel").getData().results;

                let riskScore = '';
                let highRiskValue = ''; let prohibitedValue = '';
                if (sap.ui.getCore().getModel("highRiskVal") != undefined)
                    highRiskValue = sap.ui.getCore().getModel("highRiskVal").getData();
                if (sap.ui.getCore().getModel("highRiskVisible") != undefined)
                    prohibitedValue = sap.ui.getCore().getModel("highRiskVisible").getData();
                if (prohibitedValue.visible == 'false')
                    riskScore = 'Prohibited';
                else if (prohibitedValue.visible == 'true' && highRiskValue.Value == 'true')
                    riskScore = highRiskValue.classification;
                else
                    riskScore = 'Not Classified';
                if (data.assessmentType == "ImpactAssessment") {
                    list = this.getView().byId("ID_DEMO");
                    useCaseQuestion = oListData.filter(item => item.questionNumber === 1 && item.questionnaireType == "Usecase Impact Assessment")[0].choices.filter(item => item.selected === 'true');
                    questionnaireID = oListData.filter(item => item.questionNumber === 1 && item.questionnaireType == "Usecase Impact Assessment")[0].questionnaire_ID;
                }
                if (data.assessmentType == "PolicySelfAssessment") {
                    list = this.getView().byId("ID_DEMO1");
                    useCaseQuestion = oListData.filter(item => item.questionNumber === 1 && item.questionnaireType == "Policy Self Assessment")[0].choices.filter(item => item.selected === 'true');
                    questionnaireID = oListData.filter(item => item.questionNumber === 1 && item.questionnaireType == "Policy Self Assessment")[0].questionnaire_ID;
                }
                let useCaseType;
                if (useCaseQuestion.length > 0)
                    useCaseType = useCaseQuestion[0].text;
                else
                    useCaseType = "";
                const oModel = this.getOwnerComponent().getModel();
                // Ensure model is ready
                await oModel.getMetaModel().requestObject("/");
                await new Promise(resolve => setTimeout(resolve, 200));

                let groupID = ''; let orgAssessmentID; let orgAssessmentPath;
                let groupedQID = ''; let groupedQPath = '';
                let qResponses = []; let existingQuestions = [];
                const AssessmentValue = sap.ui.getCore().getModel("assessmentModel").getData();
                orgAssessmentID = AssessmentValue.ID;
                orgAssessmentPath = AssessmentValue.path;

                const sPath = `/AIEthicsImpactAssessments(ID=${orgAssessmentID},IsActiveEntity=false)`;
                await oModel
                    .bindContext(sPath, null, {
                        $expand: "groupedQuestionnaireResponse($expand=questionnaireResponse)"
                    })
                    .requestObject()
                    .then((oData) => {
                        // grouped responses
                        if (oData.groupedQuestionnaireResponse?.length > 0) {
                            const index = oData.groupedQuestionnaireResponse.findIndex(item => item.ID === data.groupedQID);
                            const grouped = oData.groupedQuestionnaireResponse[index];
                            groupedQID = grouped.ID;
                            groupedQPath = `${sPath}/groupedQuestionnaireResponse(ID=${groupedQID},IsActiveEntity=false)`;

                            // questionnaire responses inside grouped response
                            if (grouped.questionnaireResponse?.length > 0) {
                                grouped.questionnaireResponse.forEach((resp) => {
                                    qResponses.push(resp);
                                    existingQuestions.push(resp.question_ID);
                                });
                            }
                        }
                    })
                    .catch((err) => {
                        console.error("Failed to fetch groupedQuestionnaireResponse", err);
                    });


                let oCreateContextResponse;

                const assessmentTypeValue = sap.ui.getCore().getModel("assessmentType").getData().assessmentType;
                const context = await oModel.bindContext(orgAssessmentPath).getBoundContext();

                if (assessmentTypeValue == "ImpactAssessment") {
                    context.setProperty(orgAssessmentPath + "/typeOfUseCase_code", useCaseType);
                    context.setProperty(orgAssessmentPath + "/useCaseclassification_code", riskScore);
                    if (btnText == "Next") {
                        context.setProperty(orgAssessmentPath + "/status_code", 'Ready To Submit');
                        context.setProperty(orgAssessmentPath + "/initialClassification_code", riskScore);
                    }
                }

                const model = context.getModel();
                groupID = model.getGroupId();

                await oModel
                    .bindContext(groupedQPath, null, { $expand: "questionnaireResponse" })
                    .requestObject().then(async (oData) => {
                        const list = oModel.bindList(`${groupedQPath}/questionnaireResponse`, null, [], []);

                        // Load all existing response contexts
                        // const contexts = await list.requestContexts(0, 1000);
                        const contexts = await this.loadAllContexts(list);

                        // Delete each response
                        for (const ctx of contexts) {
                            if (typeof ctx.delete === "function") {
                                await ctx.delete();
                            }
                        }

                        // Submit the changes so groupedQuestionnaireResponse.questionnaireResponse becomes []
                        await oModel.submitBatch(groupID);
                    })
                    .catch((err) => {
                        console.error("Failed to fetch groupedQuestionnaireResponse", err);
                    });

                await context.getModel().submitBatch(groupID).then(async () => {
                    const gContext = model.bindContext(groupedQPath).getBoundContext();
                    if (gContext) {
                        gContext.setProperty(groupedQPath + "/Status_code", assesmentStatusCode);
                        gContext.setProperty(groupedQPath + "/questionnaire_ID", questionnaireID);
                    }

                    await model.submitBatch(groupID).then(() => {
                        const oResponseBinding = model.bindList(groupedQPath + "/questionnaireResponse");
                        oListData.forEach(async function (oContext) {
                            const oData = oContext;
                            let oChoiceID = ''; let typeOfAssessment = '';
                            if (assessmentTypeValue == "ImpactAssessment")
                                typeOfAssessment = "Usecase Impact Assessment";
                            if (assessmentTypeValue == "PolicySelfAssessment")
                                typeOfAssessment = "Policy Self Assessment";
                            if (oData.visibility == "true" && oData.questionnaireType == typeOfAssessment) {
                                if (oData.choices != undefined) {
                                    oData.choices.forEach(function (oContext) {
                                        if (oContext.selected == "true")
                                            oChoiceID = oContext.ID;
                                    })
                                }

                                // if (existingQuestions.includes(oData.ID)) {
                                //     const question = qResponses.filter(item => item.question_ID === oData.ID);
                                //     const index = question.findIndex(item => item.groupedQuestionnaireResponse_ID === groupedQID);
                                //     let gContext, qPath = question[index].path;
                                //     if (qPath) {
                                //         gContext = model.bindContext(qPath).getBoundContext();
                                //     } else {
                                //         qPath = `${groupedQPath}/questionnaireResponse(ID=${question[index].ID},IsActiveEntity=${question[index].IsActiveEntity})`;
                                //         gContext = model.bindContext(qPath).getBoundContext();
                                //     }
                                //     gContext.setProperty(qPath + "/question_ID", oData.ID);
                                //     gContext.setProperty(qPath + "/responseText", oData.responseText);
                                //     gContext.setProperty(qPath + "/responseChoice_ID", oChoiceID);

                                //     model.submitBatch(groupID).then(() => {
                                //     });
                                // }
                                // else {
                                oCreateContextResponse = oResponseBinding.create({
                                    question_ID: oData.ID,
                                    responseText: oData.responseText,
                                    responseChoice_ID: oChoiceID
                                });
                                (function (context) {
                                    context.created().then(() => {
                                        // console.log(context.getObject().ID + "created");
                                    })
                                })(oCreateContextResponse);
                                // }
                            }
                        });
                        oView.setBusy(false);
                        setTimeout(function () {
                            window.history.go(-1);
                        }, 500);
                    });
                }).catch((oError) => {
                    oView.setBusy(false);
                    sap.m.MessageBox.error("Update failed: " + oError.message);
                });
            },

            loadAllContexts: async function (oListBinding, iPageSize = 100) {
                let aAllContexts = [];
                let iSkip = 0;

                while (true) {
                    const aContexts = await oListBinding.requestContexts(iSkip, iPageSize);
                    if (!aContexts.length) break;
                    aAllContexts = aAllContexts.concat(aContexts);
                    if (aContexts.length < iPageSize) break;
                    iSkip += iPageSize;
                }
                return aAllContexts;
            },
            _onInitPanelVisibility: function (oView, questionnaireType, readOnly) {
                console.log('_onInitPanelVisibility');
                if (questionnaireType == "Usecase Impact Assessment" || questionnaireType == "ImpactAssessment") {
                    oView.byId("QuestionnaireResponses").setTitle(`Artificial Intelligence Use Case Impact Assessment ${readOnly}`);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                }
                else {
                    oView.byId("QuestionnaireResponses").setTitle(`AI Ethics Policy Self-Assessment ${readOnly}`);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                }
            },
            //Navigation to Use Case Impact  Assessment from Start Impact Assessment Action
            onNavtoInitialPage: async function () {
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "1");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "17");

                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
            },

            //Navigation to Policy Self Assessment from Start Policy Self Assessment Action
            onNavtoInitialPagePS: async function () {
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "1");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "15");

                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
            },
            onNavToProhibitedUseCaseSection: function () {
                const oContext = this.oView.getBindingContext();
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "3");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "51");

                const generalSectionData = this.getView().byId("ID_DEMO").getModel("demoModel").getData().results.filter(item => item.section.text === 'General Usecase Information' && item.visibility == 'true' && item.questionnaireType == 'Usecase Impact Assessment');
                generalSectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                                if ((choice.text == "Other" || object.explanationRequired == true) && (!object.responseText || object.responseText == "")) {
                                    blankData++;
                                }
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0) {
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
                }
                else {
                    this._validateCurrentSection("General Usecase Information");
                    // sap.m.MessageBox.error("Please fill all the questions for the current section");
                }
            },

            onNavToHighRiskUsecaseSection: function () {
                let blankData = 0; let yesSelected = 0; let highRiskVisible; let jsonModel;
                const prohibitedData = this.getView().byId("prohibitedUseCaseList").getModel("demoModel").getData().results.filter(item => item.section.text === 'Determining Prohibited Use Cases' && item.visibility == 'true' && item.questionnaireType == 'Usecase Impact Assessment');
                prohibitedData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                                if (choice.text == 'YES' || choice.text == 'Yes' || choice.text == 'yes')
                                    yesSelected++;
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0 && yesSelected == 0) {
                    highRiskVisible = { visible: "true" };
                    jsonModel = new sap.ui.model.json.JSONModel(highRiskVisible);
                    sap.ui.getCore().setModel(jsonModel, "highRiskVisible");
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "4");
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "68");

                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
                }
                if (blankData == 0 && yesSelected > 0) {
                    highRiskVisible = { visible: "false" };
                    jsonModel = new sap.ui.model.json.JSONModel(highRiskVisible);
                    sap.ui.getCore().setModel(jsonModel, "highRiskVisible");
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "5");
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "84");

                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
                }
                if (blankData > 0) {
                    this._validateCurrentSection("Determining Prohibited Use Cases");
                }
            },

            onNavToImpactAssessmentResultSection: async function () {
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "6");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "100");

                const EUActSectionData = this.getView().byId("EUActList").getModel("demoModel").getData().results.filter(item => item.section.text === 'EU AI Act Compliance Assessment' && item.visibility == 'true' && item.questionnaireType == 'Usecase Impact Assessment');
                // const highriskData = oListData.filter(item => item.section.text === 'Determining High-Risk Use Cases' && item.visibility === 'true' && item.questionnaireType === 'Usecase Impact Assessment');
                EUActSectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices?.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                                if ((choice.text == "Other" || object.explanationRequired == true) && (!object.responseText || object.responseText == "")) {
                                    blankData++;
                                }
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0) {
                    const highRiskVisibility = sap.ui.getCore().getModel("highRiskVisible").getData();
                    if (highRiskVisibility.visible == 'true') {
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(this.isBtnVisible);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(true);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
                    }
                    else {
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(this.isBtnVisible);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                        sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(true);
                    }
                }
                else {
                    this._validateCurrentSection("EU AI Act Compliance Assessment");
                }
            },


            // onNavToImpactAssessmentResultSection: async function (oEvent) {
            // onNavToImpactAssessmentResultSection: async function (oEvent) {
            onNavToEUActSection: async function () {

                if (this._isModelContextChangeAttached) {
                    this.getView().detachModelContextChange(this.onAfterBinding, this);
                    this._isModelContextChangeAttached = false;
                }
                const oView = this.getView();
                const oModel = oView.getModel();
                oView.setBusyIndicatorDelay(0);
                oView.setBusy(true);
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "5");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "84");

                try {
                    const oListData = this.getView().byId("ID_DEMO").getModel("demoModel").getData().results;
                    const highRiskFrameworkQuestions = [];
                    const individialHighRiskCalulationResponse = [];

                    // Validate and collect data
                    const { blankData, yesSelected } = this._validateAndCollectData(oListData, highRiskFrameworkQuestions, individialHighRiskCalulationResponse);

                    if (blankData > 0) {
                        this._validateCurrentSection("Determining High-Risk Use Cases");
                        return;
                    }

                    const oContext = oView.getBindingContext();

                    // Calculate individual risk scores for high-risk framework questions
                    await this._calculateIndividualRiskScores(
                        oModel,
                        oContext,
                        highRiskFrameworkQuestions,
                        individialHighRiskCalulationResponse,
                        oListData
                    );

                    // Calculate overall risk score
                    let highRiskVal = await this._calculateOverallRiskScore(oModel, oContext);

                    if (highRiskVal && highRiskVal.classification) {
                        highRiskVal = { Value: "true", classification: highRiskVal.classification };
                        const jsonModel = new sap.ui.model.json.JSONModel(highRiskVal);
                        this.getView().setModel(jsonModel, "highRiskVal");
                        sap.ui.getCore().setModel(jsonModel, "highRiskVal");
                    }

                    // Update UI based on the results
                    this._updateUIAfterRiskCalculation(this.isBtnVisible);

                    const highRiskData = this.getView().getModel("highRiskVal").getData();
                    const classificationText = this._getClassificationText(highRiskData.classification);
                    this.getView().getModel("highRiskVal").setProperty("/classificationText", classificationText);


                } catch (error) {
                    console.error("Error in onNavToImpactAssessmentResultSection:", error);
                    sap.m.MessageBox.error("An error occurred: " + error.message);
                } finally {
                    oView.setBusy(false); // Hide the busy indicator
                    // Reattach the ModelContextChange listener at the end of the function
                    if (!this._isModelContextChangeAttached) {
                        this.getView().attachModelContextChange(this.onAfterBinding, this);
                        this._isModelContextChangeAttached = true;
                    }
                }
            },


            _getClassificationText: function (classification) {
                let classificationText = "";
                switch (classification) {
                    case "Standard": case "Limited Risk":
                        classificationText = `As the classification is marked as ${classification}, there is no further action. You are good to go with the next steps. In rare cases, the AI Ethics Office might reach out to you for further clarification`;
                        break;
                    case "High Risk": case "Controlled High Risk": case "Critical High Risk":
                        classificationText = `As the classification is marked as ${classification}, the AI Ethics Office will soon get in touch to schedule a meeting to further discuss the case.  The intention is to check if a reclassification to Standard or Limited Risk can be done, or retain the initial classification and take the next steps in the process`;
                        break;
                    case "Prohibited":
                        classificationText = `As the classification is marked as ${classification}, stop further development, deployment, and sale`;
                        break;
                    default:
                        classificationText = "";
                }
                return classificationText;
            },

            _validateAndCollectData: function (oListData, highRiskFrameworkQuestions, individialHighRiskCalulationResponse) {
                let blankData = 0;
                let yesSelected = 0;

                const highriskData = oListData.filter(item => item.section.text === 'Determining High-Risk Use Cases' && item.visibility === 'true' && item.questionnaireType === 'Usecase Impact Assessment');

                highriskData.forEach(object => {
                    if (object.responseType_code == 'CHOICE') {
                        object.choices.forEach(choice => {
                            if (choice.selected === 'true') {
                                if (object.highRiskFramework_code) {
                                    highRiskFrameworkQuestions.push(choice);
                                }
                            }
                        });
                    }
                });

                highriskData.forEach(object => {
                    if (object.responseType_code === 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(choice => {
                            if (choice.selected === 'true') {
                                choiceSelected++;
                                if ((choice.text == "Other" || object.explanationRequired == true) && (!object.responseText || object.responseText == "")) {
                                    blankData++;
                                }
                                if (choice.high_risk_score) {
                                    const parentChoiceIDs = object.dependsOnQuestionAnswerValue?.map(dep => dep.choices_ID) || [];
                                    const matchingParentChoiceID = parentChoiceIDs.find(parentChoiceID =>
                                        highRiskFrameworkQuestions.some(frameworkChoice => frameworkChoice.ID === parentChoiceID)
                                    );
                                    if (matchingParentChoiceID) {
                                        individialHighRiskCalulationResponse.push({
                                            high_risk_score_choice: choice,
                                            riskQuestionType_code: object.riskQuestionType_code,
                                            parent_Question_ID: matchingParentChoiceID, // Ensure it's from highRiskFrameworkQuestions
                                        });
                                        //choice ID of of the parent question that was selected
                                        // parent_Question_ID: object.dependsOnQuestionAnswerValue[0].choices_ID,
                                    }
                                }
                                /* if (object.highRiskFramework_code) {
                                     highRiskFrameworkQuestions.push(choice);
                                 }*/
                                if (['YES', 'Yes', 'yes'].includes(choice.text)) {
                                    yesSelected++;
                                }
                            }
                        });
                        if (choiceSelected === 0) blankData++;
                    }

                    if (object.responseType_code === 'TEXT' && !object.responseText) {
                        blankData++;
                    }
                });

                return { blankData, yesSelected };
            },

            _calculateIndividualRiskScores: async function (oModel, oContext, highRiskFrameworkQuestions, individialHighRiskCalulationResponse, oListData) {
                const scopeDataGeneralInforSection = oListData.filter(item => item.section.text === 'General Usecase Information');
                const scopeisScoreQuestion = scopeDataGeneralInforSection.filter(item => item.riskQuestionType_code === 'Scope');
                const scopeChoiceId = scopeisScoreQuestion[0]?.choices.find(choice => choice.selected === 'true')?.ID;

                await Promise.all(
                    highRiskFrameworkQuestions.map(async questionId => {
                        const choicesForQuestion = individialHighRiskCalulationResponse.filter(item => item.parent_Question_ID === questionId.ID);

                        const remediatbilityChoiceID = choicesForQuestion.find(item => item.riskQuestionType_code === 'Remediability')?.high_risk_score_choice?.ID;
                        const likeliHoodChoiceID = choicesForQuestion.find(item => item.riskQuestionType_code === 'Likelihood of occurrence')?.high_risk_score_choice?.ID;
                        const scaleChoiceID = choicesForQuestion.find(item => item.riskQuestionType_code === 'Scale')?.high_risk_score_choice?.ID;

                        try {
                            const oOperation = oModel.bindContext("AIEthicsAssessment.calculateIndividualRiskScore(...)", oContext);

                            oOperation.setParameter("scopeChoiceId", scopeChoiceId || null);
                            oOperation.setParameter("remediatbilityChoiceID", remediatbilityChoiceID || null);
                            oOperation.setParameter("likeliHoodChoiceID", likeliHoodChoiceID || null);
                            oOperation.setParameter("scaleChoiceID", scaleChoiceID || null);
                            oOperation.setParameter("individualRiskQuestionId", questionId.ID);

                            await oOperation.execute();
                            const result = oOperation.getBoundContext().getObject();

                            const riskScoreModel = new sap.ui.model.json.JSONModel({
                                questionId: questionId,
                                riskScore: result.value
                            });
                            this.getView().setModel(riskScoreModel, `riskScore_${questionId}`);
                        } catch (error) {
                            console.error(`Failed to calculate risk score for question ${questionId.ID}:`, error);
                            sap.m.MessageBox.error(`Failed to calculate risk score: ${error.message}`);
                        }
                    })
                );
            },

            _calculateOverallRiskScore: async function (oModel, oContext) {
                try {
                    const oOperation = oModel.bindContext("AIEthicsAssessment.calculateOverAllRiskScore(...)", oContext);
                    await oOperation.execute();
                    return oOperation.getBoundContext().getObject();
                } catch (error) {
                    console.error("Failed to calculate overall risk score:", error);
                    sap.m.MessageBox.error("Failed to calculate overall risk score: " + error.message);
                    return null;
                }
            },

            _updateUIAfterRiskCalculation: function (isBtnVisible) {
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(isBtnVisible);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
            },



            onNavBackToHighRiskUsecaseSection: function () {
                const highRiskVisibility = sap.ui.getCore().getModel("highRiskVisible").getData();
                if (highRiskVisibility.visible == 'true') {
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "4");
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "68");

                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
                }
                else {
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "3");
                    this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "51");

                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
                }
            },


            onNavBackToEUActSection: function () {
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "5");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "84");

                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelProhibitedUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHighRiskUseCaseSection").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEUActSection").setVisible(true);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection4").setVisible(false);
                sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelsection5").setVisible(false);
            },


            onNavToHarmlessSecuritySection: function () {
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "3");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "45");

                const generalSectionData = this.getView().byId("ID_DEMO1").getModel("demoModel").getData().results.filter(item => item.section.text === 'General Usecase Information' && item.visibility == 'true' && item.questionnaireType == 'Policy Self Assessment');
                generalSectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                                if (choice.text == "Other" && (!object.responseText || object.responseText == "")) {
                                    blankData++;
                                }
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }

                });
                if (blankData == 0) {
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSectionPS").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHarmlessSecuritySection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnableHumanAgencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelAvoidingBiasSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnsureTransparencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelThankYouSection").setVisible(false);
                } else {
                    this._validateCurrentSection("General Usecase Information");
                }
            },

            onNavToEnableHumanAgencySection: function () {
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "4");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "60");

                const harmlessSecuritySectionData = this.getView().byId("harmlessSecuritySectionList").getModel("demoModel").getData().results.filter(item => item.section.text === 'Harmlessness, Safety and Security' && item.visibility == 'true' && item.questionnaireType == 'Policy Self Assessment');
                harmlessSecuritySectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0) {
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSectionPS").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHarmlessSecuritySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnableHumanAgencySection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelAvoidingBiasSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnsureTransparencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelThankYouSection").setVisible(false);
                } else {
                    this._validateCurrentSection("Harmlessness, Safety and Security");
                }
            },

            onNavToAvoidingBiasSection: function () {
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "5");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "73");

                const enableHumanAgencySectionData = this.getView().byId("enableHumanAgencySectionList").getModel("demoModel").getData().results.filter(item => item.section.text === 'Enable Human Agency and Oversight' && item.visibility == 'true' && item.questionnaireType == 'Policy Self Assessment');
                enableHumanAgencySectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0) {
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSectionPS").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHarmlessSecuritySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnableHumanAgencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelAvoidingBiasSection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnsureTransparencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelThankYouSection").setVisible(false);
                } else {
                    this._validateCurrentSection("Enable Human Agency and Oversight");
                }
            },

            onNavToEnsureTransparencySection: function () {
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "6");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "87");

                const avoidingBiasSectionData = this.getView().byId("avoidingBiasSectionList").getModel("demoModel").getData().results.filter(item => item.section.text === 'Avoid Bias and Discrimination' && item.visibility == 'true' && item.questionnaireType == 'Policy Self Assessment');
                avoidingBiasSectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0) {
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSectionPS").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHarmlessSecuritySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnableHumanAgencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelAvoidingBiasSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnsureTransparencySection").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelThankYouSection").setVisible(false);
                } else {
                    this._validateCurrentSection("Avoid Bias and Discrimination");
                }
            },

            onNavToThankYouSection: function () {
                let blankData = 0;
                this.getView().getModel("ProgressIndicatorModel").setProperty("/currentSection", "7");
                this.getView().getModel("ProgressIndicatorModel").setProperty("/value", "100");

                const ensureTransparencySectionSectionData = this.getView().byId("ensureTransparencySectionSectionList").getModel("demoModel").getData().results.filter(item => item.section.text === 'Ensure Transparency and Explainability' && item.visibility == 'true' && item.questionnaireType == 'Policy Self Assessment');
                ensureTransparencySectionSectionData.forEach(function (object) {
                    if (object.responseType_code == 'CHOICE') {
                        let choiceSelected = 0;
                        object.choices.forEach(function (choice) {
                            if (choice.selected == 'true') {
                                choiceSelected++;
                            }
                        });
                        if (choiceSelected == 0)
                            blankData++;
                    }
                    if (object.responseType_code == 'TEXT') {
                        if (object.responseText == '')
                            blankData++;
                    }
                });
                if (blankData == 0) {
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel2").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--mainPanel1").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--UseCaseImpactAssessmentForm").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySelfAssessmentForm").setVisible(true);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySave").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--PolicySubmit").setVisible(this.isBtnVisible);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelGeneralUseCaseSectionPS").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelHarmlessSecuritySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnableHumanAgencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelAvoidingBiasSection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelEnsureTransparencySection").setVisible(false);
                    sap.ui.getCore().byId("aiethicsassessment.aiethicsassessmentapp::GroupedQuestionnaireResponsesGroupedQuestionnaireResponsesPage--panelThankYouSection").setVisible(true);
                } else {
                    this._validateCurrentSection("Ensure Transparency and Explainability");
                }
            },

            _validateCurrentSection: function (sectionText) {
                const oDemoModel = this.getView().byId("ID_DEMO").getModel("demoModel");
                const data = oDemoModel.getData().results;
                const currentSectionData = data.filter(item => item.section?.text === sectionText);
                let hasError = false;

                sap.m.MessageBox.error(
                    "Please fill all the questions for the current section",
                    {
                        actions: [sap.m.MessageBox.Action.OK],
                        emphasizedAction: sap.m.MessageBox.Action.OK,
                        onClose: function () {
                            this._scrollToFirstError(sectionText);
                        }.bind(this)
                    }
                );

                currentSectionData.forEach((q, index) => {
                    // Reset value state
                    q.textValueState = "None";
                    q.choiceValueState = "None";
                    q.otherValueState = "None";
                    q.explValueState = "None";
                    q.valueStateText = "";

                    if (q.visibility !== "true" || !q.isEditable) {
                        return;
                    }

                    // TEXT validation
                    if ((q.responseType_code === "TEXT" || q.explanationRequired) && !q.responseText) {
                        q.textValueState = "Error";
                        q.explValueState = "Error";
                        q.valueStateText = "This field is required";
                        hasError = true;
                    }

                    // CHOICE validation
                    if (q.responseType_code === "CHOICE") {
                        const selected = q.choices?.some(c => c.selected === "true");
                        if (!selected) {
                            q.choiceValueState = "Error";
                            hasError = true;
                        }
                        if (q.otherResponse && !q.responseText) {
                            q.otherValueState = "Error";
                            q.valueStateText = "This field is required";
                            hasError = true;
                        }
                    }
                });

                oDemoModel.refresh(true);
                return !hasError;
            },

            _scrollToFirstError: function (sectionText) {
                const aErrors = this.getView().findAggregatedObjects(true, oControl => {
                    if (!oControl.getValueState ||
                        oControl.getValueState() !== sap.ui.core.ValueState.Error) {
                        return false;
                    }
                    const oCtx = oControl.getBindingContext("demoModel");
                    return oCtx?.getObject()?.section?.text === sectionText;
                });

                if (!aErrors.length) return;

                let oTarget = aErrors[0];
                // Prefer visible + focusable error control of same question
                const oCtx = oTarget.getBindingContext("demoModel");

                const aSameQuestionErrors = aErrors.filter(c =>
                    c.getBindingContext("demoModel") === oCtx
                );

                const oPreferred = aSameQuestionErrors.find(c =>
                    c.getVisible?.() && typeof c.focus === "function"
                );

                if (oPreferred) {
                    oTarget = oPreferred;
                }

                const oObj = oCtx?.getObject();
                const oVSBinding = oTarget.getBindingInfo?.("valueState");
                const sVSPath = oVSBinding?.parts?.[0]?.path;

                if (oObj?.responseType_code === "CHOICE" && sVSPath === "choiceValueState") {
                    const oRow = oTarget.getParent?.(); // VBox
                    const aGroups = oRow?.findAggregatedObjects?.(true, c =>
                        c.isA && c.isA("sap.m.RadioButtonGroup")
                    ) || [];

                    if (aGroups.length) {
                        oTarget = aGroups[0];
                    }
                }

                const oDom = oTarget.getDomRef(true);
                oDom?.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                    inline: "nearest"
                });

                setTimeout(() => {
                    if (oTarget.isA?.("sap.m.RadioButtonGroup")) {
                        const btn = oTarget.getButtons()?.find(b => b.getEnabled());
                        btn?.focus();
                    } else {
                        oTarget.focus?.();
                    }
                }, 250);
            }

        });
    }
);
